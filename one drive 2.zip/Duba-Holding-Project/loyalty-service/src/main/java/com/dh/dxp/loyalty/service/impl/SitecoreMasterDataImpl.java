package com.dh.dxp.loyalty.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.MasterDataBeans;
import com.dh.dxp.loyalty.beans.TaxDetails;
import com.dh.dxp.loyalty.service.SitecoreMasterDataService;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.SitecoreRestUtil;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class SitecoreMasterDataImpl implements SitecoreMasterDataService {

	@Value("#{'${sitecore.domain}'}")
	private String sitecoreDomainUri;

	private static final Logger logger = LogManager.getLogger(SitecoreMasterDataImpl.class);
	private static final String SITECORE_MASTER_CACHE = "sitecore_master_cache";

	@Autowired
	private SitecoreRestUtil sitecoreRestUtil;

	@Cacheable(value = SITECORE_MASTER_CACHE, key = "#hotelCode+':'+#language")
	public MasterDataBeans getMasterDataFromSitecore() throws SitecoreException {

		MasterDataBeans masterData = new MasterDataBeans();
		JsonNode masterNode = getDataFromSitecore();
		JsonNode placeholders = masterNode.path(DHConstantUtils.SITECORE).path(DHConstantUtils.ROUTE)
				.path(DHConstantUtils.PLACEHOLDERS);
		masterData.setBedPreferences(getPlaceholderFields(placeholders, "BedPreference", DHConstantUtils.TITLE));
		masterData.setCancellationPolicy(
				getPlaceholderFields(placeholders, "CancellationPolicy", DHConstantUtils.DESCRIPTION));
		masterData.setSpecialRequest(getPlaceholderFields(placeholders, "SpecialRequests", DHConstantUtils.TITLE));
		masterData.setTaxDetails(getPlaceholderObject(placeholders, "TaxCode", DHConstantUtils.DISPLAY_NAME));
		masterData.setRoomLabels(getPlaceholderLabels(placeholders));
		return masterData;
	}

	private Map<String, String> getPlaceholderLabels(JsonNode placeholders) {
		Map<String, String> placeholderMap = new ConcurrentHashMap<>();
		for (JsonNode bedPrefJson : placeholders.path("Customize Stay")) {
			JsonNode bedPrefFieldsJson = bedPrefJson.path(DHConstantUtils.FIELDS);
			for (JsonNode bedPrefItemsJson : bedPrefFieldsJson.path(DHConstantUtils.ITEMS)) {
				JsonNode bedPrefFieldJson = bedPrefItemsJson.path(DHConstantUtils.FIELDS);
				String title = bedPrefFieldJson.path(DHConstantUtils.TITLE).path(DHConstantUtils.VALUE).textValue();
				String image = bedPrefFieldJson.path("Image").path(DHConstantUtils.VALUE).path("src").asText();
				placeholderMap.put(title, image);
			}
		}
		return placeholderMap;
	}

	private Map<String, TaxDetails> getPlaceholderObject(JsonNode placeholders, String placeHolderName, String label) {
		Map<String, TaxDetails> placeholderMap = new HashMap<>();

		for (JsonNode placeholderIterator : placeholders.path(placeHolderName)) {
			JsonNode objectField = placeholderIterator.path(DHConstantUtils.FIELDS);
			for (JsonNode fieldIterator : objectField.path(DHConstantUtils.ITEMS)) {
				TaxDetails tax = new TaxDetails();
				tax.setTaxName(fieldIterator.findValue(label).asText());
				JsonNode objectNode = fieldIterator.path(DHConstantUtils.FIELDS);
				String taxCode = objectNode.path(DHConstantUtils.CODE).findValue(DHConstantUtils.VALUE).asText();
				tax.setTaxCode(taxCode);
				tax.setTaxDescription(
						objectNode.path(DHConstantUtils.DESCRIPTION).findValue(DHConstantUtils.VALUE).asText());
				placeholderMap.put(taxCode, tax);
			}
		}

		return placeholderMap;
	}

	private Map<String, String> getPlaceholderFields(JsonNode placeholders, String placeHolderName, String label) {
		Map<String, String> placeholderMap = new HashMap<>();

		for (JsonNode placeholderIterator : placeholders.path(placeHolderName)) {
			JsonNode objectField = placeholderIterator.path(DHConstantUtils.FIELDS);
			for (JsonNode fieldIterator : objectField.path(DHConstantUtils.ITEMS)) {
				JsonNode objectNode = fieldIterator.path(DHConstantUtils.FIELDS);
				String objectCode = objectNode.path(DHConstantUtils.CODE).findValue(DHConstantUtils.VALUE).asText();
				String objectTitle = objectNode.path(label).path(DHConstantUtils.VALUE).textValue();
				placeholderMap.put(objectCode, objectTitle);
			}
		}

		return placeholderMap;
	}

	private JsonNode getDataFromSitecore() throws SitecoreException {
		URI url = null;
		StringBuilder urlBuilder = new StringBuilder((sitecoreDomainUri));
		String urlString = urlBuilder.append(DHConstantUtils.SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS).toString()
				.replace("{0}", DHConstantUtils.MASTER_CODE)
				.replace("{1}", DHConstantUtils.SITECORE_API_LAYOUT_RENDER_APIKEY)
				.replace("{2}", DHConstantUtils.LANGUAGE);
		try {
			url = new URI(urlString);
		} catch (URISyntaxException e) {
			logger.error("Could not build Url :{}",ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException(e.getMessage(), "URI Build Failure Exception", urlString);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>("");
		return sitecoreRestUtil.getRestResponse(url, httpEntity);
	}

}