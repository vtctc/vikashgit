package com.dh.dxp.loyalty.util;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DHConstantUtils {

	private DHConstantUtils() {
	//private constructer	
	}
	
	public static final String BASE_PATH_LOYALTY = "/1.0/hospitality/loyalty/";
	public static final String FORM_TYPE = "application/x-www-form-urlencoded";
	public static final String JSON_FRMT = "application/json";
	public static final String CIPHER_TYPE = "AES/CBC/PKCS5Padding";
	public static final String CIPHER_ENCODING = "UTF-8";
	public static final String MEMBERSHIP_HEADER = "{\r\n\"MembershipNumber\":\"";
	public static final String PWD_HEADER = "\",\r\n\"Password\":\"";
	public static final String CLOSE_TEXT = "\"\r\n}\r\n";
	public static final String AUTH_TOKEN_STRING = "AuthorizationToken";

	public static final String SITECORE = "sitecore";
	public static final String ROUTE = "route";
	public static final String PLACEHOLDERS = "placeholders";
	public static final String TITLE = "Title";
	public static final String FIELDS = "fields";
	public static final String ITEMS = "items";
	public static final String CODE = "Code";
	public static final String VALUE = "value";
	public static final String DESCRIPTION = "Description";
	public static final String DISPLAY_NAME = "displayName";
	public static final String MASTER_CODE = "7B484309-4129-470C-97F4-8B68A02BD6A1";
	public static final String LANGUAGE = "english";
	public static final String SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS = "/sitecore/api/layout/render/jss?item=%7b{0}%7d&sc_apikey=%7b{1}%7d&sc_lang={2}";
	public static final String SITECORE_API_LAYOUT_RENDER_APIKEY = "F6C5544B-E2B3-47E4-B8C0-354B492A47C8";
	public static final String HOTEL_CODE = "Hotel Code";
	public static final String JSS_MAIN = "jss-main";
	public static final String HOTEL_ROOMS = "Hotel Rooms";
	public static final String ROOM_CODE = "Room Code";
	public static final String ROOM_TITLE = "Room Title";
	public static final String SHORT_DESCRIPTION = "Short Description";
	public static final String IMAGES = "Images";
	public static final String SOURCE = "src";
	public static final String ROOM_SIZE_ICON = "Room size icon";
	public static final String SQUARE_FEET = "Square Feet";
	public static final String SQUARE_METER = "Square Meter";
	public static final String IMAGE = "Image";
	public static final String RATE_TYPES = "Rate Types";
	public static final String TAGLINE = "Tagline";
	public static final String AMENITIES = "Amenities";
	public static final String ICON = "Icon";

}
