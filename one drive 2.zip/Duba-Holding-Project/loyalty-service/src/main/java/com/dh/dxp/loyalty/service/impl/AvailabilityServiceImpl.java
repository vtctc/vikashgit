package com.dh.dxp.loyalty.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.AvailabilityRequestBeans;
import com.dh.dxp.loyalty.beans.HotelRoomDetails;
import com.dh.dxp.loyalty.beans.MasterDataBeans;
import com.dh.dxp.loyalty.beans.RoomMapper;
import com.dh.dxp.loyalty.beans.RoomRateDetails;
import com.dh.dxp.loyalty.beans.RoomResponseDto;
import com.dh.dxp.loyalty.beans.RoomType;
import com.dh.dxp.loyalty.service.AvailabilityService;
import com.dh.dxp.loyalty.service.SitecoreHotelRoomDetails;
import com.dh.dxp.loyalty.service.SitecoreMasterDataService;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.ErrorCodes;
import com.dh.dxp.loyalty.util.SiriusRestUtil;

@Service
public class AvailabilityServiceImpl implements AvailabilityService {

	@Autowired
	private SiriusRestUtil restExchangeUtil;

	@Autowired
	private SitecoreMasterDataService sitecoreMasterService;

	@Autowired
	private SitecoreHotelRoomDetails hotelRoomDetailsService;

	@Value("#{'${ocs.availability.url}'}")
	private String availabilityUrl;

	private static final Logger logger = LogManager.getLogger(AvailabilityServiceImpl.class);

	public List<RoomResponseDto> getAvailability(AvailabilityRequestBeans availabilityRequestDto)
			throws SitecoreException, SiriusLoginException {
		String cmdId = availabilityRequestDto.getCmsId();
		String langId = availabilityRequestDto.getLangId();

		MasterDataBeans masterData = sitecoreMasterService.getMasterDataFromSitecore();
		HotelRoomDetails hotelRoomDetails = hotelRoomDetailsService.getHotelRoomDetailsFromSiteCore(cmdId, langId);

		String response = getOcsResponse(availabilityRequestDto);
		JsonNode rootNode = convertResponseToJson(response);
		Map<String, RoomMapper> roomResponseMap = processResponse(rootNode, hotelRoomDetails, masterData);
		return convertToResponseDto(roomResponseMap);
	}

	private Map<String, RoomMapper> processResponse(JsonNode rootNode, HotelRoomDetails hotelRoomDetails,
			MasterDataBeans masterData) {

		Map<String, RoomMapper> setterMap = new HashMap<>();

		for (JsonNode jsonRootArray : rootNode) {

			String awardCode = jsonRootArray.path("Award").path("AwardCode").asText();
			JsonNode roomStaysNode = jsonRootArray.path("RoomStays");
			Map<String, RoomMapper> roomDataMap = processRoomData(roomStaysNode, setterMap, awardCode, hotelRoomDetails,
					masterData);
			Map<String, RoomRateDetails> rateDescMap = processSiriusRateData(roomStaysNode);
			setterMap = processRateData(roomStaysNode, roomDataMap, rateDescMap);
		}
		return setterMap;

	}

	private JsonNode convertResponseToJson(String response) throws SitecoreException {
		ObjectMapper objectMapper = new ObjectMapper();
		logger.info("Convert and Process");
		try {
			return objectMapper.readTree(response);
		} catch (IOException e) {
			logger.error("An error occurred while converting response from Html to Json. ");
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException("An error occurred while converting response from Html to Json.",
					ErrorCodes.INTERNAL_SERVER_ERROR, "Parsing Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private Map<String, RoomRateDetails> processSiriusRateData(JsonNode roomStaysNode) {
		Map<String, RoomRateDetails> ratePlanMap = new HashMap<>();

		for (JsonNode ratesPlanNode : roomStaysNode.findValue("ratePlansField")) {
			RoomRateDetails rateDetails = new RoomRateDetails();
			rateDetails.setRatePlanDescription(
					ratesPlanNode.path("ratePlanDescriptionField").path("itemsField").findValue("valueField").asText());
			rateDetails.setRatePlanName(ratesPlanNode.path("ratePlanNameField").asText());
			ratePlanMap.put(ratesPlanNode.path("ratePlanCodeField").asText(), rateDetails);
		}
		return ratePlanMap;
	}

	private Map<String, RoomMapper> processRoomData(JsonNode roomStaysNode, Map<String, RoomMapper> setterMap,
			String awardCode, HotelRoomDetails hotelRoomDetails, MasterDataBeans masterData) {
		for (JsonNode roomTypesNode : roomStaysNode.findValue("roomTypesField")) {
			String roomCode = roomTypesNode.path("roomTypeCodeField").asText();

			if (!setterMap.containsKey(roomCode)) {
				RoomMapper roomDetails = new RoomMapper();
				roomDetails.setRoomDescription(roomTypesNode.findValue("roomTypeDescriptionField").path("itemsField")
						.findValue("valueField").asText());
				roomDetails.setNumberOfUnits(Integer.toString(roomTypesNode.findValue("numberOfUnitsField").asInt()));
				roomDetails.setRoomTypeCode(roomCode);
				roomDetails.setAwardCode(awardCode);
				roomDetails.setRoomLabels(masterData.getRoomLabels());
				roomDetails.setSpecialRequest(masterData.getSpecialRequest());
				Map<String, RoomRateDetails> ratePlanMap = new HashMap<>();
				roomDetails.setRatePlanMap(ratePlanMap);

				if (!hotelRoomDetails.getRoomTypeDetails().containsKey(roomCode)) {
					logger.error("The sitecore response does not contain room data for room Code : {}", roomCode);
					setterMap.put(roomCode, roomDetails);
				} else {
					RoomMapper updatedRoomDetails = setCmsRoomData(hotelRoomDetails, roomCode, roomDetails);
					setterMap.put(roomCode, updatedRoomDetails);
				}

			}
		}
		return setterMap;
	}

	private Map<String, RoomMapper> processRateData(JsonNode roomStaysNode, Map<String, RoomMapper> setterMap,
			Map<String, RoomRateDetails> rateDescMap) {
		for (JsonNode roomRatesNode : roomStaysNode.findValue("roomRatesField")) {
			String roomCode = roomRatesNode.path("roomTypeCodeField").asText();
			String ratePlanCode = roomRatesNode.path("ratePlanCodeField").asText();
			Long totalPointsField = roomRatesNode.path("totalPointsField").asLong();
			String totalPointsString = Long.toString(totalPointsField);

			if (!setterMap.containsKey(roomCode)) {
				logger.error("No room level data set for the room Code : {}", roomCode);
			} else {
				RoomMapper roomMap = setterMap.get(roomCode);
				RoomRateDetails rateDetailsBean = new RoomRateDetails();
				Map<String, RoomRateDetails> ratePlanMap = roomMap.getRatePlanMap();

				// Calculate the minimal points
				if (StringUtils.isEmpty(roomMap.getPriceInPoints())
						|| Long.parseLong(roomMap.getPriceInPoints()) > totalPointsField) {
					roomMap.setPriceInPoints(totalPointsString);
					setterMap.put(roomCode, roomMap);
				}

				if (rateDescMap.containsKey(ratePlanCode)) {
					rateDetailsBean.setRatePlanDescription(rateDescMap.get(ratePlanCode).getRatePlanDescription());
					rateDetailsBean.setRatePlanName(rateDescMap.get(ratePlanCode).getRatePlanName());
					rateDetailsBean.setRatePlanCode(ratePlanCode);
					rateDetailsBean.setPriceInPoints(totalPointsString);
				}

				// Put the sitecore Rate data to rate plan map at room level
				ratePlanMap.put(ratePlanCode, rateDetailsBean);
				// Put the rate object into the room mapper map object
				roomMap.setRatePlanMap(ratePlanMap);
				// Put the room mapper object for the key of room code
				setterMap.put(roomCode, roomMap);
			}
		}
		return setterMap;
	}

	private RoomMapper setCmsRoomData(HotelRoomDetails hotelRoomDetails, String roomCode, RoomMapper roomMap) {
		RoomType roomData = hotelRoomDetails.getRoomTypeDetails().get(roomCode);
		String description = roomData.getShortDescription();

		if (!description.isEmpty()) {
			roomMap.setRoomDescription(roomData.getShortDescription());
		}

		roomMap.setTitle(roomData.getTitle());
		roomMap.setImages(roomData.getImages());
		roomMap.setRoomArea(roomData.getRoomArea());
		return roomMap;
	}

	private String getOcsResponse(AvailabilityRequestBeans availabilityRequestDto)
			throws SiriusLoginException, SitecoreException {
		String token = availabilityRequestDto.getMemberToken();

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		header.set(DHConstantUtils.AUTH_TOKEN_STRING, token);
		HttpEntity<String> requestEntity = new HttpEntity<>(header);

		StringBuilder urlStringBuilder = new StringBuilder(availabilityUrl);
		urlStringBuilder.append(availabilityRequestDto.getMembershipNumber());
		urlStringBuilder.append("/");
		urlStringBuilder.append(availabilityRequestDto.getHotelCode());

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(urlStringBuilder.toString())
				.queryParam("startDate", availabilityRequestDto.getStartDate())
				.queryParam("endDate", availabilityRequestDto.getEndDate())
				.queryParam("numberOfRooms", availabilityRequestDto.getNumberOfRooms())
				.queryParam("Adults", availabilityRequestDto.getAdultsCount())
				.queryParam("children", availabilityRequestDto.getChildrenCount());

		StringBuilder finalQuery = new StringBuilder(builder.toUriString());

		return restExchangeUtil.getRestResponse(finalQuery, requestEntity);
	}

	private List<RoomResponseDto> convertToResponseDto(Map<String, RoomMapper> roomResponseMap) {
		List<RoomResponseDto> roomResponseList = new ArrayList<>();

		for (Map.Entry<String, RoomMapper> entry : roomResponseMap.entrySet()) {
			RoomResponseDto roomResponseDto = new RoomResponseDto();
			RoomMapper mapper = entry.getValue();
			roomResponseDto.setAwardCode(mapper.getAwardCode());
			roomResponseDto.setImages(mapper.getImages());
			roomResponseDto.setNumberOfUnits(mapper.getNumberOfUnits());
			roomResponseDto.setPriceInPoints(mapper.getPriceInPoints());
			roomResponseDto.setRoomArea(mapper.getRoomArea());
			roomResponseDto.setRoomDescription(mapper.getRoomDescription());
			roomResponseDto.setRoomName(mapper.getTitle());
			roomResponseDto.setRoomTypeCode(mapper.getRoomTypeCode());
			roomResponseDto.setRoomLabels(mapper.getRoomLabels());
			try {

				roomResponseDto
						.setRoomRateDetails(mapper.getRatePlanMap().values().stream().collect(Collectors.toList()));

				// Uncomment the below code if special request data is required
				/*
				 * List<SpecialRequestDTO> specialRequestList = new ArrayList<>(); for (String
				 * key : mapper.getSpecialRequest().keySet()) { SpecialRequestDTO specialRequest
				 * = new SpecialRequestDTO(); specialRequest.setSpecialRequestCode(key);
				 * specialRequest.setSpecialReqDescription(mapper.getSpecialRequest().get(key));
				 * specialRequestList.add(specialRequest); }
				 * 
				 * roomResponseDto.setSpecialDetailList(specialRequestList);
				 */
			} catch (NullPointerException e) {
				logger.error("Could not find any matching Rate plans for Room : {}", mapper.getRoomTypeCode());
			}

			roomResponseList.add(roomResponseDto);
		}
		return roomResponseList;
	}

}
