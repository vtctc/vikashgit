package com.dh.dxp.loyalty.util;

import java.net.ProxySelector;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.routing.HttpRoutePlanner;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.SystemDefaultRoutePlanner;
import org.apache.http.ssl.TrustStrategy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.SitecoreException;

@Service
public class RestTemplateConfig {

	@Autowired
	private Environment environment;

	private static final Logger logger = LogManager.getLogger(RestTemplateConfig.class);

	public RestTemplate getRestTemplate() throws SitecoreException {

		if (Arrays.stream(environment.getActiveProfiles())
				.anyMatch(env -> (env.equalsIgnoreCase("local") || (env.equalsIgnoreCase("dev"))))) {
			try {

				TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

				SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
						.loadTrustMaterial(null, acceptingTrustStrategy).build();

				SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
				HttpRoutePlanner routePlanner = new SystemDefaultRoutePlanner(ProxySelector.getDefault());
				CloseableHttpClient httpClient = HttpClientBuilder.create().setRoutePlanner(routePlanner)
						.setSSLSocketFactory(csf).build();

				HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
				requestFactory.setConnectionRequestTimeout(0);
				requestFactory.setHttpClient(httpClient);
				RestTemplate restTemplate = new RestTemplate(requestFactory);
				restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(httpClient));
				logger.info("SSL verify disabled.");
				return restTemplate;
			} catch (Exception e) {
				logger.error("Failed to create Rest template");
				throw new SitecoreException("An error Occurred in creating the Rest template",ErrorCodes.INTERNAL_SERVER_ERROR,"Error in creating Rest template",HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return new RestTemplate();

	}
}
