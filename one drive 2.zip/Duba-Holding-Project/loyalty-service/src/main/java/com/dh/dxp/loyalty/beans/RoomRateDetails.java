package com.dh.dxp.loyalty.beans;

public class RoomRateDetails {
	private String priceInPoints;
	private String ratePlanCode;
	private String ratePlanName;
	private String ratePlanDescription;

	public String getRatePlanName() {
		return ratePlanName;
	}

	public void setRatePlanName(String ratePlanName) {
		this.ratePlanName = ratePlanName;
	}

	public String getPriceInPoints() {
		return priceInPoints;
	}

	public void setPriceInPoints(String priceInPoints) {
		this.priceInPoints = priceInPoints;
	}

	public String getRatePlanCode() {
		return ratePlanCode;
	}

	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	public String getRatePlanDescription() {
		return ratePlanDescription;
	}

	public void setRatePlanDescription(String ratePlanDescription) {
		this.ratePlanDescription = ratePlanDescription;
	}

}
