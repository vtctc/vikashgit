package com.dh.dxp.loyalty.beans;

public class SpecialRequestDTO {

	private String specialRequestCode;
	private String specialReqDescription;

	public String getSpecialRequestCode() {
		return specialRequestCode;
	}

	public void setSpecialRequestCode(String specialRequestCode) {
		this.specialRequestCode = specialRequestCode;
	}

	public String getSpecialReqDescription() {
		return specialReqDescription;
	}

	public void setSpecialReqDescription(String specialReqDescription) {
		this.specialReqDescription = specialReqDescription;
	}

}
