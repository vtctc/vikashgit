package com.dh.dxp.loyalty.beans;

public class PointsDetails {

	private String currentPoints;
	private String total;
	private String baseStay;

	public PointsDetails() {
		super();
	}

	public String getCurrentPoints() {
		return currentPoints;
	}

	public void setCurrentPoints(String currentPoints) {
		this.currentPoints = currentPoints;
	}

	public String getTotal() {

		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getBaseStay() {
		return baseStay;
	}

	public void setBaseStay(String baseStay) {
		this.baseStay = baseStay;
	}

}
