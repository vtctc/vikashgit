package com.dh.dxp.loyalty.util;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.SitecoreException;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class SitecoreRestUtil {

	private static final Logger logger = LogManager.getLogger(SitecoreRestUtil.class);

	@Value("#{'${sitecore.domain}'}")
	private String sitecoreDomainUrl;

	private static final String SITECORE_API_CMS_ROOM_RENDER = "sitecore_room_render";
	
	private static final long SITECORE_API_LAYOUT_RENDER_TTL = (long) 4 * 60 * 60 * 1000;

	@Cacheable(value = SITECORE_API_CMS_ROOM_RENDER, key = "#hotelCMSId+':'+#language")
	public JsonNode getDataFromSitecore(String hotelCMSId, String languageId) throws SitecoreException {

		URI url = null;
		StringBuilder urlBuilder = new StringBuilder((sitecoreDomainUrl));

		String urlString = urlBuilder.append(DHConstantUtils.SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS).toString()
				.replace("{0}", hotelCMSId).replace("{1}", DHConstantUtils.SITECORE_API_LAYOUT_RENDER_APIKEY)
				.replace("{2}", languageId);
		try {
			url = new URI(urlString);
		} catch (URISyntaxException e) {
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException(e.getMessage(), "URI Build Failure Exception", urlString);
		}
		HttpEntity<String> httpEntity = new HttpEntity<>("");
		return getRestResponse(url, httpEntity);
	}

	public JsonNode getRestResponse(URI url, HttpEntity<String> requestEntity) throws SitecoreException {

		ResponseEntity<JsonNode> response = null;
		try {
			logger.info("Final url for get  : {}", url.toString());

			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, JsonNode.class);

			if (response.getStatusCode() == HttpStatus.OK) {
				return response.getBody();
			} else {
				throw new SitecoreException("Could not connect to Sitecore", "INTERNAL_SERVER_ERROR", url.toString(),
						response.getStatusCode());
			}

		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
				logger.error("Could not find Requested Resource in Sitecore!");
				throw new SitecoreException("Could not find Requested Resource in Sitecore!", ErrorCodes.NOT_FOUND,
						url.toString(), HttpStatus.NOT_FOUND);
			} else {
				logger.error(ExceptionUtils.getFullStackTrace(e));
				throw new SitecoreException("Something went wrong!", ErrorCodes.INTERNAL_SERVER_ERROR, url.toString(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException("Something went wrong!", ErrorCodes.INTERNAL_SERVER_ERROR, url.toString(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CacheEvict(allEntries = true, cacheNames = { SITECORE_API_CMS_ROOM_RENDER })
	@Scheduled(fixedDelay = SITECORE_API_LAYOUT_RENDER_TTL)
	public boolean sitecoreApiLayoutRenderCacheEvict() {
		logger.info("Cache is getting flushed-------");
		return true;
	}
}
