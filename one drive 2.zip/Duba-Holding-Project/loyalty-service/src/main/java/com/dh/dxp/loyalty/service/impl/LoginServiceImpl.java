package com.dh.dxp.loyalty.service.impl;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.LoginResponseBeans;
import com.dh.dxp.loyalty.beans.PointsDetails;
import com.dh.dxp.loyalty.beans.UserProfileBeans;
import com.dh.dxp.loyalty.service.LoginService;
import com.dh.dxp.loyalty.service.PointService;
import com.dh.dxp.loyalty.service.ProfileService;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.ErrorCodes;
import com.dh.dxp.loyalty.util.RestTemplateConfig;
import com.dh.dxp.loyalty.util.SiriusAESEncrypter;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private RestTemplateConfig restTemplate;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private PointService pointService;

	@Autowired
	private SiriusAESEncrypter encrypter;

	@Value("#{'${ocs.membership.url}'}")
	private String url;

	private static final Logger logger = LogManager.getLogger(LoginServiceImpl.class);

	public LoginResponseBeans login(String membershipNumber, String password)
			throws SiriusLoginException,SitecoreException {

		if (membershipNumber.isEmpty() || password.isEmpty()) {
			throw new SiriusLoginException("Membership number and password cannot be empty!",ErrorCodes.INVALID_SIRIUS_LOGIN);
		}

		LoginResponseBeans response = sendOCSRequest(membershipNumber, password);
		UserProfileBeans userProfile = profileService.getProfile(response.getToken(), membershipNumber);

		response.setCurrentPoint(userProfile.getCurrentPoint());
		response.setFirstName(userProfile.getFirstName());
		response.setLastName(userProfile.getLastName());
		response.setMembershipId(userProfile.getMembershipId());
		response.setMembershipLevel(userProfile.getMembershipLevel());

		PointsDetails pointsDetails = pointService.getPointsDetails(response.getToken(), membershipNumber);
		response.setTierPoint(pointsDetails.getBaseStay());
		return response;
	}

	private LoginResponseBeans sendOCSRequest(String membershipNumber, String password)
			throws SiriusLoginException, SitecoreException {
		StringBuilder requestBody = new StringBuilder(DHConstantUtils.MEMBERSHIP_HEADER);
		requestBody.append(membershipNumber);
		requestBody.append(DHConstantUtils.PWD_HEADER);
		String encryptedPassword = encrypter.createEncryptedString(password, membershipNumber);
		requestBody.append(encryptedPassword);
		requestBody.append(DHConstantUtils.CLOSE_TEXT);

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> requestEntity = new HttpEntity<>(requestBody.toString(), header);
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.getRestTemplate().exchange(url, HttpMethod.POST, requestEntity, String.class);
			if (response.getStatusCode() == HttpStatus.OK) {
				LoginResponseBeans loginResponse = new LoginResponseBeans();
				loginResponse.setToken(response.getHeaders().get("AuthorizationToken").get(0));
				return loginResponse;
			} else {
				throw new SiriusLoginException("Could not connect to Sirius",ErrorCodes.INTERNAL_SERVER_ERROR);
			}

		} catch (HttpClientErrorException e) {
			logger.error(e);
			if (e.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				logger.error("Invalid credentials");
				throw new SiriusLoginException("Invalid Sirius Credentials", ErrorCodes.INVALID_SIRIUS_LOGIN);
			} else if (e.getStatusCode().equals(HttpStatus.LOCKED)) {
				logger.error("Account is locked");
				throw new SiriusLoginException("Account is Locked", ErrorCodes.ACCOUNT_LOCKED);
			}
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException("Could not connect to Sirius server.",ErrorCodes.INTERNAL_SERVER_ERROR,url,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
