package com.dh.dxp.loyalty.util;

public class ErrorCodes {
	
	private ErrorCodes() {
		//Private constructor
	}
	public static final String INVALID_SIRIUS_LOGIN = "INVALID_SIRIUS_LOGIN";
	public static final String ACCOUNT_LOCKED = "ACCOUNT_LOCKED";
	public static final String NOT_FOUND = "NOT_FOUND_SIRIUS";
	public static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
}
