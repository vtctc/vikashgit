package com.dh.dxp.loyalty.service.impl;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.UserProfileBeans;
import com.dh.dxp.loyalty.service.ProfileService;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.SiriusRestUtil;

@Service
public class ProfileServiceImpl implements ProfileService {

	@Value("#{'${ocs.profile.url}'}")
	private String url;

	@Autowired
	private SiriusRestUtil restExchange;

	private static final Logger logger = LogManager.getLogger(ProfileServiceImpl.class);

	@Override
	public UserProfileBeans getProfile(String token, String membershipNumber)
			throws SiriusLoginException, SitecoreException {

		StringBuilder urlAppender = new StringBuilder(url);
		urlAppender.append(membershipNumber);
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		header.set(DHConstantUtils.AUTH_TOKEN_STRING, token);
		HttpEntity<String> requestEntity = new HttpEntity<String>(header);

		String profileResponse = restExchange.getRestResponse(urlAppender, requestEntity);
		UserProfileBeans profileData = new UserProfileBeans();
		try {
			profileData = processJsonNode(profileResponse);
			profileData.setMembershipId(membershipNumber);
		} catch (JsonProcessingException e) {
			logger.error("Could not process Response string as Json node.");
		} catch (IOException e) {
			logger.error("Could not process Response string as Json node.");
		}
		return profileData;
	}

	private UserProfileBeans processJsonNode(String profileResponse) throws JsonProcessingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode rootNode = objectMapper.readTree(profileResponse);

		UserProfileBeans userProfileBeans = new UserProfileBeans();
		userProfileBeans.setCurrentPoint(Long.toString(rootNode.path("Membership").path("CurrentPoints").asLong()));
		userProfileBeans.setFirstName(rootNode.path("FirstName").asText());
		userProfileBeans.setLastName(rootNode.path("LastName").asText());
		userProfileBeans.setMembershipLevel(rootNode.path("Membership").path("Level").asText());
		return userProfileBeans;
	}

}
