package com.dh.dxp.loyalty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.AvailabilityRequestBeans;
import com.dh.dxp.loyalty.beans.LoginResponseBeans;
import com.dh.dxp.loyalty.beans.RoomResponseDto;
import com.dh.dxp.loyalty.service.AvailabilityService;
import com.dh.dxp.loyalty.service.LoginService;
import com.dh.dxp.loyalty.util.DHConstantUtils;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = DHConstantUtils.BASE_PATH_LOYALTY)
@ApiOperation(value = "Loyalty login and points", response = ResponseEntity.class)
public class OcsController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private AvailabilityService availabilityService;

	@RequestMapping(value = "login", method = RequestMethod.POST, consumes = DHConstantUtils.FORM_TYPE, produces = DHConstantUtils.JSON_FRMT)
	public ResponseEntity<LoginResponseBeans> siriusLogin(@RequestParam String membershipNumber,
			@RequestParam String password) throws SitecoreException, SiriusLoginException {
		
		return new ResponseEntity<>(loginService.login(membershipNumber, password),
				HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "availability", method = RequestMethod.POST, consumes = DHConstantUtils.JSON_FRMT, produces = DHConstantUtils.JSON_FRMT)
	public ResponseEntity<List<RoomResponseDto>> getAvailability(
			@RequestBody AvailabilityRequestBeans availabilityRequestDto)
			throws SitecoreException, SiriusLoginException {
		return new ResponseEntity<>(availabilityService.getAvailability(availabilityRequestDto),
				HttpStatus.ACCEPTED);
	}
}
