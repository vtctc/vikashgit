package com.dh.dxp.loyalty.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.loyalty.beans.SirusHotelReservationRQ;
import com.dh.dxp.loyalty.service.SirusBookingService;
import com.dh.dxp.loyalty.util.ErrorCodes;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class SirusHotelServiceImpl implements SirusBookingService {
	@Autowired
	private RestTemplate restTemplate;

	@Value("#{'${ocs.profile.url}'}")
	private String url;

	private static final Logger logger = LogManager.getLogger(SirusHotelServiceImpl.class);

	@Override
	public Map<String, String> bookingProcess(SirusHotelReservationRQ reservationRQ)
			throws DHGlobalException, IOException {
		StringBuilder urlAppender = new StringBuilder(url);
		urlAppender.append(reservationRQ.getMembershipNumber());
		urlAppender.append("/stay");

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		header.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		header.set("AuthorizationToken", reservationRQ.getMemberToken());

		MultiValueMap<String, String> mvp = new LinkedMultiValueMap<>();
		mvp.add("Adults", reservationRQ.getAdultsCount());
		mvp.add("Rooms", reservationRQ.getNumberOfRooms());
		mvp.add("Start", reservationRQ.getStartDate());
		mvp.add("End", reservationRQ.getEndDate());
		mvp.add("Hotel", reservationRQ.getHotelCode());
		mvp.add("RatePlanCode", reservationRQ.getRatePlanCode());
		mvp.add("RoomTypeCode", reservationRQ.getRoomTypeCode());
		mvp.add("AwardType", reservationRQ.getAwardType());
		logger.info("request {}", mvp);
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(mvp, header);

		ResponseEntity<String> response = null;
		try {
			logger.info("endpoint for sirus booking{}", urlAppender.toString());
			response = restTemplate.exchange(urlAppender.toString(), HttpMethod.POST, request, String.class);
			Map<String, String> responseMap = new HashMap<>();
			if (response.getStatusCode() == HttpStatus.OK) {
				ObjectMapper objectMapper = new ObjectMapper();
				JsonNode responseNode = objectMapper.readTree(response.getBody());
				JsonNode resvnList = responseNode.findPath("uniqueIDListField");
				for (JsonNode jsonNode : resvnList) {
					if (!jsonNode.path("sourceField").asText().equals("RESVID")) {
						responseMap.put("confirmationID", jsonNode.path("valueField").asText());
					}
				}
				return responseMap;
			} else {
				throw new DHGlobalException("Could not connect to Sirius");
			}

		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				throw new SiriusLoginException("Invalid Sirius Credentials", ErrorCodes.INVALID_SIRIUS_LOGIN);
			} else if (e.getStatusCode().equals(HttpStatus.LOCKED)) {
				throw new SiriusLoginException("Account is Locked", ErrorCodes.ACCOUNT_LOCKED);
			}
			throw new DHGlobalException("Could not connect to Sirius server.");
		}

	}

}
