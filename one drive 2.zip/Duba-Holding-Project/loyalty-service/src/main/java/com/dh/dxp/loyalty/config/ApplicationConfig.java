package com.dh.dxp.loyalty.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
@Configuration
public class ApplicationConfig implements WebMvcConfigurer {

	private static final Logger logger = LogManager.getLogger(ApplicationConfig.class);

	private String responseHeader = "Response_Token";
	private String mdcTokenKey = "request-Id";
	private String requestHeader = "request-Id";

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		logger.info("******Cross Origin*****");
		registry.addMapping("/**").allowedOrigins("*").allowedMethods("POST", "GET", "PUT", "OPTIONS", "DELETE");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public FilterRegistrationBean servletRegistrationBean() {
		final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		final MdcLogEnhancerFilter log4jMDCFilterFilter = new MdcLogEnhancerFilter(responseHeader, mdcTokenKey,
				requestHeader);
		registrationBean.setFilter(log4jMDCFilterFilter);
		registrationBean.setOrder(2);
		return registrationBean;
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
