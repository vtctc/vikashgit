package com.dh.dxp.loyalty.beans;

public class UserProfileBeans {
	private String firstName;
	private String lastName;
	private String membershipId;
	private String currentPoint;
	private String membershipLevel;
	private String pointsToNextLevel;
	private String tierPoint;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMembershipId() {
		return membershipId;
	}

	public void setMembershipId(String membershipId) {
		this.membershipId = membershipId;
	}

	public String getCurrentPoint() {
		return currentPoint;
	}

	public void setCurrentPoint(String currentPoint) {
		this.currentPoint = currentPoint;
	}

	public String getMembershipLevel() {
		return membershipLevel;
	}

	public void setMembershipLevel(String membershipLevel) {
		this.membershipLevel = membershipLevel;
	}

	public String getPointsToNextLevel() {
		return pointsToNextLevel;
	}

	public void setPointsToNextLevel(String pointsToNextLevel) {
		this.pointsToNextLevel = pointsToNextLevel;
	}

	public String getTierPoint() {
		return tierPoint;
	}

	public void setTierPoint(String tierPoint) {
		this.tierPoint = tierPoint;
	}
}
