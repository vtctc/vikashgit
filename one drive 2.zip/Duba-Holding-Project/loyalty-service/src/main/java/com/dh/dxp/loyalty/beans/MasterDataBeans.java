package com.dh.dxp.loyalty.beans;

import java.util.Map;

public class MasterDataBeans {

	private Map<String, String> bedPreferences; // Map of type <bedTypeCode, bedDescription> 
	private Map<String, String> cancellationPolicy; // Map of type <cancellationCode, description> 
	private Map<String, String> specialRequest; // Map of type <specialRequestCode, specialReqTitle> 
	private Map<String, TaxDetails> taxDetails; // Map of type <taxCode, taxDescription> 
	private Map<String, String> roomLabels;

	public Map<String, String> getRoomLabels() {
		return roomLabels;
	}

	public void setRoomLabels(Map<String, String> roomLabels) {
		this.roomLabels = roomLabels;
	}

	public Map<String, String> getBedPreferences() {
		return bedPreferences;
	}

	public void setBedPreferences(Map<String, String> bedPreferences) {
		this.bedPreferences = bedPreferences;
	}

	public Map<String, String> getCancellationPolicy() {
		return cancellationPolicy;
	}

	public void setCancellationPolicy(Map<String, String> cancellationPolicy) {
		this.cancellationPolicy = cancellationPolicy;
	}

	public Map<String, String> getSpecialRequest() {
		return specialRequest;
	}

	public void setSpecialRequest(Map<String, String> specialRequest) {
		this.specialRequest = specialRequest;
	}

	public Map<String, TaxDetails> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(Map<String, TaxDetails> taxDetails) {
		this.taxDetails = taxDetails;
	}

}
