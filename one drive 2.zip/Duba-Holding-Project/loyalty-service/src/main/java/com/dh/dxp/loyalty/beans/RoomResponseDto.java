package com.dh.dxp.loyalty.beans;

import java.util.List;
import java.util.Map;

public class RoomResponseDto {

	private String roomName;
	private String roomDescription;
	private String roomTypeCode;
	private String priceInPoints;
	private String numberOfUnits;
	private List<String> images;
	private List<RoomRateDetails> roomRateDetails;
	private AreaDescriptionDTO roomArea;
	private String awardCode;

	private List<SpecialRequestDTO> specialDetailList;
	private Map<String, String> roomLabels;

	public String getAwardCode() {
		return awardCode;
	}

	public void setAwardCode(String awardCode) {
		this.awardCode = awardCode;
	}

	public Map<String, String> getRoomLabels() {
		return roomLabels;
	}

	public void setRoomLabels(Map<String, String> roomLabels) {
		this.roomLabels = roomLabels;
	}

	public List<SpecialRequestDTO> getSpecialDetailList() {
		return specialDetailList;
	}

	public void setSpecialDetailList(List<SpecialRequestDTO> specialDetailList) {
		this.specialDetailList = specialDetailList;
	}

	public AreaDescriptionDTO getRoomArea() {
		return roomArea;
	}

	public void setRoomArea(AreaDescriptionDTO roomArea) {
		this.roomArea = roomArea;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getRoomDescription() {
		return roomDescription;
	}

	public void setRoomDescription(String roomDescription) {
		this.roomDescription = roomDescription;
	}

	public String getNumberOfUnits() {
		return numberOfUnits;
	}

	public void setNumberOfUnits(String numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public List<RoomRateDetails> getRoomRateDetails() {
		return roomRateDetails;
	}

	public void setRoomRateDetails(List<RoomRateDetails> roomRateDetails) {
		this.roomRateDetails = roomRateDetails;
	}

	public String getPriceInPoints() {
		return priceInPoints;
	}

	public void setPriceInPoints(String priceInPoints) {
		this.priceInPoints = priceInPoints;
	}

}
