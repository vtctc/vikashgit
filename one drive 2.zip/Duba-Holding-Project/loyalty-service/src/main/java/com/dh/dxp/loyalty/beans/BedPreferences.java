package com.dh.dxp.loyalty.beans;

public class BedPreferences {

	private String bedTypeCode;
	private String bedDecription;

	public String getBedTypeCode() {
		return bedTypeCode;
	}

	public void setBedTypeCode(String bedTypeCode) {
		this.bedTypeCode = bedTypeCode;
	}

	public String getBedDecription() {
		return bedDecription;
	}

	public void setBedDecription(String bedDecription) {
		this.bedDecription = bedDecription;
	}

}
