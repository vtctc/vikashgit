package com.dh.dxp.loyalty.beans;

import java.util.Map;

public class RoomRateBean {

	private Map<String, RateTypeBean> rateTypeMap; // Map of type <RoomCode, RateTypeBean>

	public Map<String, RateTypeBean> getRateTypeMap() {
		return rateTypeMap;
	}

	public void setRateTypeMap(Map<String, RateTypeBean> rateTypeMap) {
		this.rateTypeMap = rateTypeMap;
	}
}