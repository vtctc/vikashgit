package com.dh.dxp.loyalty.util;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;

@Service
public class SiriusRestUtil {

	private static final Logger logger = LogManager.getLogger(SiriusRestUtil.class);

	public String getRestResponse(StringBuilder url, HttpEntity<String> requestEntity)
			throws SiriusLoginException, SitecoreException {

		ResponseEntity<String> response = null;
		try {
			logger.info("Final url for get  : {}", url.toString());

			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.exchange(url.toString(), HttpMethod.GET, requestEntity, String.class);

			if (response.getStatusCode() == HttpStatus.OK) {
				return response.getBody();
			} else {
				logger.error("The request to url {} returned a response {}", url.toString(), response.getStatusCode());
				throw new SitecoreException("Could not connect to Sirius", ErrorCodes.INTERNAL_SERVER_ERROR,
						url.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				logger.error("Invalid credentials or Token");
				throw new SiriusLoginException("Invalid Sirius Credentials", ErrorCodes.INVALID_SIRIUS_LOGIN);
			} else if (e.getStatusCode().equals(HttpStatus.LOCKED)) {
				logger.error("Account is locked");
				throw new SiriusLoginException("Account is Locked", ErrorCodes.ACCOUNT_LOCKED);
			} else if (e.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
				logger.error("Could not find Requested Resource in OCIS!");
				throw new SitecoreException("Could not find Requested Resource in OCIS!", ErrorCodes.NOT_FOUND,
						url.toString(), HttpStatus.NOT_FOUND);
			}
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException("Could not connect to Sirius server.", ErrorCodes.INTERNAL_SERVER_ERROR,
					url.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			logger.error("An error occurred in connecting to Sirius.");
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SitecoreException("Could not connect to Sirius server.", ErrorCodes.INTERNAL_SERVER_ERROR,
					url.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}
