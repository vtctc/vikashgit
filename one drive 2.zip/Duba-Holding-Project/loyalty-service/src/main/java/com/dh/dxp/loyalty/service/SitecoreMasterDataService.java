package com.dh.dxp.loyalty.service;

import org.springframework.stereotype.Component;

import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.MasterDataBeans;

@Component
public interface SitecoreMasterDataService {
	public MasterDataBeans getMasterDataFromSitecore() throws SitecoreException;
}