package com.dh.dxp.loyalty.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.AvailabilityRequestBeans;
import com.dh.dxp.loyalty.beans.RoomResponseDto;

@Component
public interface AvailabilityService {
	public List<RoomResponseDto> getAvailability(AvailabilityRequestBeans availabilityRequestDto)
			throws SitecoreException, SiriusLoginException;
}
