package com.dh.dxp.loyalty.beans;

import java.util.List;

public class RoomType {

	private String title;
	private String shortDescription;
	private List<String> images;
	private AreaDescriptionDTO roomArea;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public AreaDescriptionDTO getRoomArea() {
		return roomArea;
	}

	public void setRoomArea(AreaDescriptionDTO roomArea) {
		this.roomArea = roomArea;
	}

}
