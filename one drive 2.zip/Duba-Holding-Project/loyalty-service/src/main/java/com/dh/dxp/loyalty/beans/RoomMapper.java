package com.dh.dxp.loyalty.beans;

import java.util.List;
import java.util.Map;

public class RoomMapper {
	private String roomTypeCode;
	private String roomDescription;
	private String priceInPoints;
	private List<String> images;
	private Map<String, RoomRateDetails> ratePlanMap;
	private AreaDescriptionDTO roomArea;
	private String title;
	private String awardCode;
	private String numberOfUnits;
	private Map<String, String> roomLabels;
	private Map<String, String> specialRequest;

	public Map<String, String> getSpecialRequest() {
		return specialRequest;
	}

	public void setSpecialRequest(Map<String, String> specialRequest) {
		this.specialRequest = specialRequest;
	}

	public Map<String, String> getRoomLabels() {
		return roomLabels;
	}

	public void setRoomLabels(Map<String, String> roomLabels) {
		this.roomLabels = roomLabels;
	}

	public String getNumberOfUnits() {
		return numberOfUnits;
	}

	public void setNumberOfUnits(String numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}

	public String getAwardCode() {
		return awardCode;
	}

	public void setAwardCode(String awardCode) {
		this.awardCode = awardCode;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public AreaDescriptionDTO getRoomArea() {
		return roomArea;
	}

	public void setRoomArea(AreaDescriptionDTO roomArea) {
		this.roomArea = roomArea;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPriceInPoints() {
		return priceInPoints;
	}

	public void setPriceInPoints(String priceInPoints) {
		this.priceInPoints = priceInPoints;
	}

	public Map<String, RoomRateDetails> getRatePlanMap() {
		return ratePlanMap;
	}

	public void setRatePlanMap(Map<String, RoomRateDetails> ratePlanMap) {
		this.ratePlanMap = ratePlanMap;
	}

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public String getRoomDescription() {
		return roomDescription;
	}

	public void setRoomDescription(String roomDescription) {
		this.roomDescription = roomDescription;
	}

}
