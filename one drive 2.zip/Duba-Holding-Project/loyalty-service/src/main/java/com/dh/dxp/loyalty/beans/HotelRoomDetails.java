package com.dh.dxp.loyalty.beans;

import java.util.Map;

public class HotelRoomDetails {

	private String hotelCode;
	
	// Map of type <RoomCode, RoomType> 
	private Map<String, RoomType> roomTypeDetails; 

	public String getHotelCode() {
		return hotelCode;
	}

	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	public Map<String, RoomType> getRoomTypeDetails() {
		return roomTypeDetails;
	}

	public void setRoomTypeDetails(Map<String, RoomType> roomTypeDetails) {
		this.roomTypeDetails = roomTypeDetails;
	}

}