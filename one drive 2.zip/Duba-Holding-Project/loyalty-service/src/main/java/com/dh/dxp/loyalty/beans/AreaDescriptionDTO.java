package com.dh.dxp.loyalty.beans;

public class AreaDescriptionDTO {
	private String squareFeet;
	private String squareMeter;
	private String icon;

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getSquareMeter() {
		return squareMeter;
	}

	public void setSquareMeter(String squareMeter) {
		this.squareMeter = squareMeter;
	}

	public String getSquareFeet() {
		return squareFeet;
	}

	public void setSquareFeet(String squareFeet) {
		this.squareFeet = squareFeet;
	}
}
