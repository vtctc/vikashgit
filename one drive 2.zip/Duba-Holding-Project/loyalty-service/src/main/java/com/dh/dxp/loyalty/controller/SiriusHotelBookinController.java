package com.dh.dxp.loyalty.controller;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.loyalty.beans.SirusHotelReservationRQ;
import com.dh.dxp.loyalty.service.SirusBookingService;
import com.dh.dxp.loyalty.util.DHConstantUtils;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = DHConstantUtils.BASE_PATH_LOYALTY)
@ApiOperation(value = "Loyalty booking with points", response = ResponseEntity.class)
public class SiriusHotelBookinController {
	private static final Logger logger = LogManager.getLogger(SiriusHotelBookinController.class);
	@Autowired
	SirusBookingService sirusBookingService;

	@PostMapping(value = "sirius_reservations")
	public Map<String, String> createSirusReservation(@RequestBody SirusHotelReservationRQ sirusHotelReservationRQ) throws DHGlobalException, IOException {
	logger.info("reservation request:{}",sirusHotelReservationRQ);
		return sirusBookingService.bookingProcess(sirusHotelReservationRQ);

	}
}
