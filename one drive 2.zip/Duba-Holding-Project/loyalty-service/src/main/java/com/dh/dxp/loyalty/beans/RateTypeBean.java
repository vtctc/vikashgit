package com.dh.dxp.loyalty.beans;

import java.util.Map;

public class RateTypeBean {

	// Map of type RatePlanCode, RoomRateDetails
	private Map<String, RoomRateDetails> rateDetailsMap; 

	public Map<String, RoomRateDetails> getRateDetailsMap() {
		return rateDetailsMap;
	}

	public void setRateDetailsMap(Map<String, RoomRateDetails> rateDetailsMap) {
		this.rateDetailsMap = rateDetailsMap;
	}
}