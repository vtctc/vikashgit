package com.dh.dxp.loyalty.util;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.StringUtils;

@Service
public class SiriusAESEncrypter {

	@Value("#{'${ocs.key}'}")
	private String key;

	private static final Logger logger = LogManager.getLogger(SiriusAESEncrypter.class);

	public String createEncryptedString(String toEncrypt, String reference) throws SiriusLoginException {
		try {
			String salt = key + reference;
			String paddedSalt = StringUtils.rightPad(salt, 32);
			String paddedRef = StringUtils.rightPad(reference, 16);
			Cipher cipher = Cipher.getInstance(DHConstantUtils.CIPHER_TYPE);
			String paddedSaltSubStr = paddedSalt.substring(0, 32);
			String paddedRefSubStr = paddedRef.substring(0, 16);

			byte[] keyStream = paddedSaltSubStr.getBytes(DHConstantUtils.CIPHER_ENCODING);
			SecretKeySpec secretKey = new SecretKeySpec(keyStream, "AES");

			IvParameterSpec ivparameterspec = new IvParameterSpec(
					paddedRefSubStr.getBytes(DHConstantUtils.CIPHER_ENCODING));
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivparameterspec);
			byte[] cipherText = cipher.doFinal(toEncrypt.getBytes(DHConstantUtils.CIPHER_ENCODING));
			Base64.Encoder encoder = Base64.getEncoder();

			return encoder.encodeToString(cipherText);

		} catch (Exception e) {
			logger.error("Data encryption failed : {} ", e.getMessage());
			logger.error(ExceptionUtils.getFullStackTrace(e));
			throw new SiriusLoginException("Data Encryption failed ", ErrorCodes.INTERNAL_SERVER_ERROR);
		}
	}
}
