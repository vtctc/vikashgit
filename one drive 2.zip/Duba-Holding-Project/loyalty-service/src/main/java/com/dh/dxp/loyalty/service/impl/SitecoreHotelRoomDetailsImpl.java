package com.dh.dxp.loyalty.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.AreaDescriptionDTO;
import com.dh.dxp.loyalty.beans.HotelRoomDetails;
import com.dh.dxp.loyalty.beans.RoomType;
import com.dh.dxp.loyalty.service.SitecoreHotelRoomDetails;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.SitecoreRestUtil;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class SitecoreHotelRoomDetailsImpl implements SitecoreHotelRoomDetails {

	@Autowired
	private SitecoreRestUtil sitecoreRestExchange;

	private static final Logger logger = LogManager.getLogger(SitecoreMasterDataImpl.class);

	public HotelRoomDetails getHotelRoomDetailsFromSiteCore(String hotelCMSId, String languageId)
			throws SitecoreException {
		logger.info("Getting hotel room details from sitecore.");

		if (languageId.isEmpty()) {
			languageId = "en";
		}

		HotelRoomDetails roomDetails = new HotelRoomDetails();
		JsonNode roomDetailsNode = sitecoreRestExchange.getDataFromSitecore(hotelCMSId, languageId);
		roomDetails.setHotelCode(
				roomDetailsNode.path(DHConstantUtils.SITECORE).path(DHConstantUtils.ROUTE).path(DHConstantUtils.FIELDS)
						.path(DHConstantUtils.HOTEL_CODE).findValue(DHConstantUtils.VALUE).asText());
		JsonNode hotelRoomsNode = roomDetailsNode.path(DHConstantUtils.SITECORE).path(DHConstantUtils.ROUTE)
				.path(DHConstantUtils.PLACEHOLDERS).findPath(DHConstantUtils.JSS_MAIN)
				.findValue(DHConstantUtils.HOTEL_ROOMS);
		Map<String, RoomType> roomTypeMap = getRoomTypeMap(hotelRoomsNode);
		roomDetails.setRoomTypeDetails(roomTypeMap);

		return roomDetails;
	}

	private Map<String, RoomType> getRoomTypeMap(JsonNode hotelRoomsNode) {

		Map<String, RoomType> roomTypeMap = new HashMap<>();
		for (JsonNode hotelRoom : hotelRoomsNode) {
			String roomCode = hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.ROOM_CODE)
					.findValue(DHConstantUtils.VALUE).asText();
			RoomType roomType = getRoomTypeObject(hotelRoom);
			roomTypeMap.put(roomCode, roomType);
		}

		return roomTypeMap;
	}

	private RoomType getRoomTypeObject(JsonNode hotelRoom) {
		RoomType roomType = new RoomType();

		roomType.setTitle(hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.ROOM_TITLE)
				.findValue(DHConstantUtils.VALUE).asText());
		roomType.setShortDescription(hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.SHORT_DESCRIPTION)
				.findValue(DHConstantUtils.VALUE).asText());

		List<String> images = getImagesList(hotelRoom.path(DHConstantUtils.FIELDS).findValue(DHConstantUtils.IMAGES));
		roomType.setImages(images);

		AreaDescriptionDTO roomArea = new AreaDescriptionDTO();
		roomArea.setIcon(hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.ROOM_SIZE_ICON)
				.path(DHConstantUtils.VALUE).findValue(DHConstantUtils.SOURCE).asText());
		roomArea.setSquareFeet(hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.SQUARE_FEET)
				.findValue(DHConstantUtils.VALUE).asText());
		roomArea.setSquareMeter(hotelRoom.path(DHConstantUtils.FIELDS).path(DHConstantUtils.SQUARE_METER)
				.findValue(DHConstantUtils.VALUE).asText());
		roomType.setRoomArea(roomArea);

		return roomType;
	}

	private List<String> getImagesList(JsonNode imagesNode) {
		List<String> images = new ArrayList<>();

		for (JsonNode imageNode : imagesNode) {
			images.add(imageNode.path(DHConstantUtils.FIELDS).path(DHConstantUtils.IMAGE).path(DHConstantUtils.VALUE)
					.findValue(DHConstantUtils.SOURCE).asText());
		}

		return images;
	}

}
