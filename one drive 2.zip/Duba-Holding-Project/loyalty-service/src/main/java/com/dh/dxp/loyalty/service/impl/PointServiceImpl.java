package com.dh.dxp.loyalty.service.impl;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.PointsDetails;
import com.dh.dxp.loyalty.service.PointService;
import com.dh.dxp.loyalty.util.DHConstantUtils;
import com.dh.dxp.loyalty.util.SiriusRestUtil;

@Service
public class PointServiceImpl implements PointService {

	@Value("#{'${ocs.profile.url}'}")
	private String url;

	@Autowired
	private SiriusRestUtil restExchange;

	private static final Logger logger = LogManager.getLogger(ProfileServiceImpl.class);

	@Override
	public PointsDetails getPointsDetails(String token, String membershipNumber)
			throws SiriusLoginException, SitecoreException {

		StringBuilder urlAppender = new StringBuilder(url);
		urlAppender.append(membershipNumber);
		urlAppender.append("/points");
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		header.set(DHConstantUtils.AUTH_TOKEN_STRING, token);
		HttpEntity<String> requestEntity = new HttpEntity<>(header);
		logger.debug("Final url for points :", urlAppender.toString());
		String pointResponse = restExchange.getRestResponse(urlAppender, requestEntity);
		PointsDetails pointsDetails = new PointsDetails();

		try {
			pointsDetails = processJsonNode(pointResponse);
		} catch (IOException e) {
			logger.error("Could not process Response string as Json node.");
		} 
		return pointsDetails;
	}

	private PointsDetails processJsonNode(String pointResponse) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode rootNode = objectMapper.readTree(pointResponse);

		PointsDetails pointsDetails = new PointsDetails();

		pointsDetails.setCurrentPoints(Long.toString(rootNode.path("Membership").path("CurrentPoints").asLong()));
		pointsDetails.setTotal(Long.toString(rootNode.path("Points").path("Total").asLong()));
		pointsDetails.setBaseStay(Long.toString(rootNode.path("Tier").path("BaseStay").asLong()));

		return pointsDetails;
	}
}
