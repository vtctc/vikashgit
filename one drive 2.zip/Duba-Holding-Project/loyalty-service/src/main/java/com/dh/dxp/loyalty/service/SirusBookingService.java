package com.dh.dxp.loyalty.service;

import java.io.IOException;
import java.util.Map;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.loyalty.beans.SirusHotelReservationRQ;

public interface SirusBookingService {

	public Map<String, String> bookingProcess(SirusHotelReservationRQ reservationRQ)
			throws  DHGlobalException, IOException;
}
