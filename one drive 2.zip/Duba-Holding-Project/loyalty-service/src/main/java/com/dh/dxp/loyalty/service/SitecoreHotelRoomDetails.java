package com.dh.dxp.loyalty.service;

import org.springframework.stereotype.Component;

import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.HotelRoomDetails;

@Component
public interface SitecoreHotelRoomDetails {
	public HotelRoomDetails getHotelRoomDetailsFromSiteCore(String hotelCMSId, String languageId)
			throws SitecoreException;
}
