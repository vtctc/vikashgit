package com.dh.dxp.loyalty.service;

import org.springframework.stereotype.Component;

import com.dh.dxp.component.exceptions.SiriusLoginException;
import com.dh.dxp.component.exceptions.SitecoreException;
import com.dh.dxp.loyalty.beans.PointsDetails;

@Component
public interface PointService {

	PointsDetails getPointsDetails(String token, String membershipNumber)
			throws SitecoreException, SiriusLoginException;

}
