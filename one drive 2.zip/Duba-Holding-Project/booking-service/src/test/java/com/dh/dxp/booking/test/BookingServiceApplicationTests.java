package com.dh.dxp.booking.test;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.dh.dxp.booking.config.DHConstants;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class BookingServiceApplicationTests extends CreateReservationAppTest {
	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;
	private static String token;

	@Before
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		token = obtainAccessToken("dh-ui-client", "DH@React.123");

	}

	@Test
	public void testCaseForCreateReservation() throws Exception {

		String loadMockData = loadMockResource("mockWithCorrectData");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(200));

	}

	@Test
	public void testCaseForCreateReservationWithOptional() throws Exception {

		String loadMockData = loadMockResource("mockWithCorrectOptionalData");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(200));

	}

	@Test
	public void negativeTestCaseWithoutCardExpireDate() throws Exception {

		String loadMockData = loadMockResource("mockWithoutCardExpireDate");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.header("Authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON)
				.content(loadMockData).accept(MediaType.APPLICATION_JSON)).andExpect(status().is(400));

	}

	@Test
	public void negativeTestCaseWithoutCardNumber() throws Exception {

		String loadMockData = loadMockResource("mockWithoutCardNumber");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	@Test
	public void negativeTestCaseWithoutGuestCount() throws Exception {

		String loadMockData = loadMockResource("mockWithoutGuestCount");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	@Test
	public void negativeTestCaseWithouHotelCode() throws Exception {

		String loadMockData = loadMockResource("mockWithoutHotelCode");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	// @Test
	public void negativeTestCaseWithoutRateCode() throws Exception {

		String loadMockData = loadMockResource("mockWithoutRateCode");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	@Test
	public void negativeTestCaseWithoutRoomCode() throws Exception {

		String loadMockData = loadMockResource("mockWithoutRoomCode");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	@Test
	public void negativeTestCaseWithoutSurname() throws Exception {

		String loadMockData = loadMockResource("mockWithoutSurname");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/reservations")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}
	
	@Test
	public void testCaseForReadReservation() throws Exception {

		String loadMockData = loadMockResource("mockWithReadReservationCorrectData");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/read_reservation")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(200));

	}
	@Test
	public void testCaseForCancelReservation() throws Exception {

		String loadMockData = loadMockResource("mockWithCancelReservnCorrectData");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/cancel_reservation")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(200));

	}
	@Test
	public void negativeReadTestCaseWithoutConfirmationNume() throws Exception {

		String loadMockData = loadMockResource("readReservationWithoutConfirmationNo");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/read_reservation")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}
	@Test
	public void negativeCancelTestCaseWithoutConfirmationNume() throws Exception {

		String loadMockData = loadMockResource("cancelWithoutConfirmationNo");
		System.out.println(loadMockData);
		mockMvc.perform(MockMvcRequestBuilders.post(DHConstants.BASE_PATH_BKNG + "/cancel_reservation")
				.contentType(MediaType.APPLICATION_JSON).content(loadMockData).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().is(400));

	}

	private static String loadMockResource(String mockType) throws Exception {
		File resource = null;
		String strCurrentLine = "";
		StringBuilder mockdataStr = new StringBuilder();

		resource = new ClassPathResource("mockData/" + mockType + ".json").getFile();
		try (BufferedReader br = new BufferedReader(new FileReader(resource))) {

			while ((strCurrentLine = br.readLine()) != null) {
				mockdataStr.append(strCurrentLine).append("\n");
			}
		}
		return mockdataStr.toString();
	}

	private String obtainAccessToken(String client_id, String client_secret) throws Exception {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add("grant_type", "client_credentials");
		params.add("client_id", client_id);
		params.add("client_secret", "DH@React.123");
		params.add("scope", "read");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + "ZGgtdWktY2xpZW50OkRIQFJlYWN0LjEyMw==");

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(params,
				headers);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.postForEntity("http://13.80.70.173/oauth/token", request,
				String.class);
		String responseValue = response.getBody();
		JacksonJsonParser jsonParser = new JacksonJsonParser();
		responseValue = jsonParser.parseMap(responseValue).get("access_token").toString();
		return responseValue;
	}
}
