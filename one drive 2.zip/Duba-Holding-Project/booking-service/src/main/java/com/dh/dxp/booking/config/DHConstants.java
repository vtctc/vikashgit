package com.dh.dxp.booking.config;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DHConstants {
	private DHConstants() {
		
	}
	public static final String BASE_PATH_BKNG = "/1.0/hospitality/hotels";
	public static final String PRODUCERS_FRMT = "application/json";
	public static final String REQUESTOR_ID = "10";
	public static final String COMPANY_CODE = "WSBE";
	public static final String ID_CONTEXT = "Synxis";
	public static final String RESPONSE_HEADER = "Response_Token";
	public static final String MDC_TOKEN_KEY = "request-Id";
	public static final String REQUEST_HEADER = "request-Header";
	public static final String ECOTOKEN = "12345";
	public static final String RES_STATUS = "Commit";
	public static final String TRUE_STRING = "true";
	public static final String NAME_SPACE="http://www.opentravel.org/OTA/2003/05";
	public static final String CRS_CONFIRM_TYPE = "14";
	public static final String CRS_CONFIRM_CONTEXT = "CrsConfirmNumber";
	public static final Integer MAX_RESPONSE = 0;
	
	//error Message
	public static final String ROOM_TYPE_CODE_ERROR = "roomTypeCode can't be empty or null";
	public static final String NO_OF_UNITS_ERROR = "numberOfUnits cannot be less than 1";
	public static final String RATE_PLAN_CODE_ERROR = "ratePlanCode can't be empty or null";
	public static final String RATE_PLAN_ID_ERROR = "ratePlanID can't be empty or null";
	public static final String AGE_OF_QUALIFYING_ERROR = "AgeQualifyingCode can't be empty or null";
	public static final String GUEST_COUNT_ERROR = "Guest Count can't be empty or null";
	public static final String HOTEL_CODE_ERROR = "Hotel Code can't be empty or null";
	public static final String EMAIL_ERROR = "Email can't be empty or null";
	public static final String PHONE_NUM_ERROR = "Phone number can't be empty or null";
	public static final String GIVEN_NAME_ERROR = "GivenName can't be empty or null";
	public static final String SUR_NAME_ERROR = "SurName can't be empty or null";
	public static final String CARD_NAME_ERROR = "Card Name can't be empty or null";
	public static final String CARD_NUM_ERROR = "Card number can't be empty or null";
	public static final String CARD_EXPIRE_ERROR = "Card expire can't be empty or null";
	public static final String CARD_SERIES_ERROR = "Card Series can't be empty or null";
	public static final String CRS_CONFIRM_NUM_ERROR = "Confirmation Num can't be empty or null";
	public static final String COUNTRY_ERROR = "Country name can't be empty or null";
	public static final String START_DATE_ERROR = "startDate can't be empty or null";
	public static final String END_DATE_ERROR = "end date can't be empty or null";
}
