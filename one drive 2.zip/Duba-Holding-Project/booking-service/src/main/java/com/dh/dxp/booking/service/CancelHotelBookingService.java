package com.dh.dxp.booking.service;

import java.io.IOException;
import java.util.Objects;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.ReadCancelHotelRequest;
import com.dh.dxp.booking.utils.Utility;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.dh.dxp.schemas.BasicPropertyInfoType;
import com.dh.dxp.schemas.OTACancelRQ;
import com.dh.dxp.schemas.OTACancelRS;
import com.dh.dxp.schemas.ObjectFactory;
import com.dh.dxp.schemas.SupplementalData;
import com.dh.dxp.schemas.TPAExtensions;
import com.dh.dxp.schemas.UniqueID;
import com.dh.dxp.schemas.Verification;
import com.dh.dxp.schemas.WrittenConfInst;
import com.dh.dxp.synxis.util.ServiceUtils;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/

@Service
public class CancelHotelBookingService {

	private static final Logger logger = LogManager.getLogger(CancelHotelBookingService.class);

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private Utility utility;
	
	@Autowired
	private HotelRestaurantMappingServiceImpl hotelRestaurantMappingServiceImpl;


	@Value("#{'${cancelReservations.action}'}")
	private String cancelBookingAction = "";

	@Value("#{'${serivce.namespaceuri}'}")
	private String nameSpaceUri;

	@HystrixCommand(ignoreExceptions = {
			DHGlobalException.class },fallbackMethod = "cancelReeservationFallback", commandKey = "serviceACommandKey")
	public OTACancelRS cancelHotelProcess(ReadCancelHotelRequest cancelHotelRequest) throws DHGlobalException {
		
		logger.info(" calling getCancelHotelBookingRQ ");		
		JAXBElement<OTACancelRQ> cancelHotelRQ = setJAXBOtaCancelHotelRQ(cancelHotelRequest);
		
		@SuppressWarnings("unchecked")
		JAXBElement<OTACancelRS> dhJaxbElement = (JAXBElement<OTACancelRS>) serviceUtils.sendAndRecieve(cancelHotelRQ,
				cancelBookingAction);
		logger.info(" exit getCancelHotelBookingRQ ");
		return dhJaxbElement.getValue();

	}

	/**
	 * @param oTAHotelResRQ
	 * @return
	 * @throws DHGlobalException
	 */
	public OTACancelRS cancelReeservationFallback(ReadCancelHotelRequest cancelHotelRequest)
			throws DHGlobalException {
		logger.debug("crsConfirmationNumber {}",cancelHotelRequest.getCrsConfirmNumber());
		String response = "Service is down!!! Please try again later";
		logger.error(response);
		throw new DHGlobalException(response);
	}

	/**
	 * @param hotelAvailRequestObj
	 * @return
	 * @throws DHGlobalException 
	 * @throws IOException
	 */
	private JAXBElement<OTACancelRQ> setJAXBOtaCancelHotelRQ(ReadCancelHotelRequest cancelHotelRequest) throws DHGlobalException {
		logger.info("calling checkOTAHotelAvailRQ");
		Objects.requireNonNull(cancelHotelRequest, "Request can't be null");
		String bookingNum=cancelHotelRequest.getCrsConfirmNumber();
		String hotelCode=cancelHotelRequest.getHotelCode();
		utility.checkNullAndEmpety(bookingNum, DHConstants.CRS_CONFIRM_NUM_ERROR);
		utility.checkNullAndEmpety(hotelCode, DHConstants.HOTEL_CODE_ERROR);		
		hotelCode=hotelRestaurantMappingServiceImpl.findBookingSystemId(hotelCode);
		ObjectFactory objectFactory = new ObjectFactory();
		OTACancelRQ hotelCancelRQ = objectFactory.createOTACancelRQ();
		hotelCancelRQ.setPrimaryLangID(cancelHotelRequest.getPrimaryLangID());
		// UniqueID Channel Info

		UniqueID uniqueID = new UniqueID();
		uniqueID.setType(DHConstants.CRS_CONFIRM_TYPE);
		uniqueID.setID(cancelHotelRequest.getCrsConfirmNumber());
		uniqueID.setIDContext(DHConstants.CRS_CONFIRM_CONTEXT);

		// Verification Channel Info
		Verification verification = new Verification();

		TPAExtensions tpaExtensions = new TPAExtensions();

		BasicPropertyInfoType basicPropertyInfoType = new BasicPropertyInfoType();
		basicPropertyInfoType.setHotelCode(hotelCode);
		verification.setTPAExtensions(tpaExtensions);
		tpaExtensions.setBasicPropertyInfo(basicPropertyInfoType);

		// WrittenConfInst
		WrittenConfInst writtenConfInst = new WrittenConfInst();
		SupplementalData supplementalData = new SupplementalData();
		writtenConfInst.setSupplementalData(supplementalData);
		hotelCancelRQ.setPOS(utility.setPosChanel());
		hotelCancelRQ.getUniqueID().add(uniqueID);
		hotelCancelRQ.setVerification(verification);
		hotelCancelRQ.setTPAExtensions(tpaExtensions);
		utility.jaxbObjectToXML(hotelCancelRQ,"OTA_CancelRQ",nameSpaceUri);
		return new JAXBElement<>(new QName(nameSpaceUri, "OTA_CancelRQ"), OTACancelRQ.class, hotelCancelRQ);

	}
}
