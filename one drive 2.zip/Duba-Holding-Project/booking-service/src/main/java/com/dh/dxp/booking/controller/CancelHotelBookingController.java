package com.dh.dxp.booking.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.ReadCancelHotelRequest;
import com.dh.dxp.booking.service.CancelHotelBookingService;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.schemas.OTACancelRS;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */

@RestController
@RequestMapping(path = DHConstants.BASE_PATH_BKNG)
public class CancelHotelBookingController {

	@Autowired
	private CancelHotelBookingService cancelHotelBookingService;

	private static final Logger logger = LogManager.getLogger(CancelHotelBookingController.class);

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = OTACancelRS.class),
			@ApiResponse(code = 500, message = "Error", response = DHGlobalException.class) })
	@ApiOperation(value = "cancel the reservation of the hotel based on basis of confirmation number and hotel code ", produces = DHConstants.PRODUCERS_FRMT, notes = "This functionality is used for microservices communication.")
	@RequestMapping(value = "cancel_reservation", method = RequestMethod.POST, produces = DHConstants.PRODUCERS_FRMT)
	public ResponseEntity<OTACancelRS> cancelBooking(@RequestBody ReadCancelHotelRequest cancelHotelRequest) throws DHGlobalException {
		logger.info("cancelHotelBooking cancelHotelRequest:{}", cancelHotelRequest);

		return new ResponseEntity<>(cancelHotelBookingService.cancelHotelProcess(cancelHotelRequest),
				HttpStatus.OK);
	}

}
