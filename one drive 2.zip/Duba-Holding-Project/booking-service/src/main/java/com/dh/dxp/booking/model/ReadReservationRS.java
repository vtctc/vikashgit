package com.dh.dxp.booking.model;

import java.util.List;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class ReadReservationRS {
	
private List<RoomStaysRS> roomStays;
private String bookingNum;

private List <String> addOns;
private List <String> specailRequest;

public List<RoomStaysRS> getRoomStays() {
	return roomStays;
}
public void setRoomStays(List<RoomStaysRS> roomStays) {
	this.roomStays = roomStays;
}
public String getBookingNum() {
	return bookingNum;
}
public void setBookingNum(String bookingNum) {
	this.bookingNum = bookingNum;
}
public List<String> getAddOns() {
	return addOns;
}
public void setAddOns(List<String> addOns) {
	this.addOns = addOns;
}
public List<String> getSpecailRequest() {
	return specailRequest;
}
public void setSpecailRequest(List<String> specailRequest) {
	this.specailRequest = specailRequest;
}



}
