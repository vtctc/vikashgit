/**
 * 
 */
package com.dh.dxp.booking.model;

import java.util.List;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHResGuests {
	
	private List<DHProfileInfo> profileInfoList;

	public List<DHProfileInfo> getProfileInfoList() {
		return profileInfoList;
	}

	public void setProfileInfoList(List<DHProfileInfo> profileInfoList) {
		this.profileInfoList = profileInfoList;
	}
}
