package com.dh.dxp.booking.service;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.DHBase;
import com.dh.dxp.booking.model.DHCutomer;
import com.dh.dxp.booking.model.DHProfileInfo;
import com.dh.dxp.booking.model.DHRate;
import com.dh.dxp.booking.model.DHRatePlan;
import com.dh.dxp.booking.model.DHResGlobalInfo;
import com.dh.dxp.booking.model.DHResGuests;
import com.dh.dxp.booking.model.DHReservationReseponse;
import com.dh.dxp.booking.model.DHRoomRate;
import com.dh.dxp.booking.model.DHRoomStays;
import com.dh.dxp.booking.model.DHRoomType;
import com.dh.dxp.booking.model.DHServiceDetails;
import com.dh.dxp.booking.model.DHTotal;
import com.dh.dxp.booking.model.DHUserId;
import com.dh.dxp.booking.model.HotelReservationRequest;
import com.dh.dxp.booking.model.ReservationRequest;
import com.dh.dxp.booking.utils.CardType;
import com.dh.dxp.booking.utils.Utility;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.CurrencyExchangeService;
import com.dh.dxp.component.utils.DHMapper;
import com.dh.dxp.schemas.AddressInfo;
import com.dh.dxp.schemas.ArrayOfComment;
import com.dh.dxp.schemas.ArrayOfErrorType;
import com.dh.dxp.schemas.ArrayOfGuaranteeAccepted;
import com.dh.dxp.schemas.ArrayOfHotelReservation;
import com.dh.dxp.schemas.ArrayOfHotelReservationID;
import com.dh.dxp.schemas.ArrayOfProfileInfo;
import com.dh.dxp.schemas.ArrayOfRatePlan;
import com.dh.dxp.schemas.ArrayOfRateType;
import com.dh.dxp.schemas.ArrayOfResGuest;
import com.dh.dxp.schemas.ArrayOfRoomRate;
import com.dh.dxp.schemas.ArrayOfRoomStay;
import com.dh.dxp.schemas.ArrayOfRoomType;
import com.dh.dxp.schemas.ArrayOfService;
import com.dh.dxp.schemas.ArrayOfSpecialRequest;
import com.dh.dxp.schemas.Base;
import com.dh.dxp.schemas.Comment;
import com.dh.dxp.schemas.ContactPerson;
import com.dh.dxp.schemas.CountryName;
import com.dh.dxp.schemas.CustLoyalty;
import com.dh.dxp.schemas.Customer;
import com.dh.dxp.schemas.DateTimeSpanType;
import com.dh.dxp.schemas.ErrorType;
import com.dh.dxp.schemas.Guarantee;
import com.dh.dxp.schemas.GuaranteeAccepted;
import com.dh.dxp.schemas.GuestCount;
import com.dh.dxp.schemas.GuestCounts;
import com.dh.dxp.schemas.HotelReferenceGroup;
import com.dh.dxp.schemas.HotelReservation;
import com.dh.dxp.schemas.HotelReservationID;
import com.dh.dxp.schemas.OTAHotelResRQ;
import com.dh.dxp.schemas.OTAHotelResRS;
import com.dh.dxp.schemas.ObjectFactory;
import com.dh.dxp.schemas.POS;
import com.dh.dxp.schemas.PaymentCard;
import com.dh.dxp.schemas.PersonName;
import com.dh.dxp.schemas.Profile;
import com.dh.dxp.schemas.ProfileInfo;
import com.dh.dxp.schemas.RatePlan;
import com.dh.dxp.schemas.RateType;
import com.dh.dxp.schemas.ResCommonDetailType;
import com.dh.dxp.schemas.ResGlobalInfo;
import com.dh.dxp.schemas.ResGuest;
import com.dh.dxp.schemas.RoomRate;
import com.dh.dxp.schemas.RoomStay;
import com.dh.dxp.schemas.RoomType;
import com.dh.dxp.schemas.Service;
import com.dh.dxp.schemas.SpecialRequest;
import com.dh.dxp.schemas.TelephoneInfo;
import com.dh.dxp.schemas.Total;
import com.dh.dxp.schemas.UniqueID;
import com.dh.dxp.schemas.UserID;
import com.dh.dxp.schemas.WrittenConfInst;
import com.dh.dxp.synxis.util.ServiceUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
@org.springframework.stereotype.Service
public class CreateReservationService {
	@Autowired
	private Environment env;

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private Utility utility;
	
	@Autowired
	private CurrencyExchangeService currencyExchangeService;
	
	@Autowired
	private DHMapper dhMapper;

	@Value("#{'${createReservations.action}'}")
	private String createAction;

	@Value("#{'${serivce.namespaceuri}'}")
	private String nameSpaceUri;

	final Logger logger = LoggerFactory.getLogger(CreateReservationService.class);

	/**
	 * @param oTAHotelResRequest
	 * @return
	 * @throws DHGlobalException
	 * @throws IOException 
	 * @throws JsonProcessingException 
	 */
	@HystrixCommand(ignoreExceptions = {
			DHGlobalException.class }, fallbackMethod = "createReservationFallback", commandKey = "serviceACommandKey")
	public DHReservationReseponse createReservationRequest(HotelReservationRequest hotelReservationRequest)
			throws DHGlobalException {
		logger.info(" calling hotelBookingReservation");
		JAXBElement<OTAHotelResRQ> oTAHotelResRQ =	createOTAHotelResRQ(hotelReservationRequest);
			
		DHReservationReseponse response = new DHReservationReseponse();
		
		Double siriusPoints=2*calculateSiriusPoints(hotelReservationRequest);
		
		OTAHotelResRS otaHotelResResponse = callSynixClient(oTAHotelResRQ);
		
		utility.jaxbObjectToJson(otaHotelResResponse);
		if (otaHotelResResponse != null) {
			ArrayOfErrorType arrayOfErrorType = otaHotelResResponse.getErrors();

			if (null != arrayOfErrorType) {
				extractErrorDetail(arrayOfErrorType);

			} else {
				ArrayOfHotelReservation hotelReservations = otaHotelResResponse.getHotelReservations();
				Objects.requireNonNull(hotelReservations, "hotelReservations can't be null");
				List<HotelReservation> reservationsList = hotelReservations.getHotelReservation();
				Objects.requireNonNull(reservationsList, "hotelReservations list can't be null");
				for (HotelReservation hotelReservation : reservationsList) {
					UniqueID uniqueID = hotelReservation.getUniqueID();
					Objects.requireNonNull(uniqueID, "confirmation number not found");
					response.setCrsConfirmNumber(uniqueID.getID());
					Long sirusPoint=Math.round(siriusPoints);
					response.setSiriusPoint(sirusPoint.toString());
				}
			}

		} else {
			logger.error("hotel response is null");
			throw new DHGlobalException("Internal Server Error");
		}
		logger.info(" exit from hotelBookingReservation");
		return response;
	}

	private Double calculateSiriusPoints(HotelReservationRequest hotelReservationRequest) {
		ObjectMapper objectMapper = new ObjectMapper();
		double val = 0;

		JsonNode node = objectMapper.convertValue(hotelReservationRequest, JsonNode.class);
		String amountBeforeTax = node.findPath("amountBeforeTax").asText();
		String numberOfUnits = node.findPath("numberOfUnits").asText();

		if (numberOfUnits != null && amountBeforeTax != null && !numberOfUnits.isEmpty()
				&& !amountBeforeTax.isEmpty()) {
			try {
				val = currencyExchangeService.getCurrencyExchangeValue("AED", "USD", amountBeforeTax);
				val=val*Integer.parseInt(numberOfUnits);
				logger.info("val:{}", val);
			} catch (Exception e) {
				logger.info("error{}", e.getMessage());
			}
		}
		return val;
	}

	private void extractErrorDetail(ArrayOfErrorType arrayOfErrorType) throws DHGlobalException {
		List<ErrorType> errorTypeList = arrayOfErrorType.getError();
		StringBuilder errorMsg = new StringBuilder();
		if (null != errorTypeList && !errorTypeList.isEmpty()) {
			for (ErrorType errorType : errorTypeList) {
				errorMsg.append((errorType.getShortText() + " "));
			}
		}
		logger.error("error:{}", errorMsg);
		throw new DHGlobalException(errorMsg.toString());
	}

	/**
	 * @param oTAHotelResRQ
	 * @return
	 */
	public OTAHotelResRS callSynixClient(JAXBElement<OTAHotelResRQ> oTAHotelResRQ) {
		@SuppressWarnings("unchecked")
		final JAXBElement<OTAHotelResRS> jaxbElement = (JAXBElement<OTAHotelResRS>) serviceUtils
				.sendAndRecieve(oTAHotelResRQ, createAction);

		return jaxbElement.getValue();
	}

	/**
	 * @param oTAHotelResRequest
	 * @return
	 * @throws DHGlobalException
	 */
	public DHReservationReseponse createReservationFallback(HotelReservationRequest hotelReservationRequest)
			throws DHGlobalException {
		logger.debug("oTAHotelResRQ{}",hotelReservationRequest.getReservationRequest());
		String response = "Service is down!!! Please try again later";
		logger.error(response);
		throw new DHGlobalException(response);
	}

	/**
	 * @param oTAHotelResRequest
	 * @return
	 */
	public JAXBElement<OTAHotelResRQ> createOTAHotelResRQ(HotelReservationRequest oTAHotelResRequest)
			throws DHGlobalException {
		logger.info("calling createOTAHotelResRQ");
		ObjectFactory objectFactory = new ObjectFactory();

		OTAHotelResRQ otaHotelResRQ = objectFactory.createOTAHotelResRQ();
		otaHotelResRQ.setPrimaryLangID(oTAHotelResRequest.getPrimaryLangId());
		otaHotelResRQ.setResStatus(DHConstants.RES_STATUS);

		POS pos = utility.setPosChanel();

		// Hotel Reservation setting
		ArrayOfHotelReservation arrayOfHotelReservation = new ArrayOfHotelReservation();
		List<ReservationRequest> reservationRequests = oTAHotelResRequest.getReservationRequest();
		if (reservationRequests != null && !reservationRequests.isEmpty()) {
			for (ReservationRequest reservationRequest : reservationRequests) {
				HotelReservation hotelReservation = new HotelReservation();

				hotelReservation.setRoomStayReservation(Boolean.TRUE);

				// setting Unique ID
				UniqueID dhUniqueID = reservationRequest.getUniqueID();
				hotelReservation.setUniqueID(dhUniqueID);

				// setRoomStays
				ArrayOfRoomStay arrayOfRoomStay = new ArrayOfRoomStay();
				setRoomstays(reservationRequest, arrayOfRoomStay);
				hotelReservation.setRoomStays(arrayOfRoomStay);

				// setting ResGuests
				List<DHResGuests> dhResGuests = reservationRequest.getResGuests();
				ArrayOfResGuest arrayOfResGuest = new ArrayOfResGuest();
				createResGuests(dhResGuests, arrayOfResGuest);
				hotelReservation.setResGuests(arrayOfResGuest);
				// end of setting ResGuests

				// setting global info
				DHResGlobalInfo dhResGlobalInfo = reservationRequest.getResGlobalInfo();
				ResGlobalInfo resGlobalInfo = new ResGlobalInfo();
				createResGlobalInfo(dhResGlobalInfo, resGlobalInfo);
				hotelReservation.setResGlobalInfo(resGlobalInfo);
				// end of setting global info

				// setting Supplement Data
				WrittenConfInst writtenConfInst = new WrittenConfInst();
				hotelReservation.setWrittenConfInst(writtenConfInst);
				// end

				// Setting Services detail
				List<DHServiceDetails> dhServiceDetails = reservationRequest.getServiceDetails();
				ArrayOfService arrayOfService = new ArrayOfService();
				setServiceDetails(dhServiceDetails, arrayOfService);
				hotelReservation.setServices(arrayOfService);
				// end of Setting Services detail

				arrayOfHotelReservation.getHotelReservation().add(hotelReservation);

			}
			logger.info("exit from createOTAHotelResRQ");
		}

		otaHotelResRQ.setPOS(pos);
		otaHotelResRQ.setHotelReservations(arrayOfHotelReservation);
		utility.jaxbObjectToXML(otaHotelResRQ, "OTA_HotelResRQ", nameSpaceUri);
		JAXBElement<OTAHotelResRQ> jaxbOTAHotelResRQ = new JAXBElement<>(new QName(nameSpaceUri, "OTA_HotelResRQ"),
				OTAHotelResRQ.class, otaHotelResRQ);
		logger.info("returning response {}");
		return jaxbOTAHotelResRQ;
	}

	/**
	 * @param dhResGuests
	 * @param arrayOfResGuest
	 */
	private void createResGuests(List<DHResGuests> dhResGuests, ArrayOfResGuest arrayOfResGuest)
			throws DHGlobalException {
		logger.info("calling createResGuests");
		if (dhResGuests != null && !dhResGuests.isEmpty())
			for (DHResGuests dhResGuest : dhResGuests) {
				ResGuest resGuest = new ResGuest();
				List<DHProfileInfo> dhProfileInfos = dhResGuest.getProfileInfoList();
				ArrayOfProfileInfo arrayOfProfileInfo = new ArrayOfProfileInfo();
				extractProfile(dhProfileInfos, arrayOfProfileInfo);
				resGuest.setProfiles(arrayOfProfileInfo);
				arrayOfResGuest.getResGuest().add(resGuest);
			}
	}

	/**
	 * @param dhProfileInfos
	 * @param arrayOfProfileInfo
	 * @throws DHGlobalException
	 */
	private void extractProfile(List<DHProfileInfo> dhProfileInfos, ArrayOfProfileInfo arrayOfProfileInfo)
			throws DHGlobalException {
		if (dhProfileInfos != null && !dhProfileInfos.isEmpty())
			for (DHProfileInfo dhProfileInfo : dhProfileInfos) {
				ProfileInfo profileInfo = new ProfileInfo();
				Profile profile = new Profile();
				setProfileUniqueID(profileInfo, dhProfileInfo);

				DHUserId dhUserId = dhProfileInfo.getUserId();
				setUserID(profile, dhUserId);
				List<DHCutomer> dhCutomers = dhProfileInfo.getCutomers();
				if (dhCutomers != null && !dhCutomers.isEmpty()) {
					for (DHCutomer dhCutomer : dhCutomers) {
						setCustomer(profile, dhCutomer);
					}
				}

				profileInfo.setProfile(profile);
				arrayOfProfileInfo.getProfileInfo().add(profileInfo);

			}
	}

	/**
	 * @param dhResGlobalInfo
	 * @param resGlobalInfo
	 * @throws DHGlobalException
	 */
	private void createResGlobalInfo(DHResGlobalInfo dhResGlobalInfo, ResGlobalInfo resGlobalInfo)
			throws DHGlobalException {
		logger.info("calling createResGlobalInfo");
		if (dhResGlobalInfo != null) {

			// setting comments
			ArrayOfComment arrayOfComment = new ArrayOfComment();
			List<Comment> dhComments = dhResGlobalInfo.getComment();
			if (dhComments != null && !dhComments.isEmpty()) {
				for (Comment dhcomment : dhComments) {
					arrayOfComment.getComment().add(dhcomment);
				}

			}
			resGlobalInfo.setComments(arrayOfComment);

			// setting payment Card
			List<PaymentCard> dhPaymentCards = dhResGlobalInfo.getPaymentCards();
			Guarantee guarantee = new Guarantee();
			ArrayOfGuaranteeAccepted arrayOfGuaranteeAccepted = new ArrayOfGuaranteeAccepted();
			extractCardDetails(dhPaymentCards, arrayOfGuaranteeAccepted);

			guarantee.setGuaranteesAccepted(arrayOfGuaranteeAccepted);

			resGlobalInfo.setGuarantee(guarantee);

			// setting profile
			List<UniqueID> dhUniqueID = dhResGlobalInfo.getProfileInfo();
			ArrayOfProfileInfo arrayOfProfileInfo = new ArrayOfProfileInfo();
			ProfileInfo profileInfo = new ProfileInfo();
			if (null != dhUniqueID && !dhUniqueID.isEmpty())
				setUniqueID(dhUniqueID, profileInfo);

			arrayOfProfileInfo.getProfileInfo().add(profileInfo);
			resGlobalInfo.setProfiles(arrayOfProfileInfo);

			// setting HotelReservationIDs
			List<HotelReservationID> dhArrayOfHotelReservationID = dhResGlobalInfo.getHotelResvId();
			ArrayOfHotelReservationID arrayOfHotelReservationID = new ArrayOfHotelReservationID();
			if (null != dhArrayOfHotelReservationID && !dhArrayOfHotelReservationID.isEmpty()) {
				setHotelReservationID(dhArrayOfHotelReservationID, arrayOfHotelReservationID);
			}
			resGlobalInfo.setHotelReservationIDs(arrayOfHotelReservationID);
		}
	}

	private void setUniqueID(List<UniqueID> dhUniqueID, ProfileInfo profileInfo) {
		for (UniqueID dhuniqueID : dhUniqueID) {

			profileInfo.getUniqueID().add(dhuniqueID);
		}
	}

	private void setHotelReservationID(List<HotelReservationID> dhArrayOfHotelReservationID,
			ArrayOfHotelReservationID arrayOfHotelReservationID) {
		for (HotelReservationID dhHotelReservationID : dhArrayOfHotelReservationID) {
			arrayOfHotelReservationID.getHotelReservationID().add(dhHotelReservationID);
		}
	}

	/**
	 * @param dhPaymentCards
	 * @param arrayOfGuaranteeAccepted
	 * @throws DHGlobalException
	 */
	private void extractCardDetails(List<PaymentCard> dhPaymentCards, ArrayOfGuaranteeAccepted arrayOfGuaranteeAccepted)
			throws DHGlobalException {
		if (dhPaymentCards != null && !dhPaymentCards.isEmpty()) {
			for (PaymentCard dhpaymentCard : dhPaymentCards) {
				GuaranteeAccepted guaranteeAccepted = new GuaranteeAccepted();
				CardType type = CardType.detect(dhpaymentCard.getCardNumber());
				String cardTypeCode = "";
				if (type != null) {
					cardTypeCode = env.getProperty(type.toString());
					logger.info("cardTypeCode {}", cardTypeCode);
					dhpaymentCard.setCardCode(cardTypeCode);
				}
				utility.checkNullAndEmpety(dhpaymentCard.getExpireDate(), DHConstants.CARD_EXPIRE_ERROR);
				utility.checkNullAndEmpety(dhpaymentCard.getCardNumber(), DHConstants.CARD_NUM_ERROR);
				utility.checkNullAndEmpety(dhpaymentCard.getSeriesCode(), DHConstants.CARD_SERIES_ERROR);
				utility.checkNullAndEmpety(dhpaymentCard.getCardHolderName(), DHConstants.CARD_NAME_ERROR);
				guaranteeAccepted.setPaymentCard(dhpaymentCard);
				arrayOfGuaranteeAccepted.getGuaranteeAccepted().add(guaranteeAccepted);
			}

		} else {
			throw new DHGlobalException("Card details can't be null");
		}
	}

	/**
	 * @param dhServiceDetails
	 * @param arrayOfService
	 * @throws DHGlobalException
	 */
	private void setServiceDetails(List<DHServiceDetails> dhServiceDetails, ArrayOfService arrayOfService) {
		logger.info("calling setServiceDetails");
		if (dhServiceDetails != null && !dhServiceDetails.isEmpty()) {
			for (DHServiceDetails dhServiceDetail : dhServiceDetails) {
				String startDate = dhServiceDetail.getStartTimestamp();
				String endDate = dhServiceDetail.getEndTimestamp();
				Service service = new Service();
				service.setServiceInventoryCode(dhServiceDetail.getServiceInventoryCode());
				ResCommonDetailType resCommonDetailType = new ResCommonDetailType();
				DateTimeSpanType dateTimeSpanType = new DateTimeSpanType();
				dateTimeSpanType.setStart(startDate);
				dateTimeSpanType.setEnd(endDate);
				resCommonDetailType.setTimeSpan(dateTimeSpanType);
				GuestCounts guestCounts = new GuestCounts();
				List<GuestCount> dhGuestCounts = dhServiceDetail.getGuestCount();
				for (GuestCount dhGuestCount : dhGuestCounts) {
					GuestCount guestCount = new GuestCount();
					guestCounts.getGuestCount().add(dhGuestCount);
					guestCount.setCount(dhGuestCount.getCount());
					guestCount.setAgeQualifyingCode(dhGuestCount.getAgeQualifyingCode());
					guestCounts.getGuestCount().add(guestCount);
				}

				resCommonDetailType.setGuestCounts(guestCounts);
				service.setServiceDetails(resCommonDetailType);
				arrayOfService.getService().add(service);
			}

		}
	}

	/**
	 * @param profile
	 * @param dhCutomer
	 */
	/**
	 * @param profile
	 * @param dhCutomer
	 * @throws DHGlobalException
	 */
	private void setCustomer(Profile profile, DHCutomer dhCutomer) throws DHGlobalException {
		logger.info("calling setCustomer");
		Customer customer = new Customer();

		// getting and setting person name
		List<PersonName> personNames = dhCutomer.getPersonName();
		extractPersonName(customer, personNames);

		// getting and setting TelephoneInfo
		List<TelephoneInfo> telephoneInfos = dhCutomer.getTelephone();
		if (telephoneInfos != null && !telephoneInfos.isEmpty()) {

			for (TelephoneInfo dhTelephoneInfo : telephoneInfos) {
				utility.checkNullAndEmpety(dhTelephoneInfo.getPhoneNumber(), DHConstants.PHONE_NUM_ERROR);
				customer.getTelephone().add(dhTelephoneInfo);

			}
		} else {
			throw new DHGlobalException("telphone details is missing ");
		}

		// getting and setting CountryName
		List<AddressInfo> dhAddressInfos = dhCutomer.getAddress();
		if (dhAddressInfos != null && !dhAddressInfos.isEmpty())
			setAddressInfo(customer, dhAddressInfos);

		// getting and setting ContactPerson
		ContactPerson dhContactPerson = dhCutomer.getContactPerson();
		if (dhContactPerson != null) {
			customer.setContactPerson(dhContactPerson);
		}
		// loyality
		List<CustLoyalty> dhCutLoyalty = dhCutomer.getCustLoyalty();
		if (null != dhCutLoyalty && !dhCutLoyalty.isEmpty()) {
			setCustomerLoyalty(customer, dhCutLoyalty);
		}

		List<String> dhEmails = dhCutomer.getEmail();
		if (null != dhEmails && !dhEmails.isEmpty()) {
			for (String dhEmail : dhEmails) {
				utility.checkNullAndEmpety(dhEmail, DHConstants.EMAIL_ERROR);
				customer.getEmail().add(dhEmail);
			}
		} else {
			throw new DHGlobalException(DHConstants.EMAIL_ERROR);
		}
		profile.setCustomer(customer);
	}

	private void setCustomerLoyalty(Customer customer, List<CustLoyalty> dhCutLoyalty) {
		for (CustLoyalty customerLoyalty : dhCutLoyalty) {
			customer.getCustLoyalty().add(customerLoyalty);
		}
	}

	private void setAddressInfo(Customer customer, List<AddressInfo> dhAddressInfos) throws DHGlobalException {
		for (AddressInfo dhAddressInfo : dhAddressInfos) {
			CountryName countryName = dhAddressInfo.getCountryName();
			Objects.requireNonNull(countryName, DHConstants.COUNTRY_ERROR);
			utility.checkNullAndEmpety(countryName.getCode(), DHConstants.COUNTRY_ERROR);
			customer.getAddress().add(dhAddressInfo);
		}
	}

	private void extractPersonName(Customer customer, List<PersonName> personNames) throws DHGlobalException {
		if (personNames != null && !personNames.isEmpty()) {

			for (PersonName dhPersonName : personNames) {
				List<String> givenName;
				String surName;
				if (dhPersonName != null && (givenName = dhPersonName.getGivenName()) != null
						&& (surName = dhPersonName.getSurname()) != null && !givenName.isEmpty()) {
					utility.checkNullAndEmpety(givenName.get(0), DHConstants.GIVEN_NAME_ERROR);
					utility.checkNullAndEmpety(surName, DHConstants.SUR_NAME_ERROR);
				} else {
					throw new DHGlobalException("Person details  is missing ");
				}

				customer.getPersonName().add(dhPersonName);
			}
		} else {
			throw new DHGlobalException("Person details  is missing ");
		}
	}

	/**
	 * @param profile
	 * @param dhUserId
	 */
	private void setUserID(Profile profile, DHUserId dhUserId) {
		logger.info("calling setUserID");
		if (dhUserId != null) {
			UserID userID = new UserID();
			userID.setID(dhUserId.getId());
			userID.setPinNumber(dhUserId.getPinNumber());
			profile.setUserID(userID);

		}
	}

	/**
	 * @param profileInfo
	 * @param dhProfileInfo
	 */
	private void setProfileUniqueID(ProfileInfo profileInfo, DHProfileInfo dhProfileInfo) {
		logger.info("calling setProfileUniqueID");
		List<UniqueID> uniqueIDs = dhProfileInfo.getUniqueID();
		if (uniqueIDs != null && !uniqueIDs.isEmpty())
			setUniqueID(uniqueIDs, profileInfo);
	}

	/**
	 * @param ReservationRequest reservationRequest
	 * @param ArrayOfRoomStay    arrayOfRoomStay
	 * @throws DHGlobalException
	 */
	private void setRoomstays(ReservationRequest reservationRequest, ArrayOfRoomStay arrayOfRoomStay)
			throws DHGlobalException {
		logger.info("calling setRoomstays");
		List<DHRoomStays> roomStays = reservationRequest.getRoomStaysList();
		ArrayOfRoomType arrayOfRoomType = new ArrayOfRoomType();
		ArrayOfRatePlan arrayOfRatePlan = new ArrayOfRatePlan();
		ArrayOfRoomRate arrayOfRoomRate = new ArrayOfRoomRate();
		ArrayOfSpecialRequest arrayOfSpecialRequest = new ArrayOfSpecialRequest();
		GuestCounts guestCounts = new GuestCounts();
		if (null != roomStays && !roomStays.isEmpty())
			for (DHRoomStays dhRoomStay : roomStays) {
				RoomStay roomStay = new RoomStay();
				DateTimeSpanType dateTimeSpanType = dhRoomStay.getTimeSpan();
				Objects.requireNonNull(dateTimeSpanType, "start and end date Can't be null");
				utility.checkNullAndEmpety(dateTimeSpanType.getStart(), DHConstants.START_DATE_ERROR);
				utility.checkNullAndEmpety(dateTimeSpanType.getEnd(), DHConstants.END_DATE_ERROR);
				setRoomTypes(arrayOfRoomType, dhRoomStay);
				setRatePlans(arrayOfRatePlan, dhRoomStay);
				setRoomRate(arrayOfRoomRate, dhRoomStay);
				setGuestCount(guestCounts, dhRoomStay);

				HotelReferenceGroup hotelReferenceGroup = new HotelReferenceGroup();
				setHotelRefGroup(dhRoomStay, hotelReferenceGroup);
				setSpecialRequest(arrayOfSpecialRequest, dhRoomStay);

				roomStay.setRoomTypes(arrayOfRoomType);
				roomStay.setRatePlans(arrayOfRatePlan);
				roomStay.setRoomRates(arrayOfRoomRate);
				roomStay.setGuestCounts(guestCounts);
				roomStay.setTimeSpan(dateTimeSpanType);
				roomStay.setBasicPropertyInfo(hotelReferenceGroup);
				roomStay.setSpecialRequests(arrayOfSpecialRequest);
				arrayOfRoomStay.getRoomStay().add(roomStay);
			}
	}

	/**
	 * @param arrayOfSpecialRequest
	 * @param roomStay
	 */
	private void setSpecialRequest(ArrayOfSpecialRequest arrayOfSpecialRequest, DHRoomStays roomStay) {
		logger.info("calling setSpecialRequest");
		List<SpecialRequest> specialRequests = roomStay.getSpecialRequest();
		if (specialRequests != null && !specialRequests.isEmpty())
			for (SpecialRequest dhSpecialRequests : specialRequests) {
				arrayOfSpecialRequest.getSpecialRequest().add(dhSpecialRequests);
			}
	}

	/**
	 * @param roomStay
	 * @throws DHGlobalException
	 */
	private void setHotelRefGroup(DHRoomStays roomStay, HotelReferenceGroup hotelReferenceGroup)
			throws DHGlobalException {
		logger.info("calling setHotelRefGroup");
		String hotelCode = roomStay.getHotelCode();
		utility.checkNullAndEmpety(hotelCode, DHConstants.HOTEL_CODE_ERROR);		
		hotelCode=dhMapper.getSynxisID(hotelCode);
		hotelReferenceGroup.setHotelCode(hotelCode);
	}

	/**
	 * @param guestCounts
	 * @param roomStay
	 * @throws DHGlobalException
	 */
	private void setGuestCount(GuestCounts guestCounts, DHRoomStays roomStay) throws DHGlobalException {
		logger.info("calling setGuestCount");
		List<GuestCount> dhGuestCounts = roomStay.getGuestCount();
		if (dhGuestCounts != null && !dhGuestCounts.isEmpty())
			for (GuestCount dhGuestCount : dhGuestCounts) {
				utility.checkNullAndEmpety(dhGuestCount.getAgeQualifyingCode(),
						DHConstants.AGE_OF_QUALIFYING_ERROR);
				utility.checkNullAndEmpety(dhGuestCount.getCount(), DHConstants.GUEST_COUNT_ERROR);
				guestCounts.getGuestCount().add(dhGuestCount);
			}
	}

	/**
	 * @param arrayOfRoomRate
	 * @param roomStay
	 */
	private void setRoomRate(ArrayOfRoomRate arrayOfRoomRate, DHRoomStays roomStay) {
		logger.info("calling setRoomRate");
		List<DHRoomRate> dhRoomRates = roomStay.getRoomRates();
		if (dhRoomRates != null && !dhRoomRates.isEmpty()) {
			for (DHRoomRate dhRoomRate : dhRoomRates) {
				RoomRate roomRate = new RoomRate();

				roomRate.setEffectiveDate(dhRoomRate.getEffectiveDate());
				roomRate.setExpireDate(dhRoomRate.getExpireDate());
				roomRate.setNumberOfUnits(dhRoomRate.getNumberOfUnits());
				roomRate.setRoomTypeCode(dhRoomRate.getRoomTypeCode());

				ArrayOfRateType arrayOfRateType = new ArrayOfRateType();
				List<DHRate> dhRates = dhRoomRate.getRateList();
				extractRoomRate(arrayOfRoomRate, roomRate, arrayOfRateType, dhRates);
			}
		}

	}

	/**
	 * @param arrayOfRoomRate
	 * @param roomRate
	 * @param arrayOfRateType
	 * @param dhRates
	 */
	private void extractRoomRate(ArrayOfRoomRate arrayOfRoomRate, RoomRate roomRate, ArrayOfRateType arrayOfRateType,
			List<DHRate> dhRates) {
		if (dhRates != null && !dhRates.isEmpty()) {
			for (DHRate dhRate : dhRates) {
				RateType rateType = new RateType();

				DHBase dhBase = dhRate.getDhBase();
				if (null != dhBase) {
					Base base = new Base();
					base.setAmountAfterTax(dhBase.getAmountAfterTax());
					base.setAmountBeforeTax(dhBase.getAmountBeforeTax());
					base.setCurrencyCode(dhBase.getCurrencyCode());
					rateType.setBase(base);
				}

				DHTotal dhTotal = dhRate.getDhTotal();
				if (null != dhTotal) {
					Total total = new Total();
					total.setAmountAfterTax(dhTotal.getAmountAfterTax());
					total.setAmountBeforeTax(dhTotal.getAmountBeforeTax());
					total.setCurrencyCode(dhTotal.getCurrencyCode());
					rateType.setTotal(total);
				}

				arrayOfRateType.getRate().add(rateType);
				roomRate.setRates(arrayOfRateType);
				arrayOfRoomRate.getRoomRate().add(roomRate);
			}
		}
	}

	/**
	 * @param arrayOfRatePlan
	 * @param roomStay
	 * @throws DHGlobalException
	 */
	private void setRatePlans(ArrayOfRatePlan arrayOfRatePlan, DHRoomStays roomStay) throws DHGlobalException {
		logger.info("calling setRatePlans");
		List<DHRatePlan> ratePlans = roomStay.getRatePlans();
		if (null != ratePlans && !ratePlans.isEmpty()) {
			for (DHRatePlan dhRatePlan : ratePlans) {
				RatePlan ratePlan = new RatePlan();

				String ratePlanCode = dhRatePlan.getRatePlanCode();
				utility.checkNullAndEmpety(ratePlanCode, DHConstants.RATE_PLAN_CODE_ERROR);
				ratePlan.setRatePlanCode(ratePlanCode);

				String ratePlanID = dhRatePlan.getRatePlanID();
				utility.checkNullAndEmpety(ratePlanCode, DHConstants.RATE_PLAN_ID_ERROR);
				ratePlan.setRatePlanID(ratePlanID);

				arrayOfRatePlan.getRatePlan().add(ratePlan);
			}
		}
	}

	/**
	 * @param arrayOfRoomType
	 * @param roomStay
	 * @throws DHGlobalException
	 */
	private void setRoomTypes(ArrayOfRoomType arrayOfRoomType, DHRoomStays roomStay) throws DHGlobalException {
		logger.info("calling setRoomTypes");
		List<DHRoomType> roomTypes = roomStay.getRoomTypeList();
		if (roomTypes != null && !roomTypes.isEmpty()) {
			for (DHRoomType dhRoomType : roomTypes) {
				RoomType roomType = new RoomType();
				String roomTypeCode = dhRoomType.getRoomTypeCode();
				utility.checkNullAndEmpety(roomTypeCode, DHConstants.ROOM_TYPE_CODE_ERROR);
				roomType.setRoomTypeCode(roomTypeCode);
				Integer noOfUnits = dhRoomType.getNumberOfUnits();

				utility.checkNonZeroValue(noOfUnits, DHConstants.NO_OF_UNITS_ERROR);
				roomType.setNumberOfUnits(noOfUnits);

				arrayOfRoomType.getRoomType().add(roomType);
			}
		}
	}

}
