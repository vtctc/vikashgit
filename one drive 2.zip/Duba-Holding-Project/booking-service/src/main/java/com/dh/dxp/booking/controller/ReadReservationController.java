package com.dh.dxp.booking.controller;

import java.io.IOException;

import javax.xml.bind.JAXBElement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.ReadCancelHotelRequest;
import com.dh.dxp.booking.model.ReadReservationRS;
import com.dh.dxp.booking.service.ReadReservationService;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.schemas.OTAReadRQ;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */

@RestController
@RequestMapping(path = DHConstants.BASE_PATH_BKNG)
public class ReadReservationController {

	@Autowired
	private ReadReservationService readReservationService;

	private static final Logger logger = LogManager.getLogger(ReadReservationController.class);

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ReadReservationRS.class),
			@ApiResponse(code = 500, message = "Error", response = DHGlobalException.class) })
	@ApiOperation(value = "This service for read reservation  based on hotel code and confirmation number ", produces = "application/json", 
	              notes = "This functionality is used for microservices communication.")	
	@RequestMapping(value = "read_reservation", method = RequestMethod.POST, produces = DHConstants.PRODUCERS_FRMT)
	public ResponseEntity<ReadReservationRS> readReservation(
			@RequestBody  ReadCancelHotelRequest readReservationRequest) throws DHGlobalException, IOException {
		logger.info("readReservation readReservationRequest:{}", readReservationRequest);
		JAXBElement<OTAReadRQ> readlHotelRQ = readReservationService.setJAXBReadReservastionRQ(readReservationRequest);
		ReadReservationRS readReservation = readReservationService.readReservationProcess(readlHotelRQ);
		return new ResponseEntity<>(readReservation, HttpStatus.OK);
	}

}
