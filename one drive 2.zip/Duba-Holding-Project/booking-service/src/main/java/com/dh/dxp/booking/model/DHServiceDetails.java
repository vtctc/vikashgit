package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.GuestCount;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHServiceDetails {
private String serviceInventoryCode;
private String startTimestamp;
private String endTimestamp;
private List<GuestCount> guestCount;



public List<GuestCount> getGuestCount() {
	return guestCount;
}
public void setGuestCount(List<GuestCount> guestCount) {
	this.guestCount = guestCount;
}
public String getEndTimestamp() {
	return endTimestamp;
}
public void setEndTimestamp(String endTimestamp) {
	this.endTimestamp = endTimestamp;
}
public String getServiceInventoryCode() {
	return serviceInventoryCode;
}
public void setServiceInventoryCode(String serviceInventoryCode) {
	this.serviceInventoryCode = serviceInventoryCode;
}
public String getStartTimestamp() {
	return startTimestamp;
}
public void setStartTimestamp(String startTimestamp) {
	this.startTimestamp = startTimestamp;
}

}
