/**
 * 
 */
package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.DateTimeSpanType;
import com.dh.dxp.schemas.GuestCount;
import com.dh.dxp.schemas.SpecialRequest;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHRoomStays {
	
	private List<DHRoomType> roomTypeList;
	private List<DHRatePlan> ratePlans;	
	private List<DHRoomRate> roomRates;
	private List<GuestCount> guestCount;
	private DateTimeSpanType timeSpan;
	private String hotelCode;
	private List<SpecialRequest> specialRequest;
	

	public List<DHRoomType> getRoomTypeList() {
		return roomTypeList;
	}
	public void setRoomTypeList(List<DHRoomType> roomTypeList) {
		this.roomTypeList = roomTypeList;
	}
	public List<DHRatePlan> getRatePlans() {
		return ratePlans;
	}
	public void setRatePlans(List<DHRatePlan> ratePlans) {
		this.ratePlans = ratePlans;
	}
	public List<DHRoomRate> getRoomRates() {
		return roomRates;
	}
	public void setRoomRates(List<DHRoomRate> roomRates) {
		this.roomRates = roomRates;
	}
	public List<GuestCount> getGuestCount() {
		return guestCount;
	}
	public void setGuestCount(List<GuestCount> guestCount) {
		this.guestCount = guestCount;
	}
	public DateTimeSpanType getTimeSpan() {
		return timeSpan;
	}
	public void setTimeSpan(DateTimeSpanType timeSpan) {
		this.timeSpan = timeSpan;
	}
	public String getHotelCode() {
		return hotelCode;
	}
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	
	public List<SpecialRequest> getSpecialRequest() {
		return specialRequest;
	}
	public void setSpecialRequest(List<SpecialRequest> specialRequest) {
		this.specialRequest = specialRequest;
	}
	
	
	
	
	
	
	
}
