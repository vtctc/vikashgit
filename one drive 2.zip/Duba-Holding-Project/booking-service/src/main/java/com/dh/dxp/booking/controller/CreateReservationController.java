package com.dh.dxp.booking.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.DHReservationReseponse;
import com.dh.dxp.booking.model.HotelReservationRequest;
import com.dh.dxp.booking.service.CreateReservationService;
import com.dh.dxp.component.exceptions.DHGlobalException;

import io.swagger.annotations.ApiOperation;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/

@RestController
@RequestMapping(path = DHConstants.BASE_PATH_BKNG)
public class CreateReservationController {

	@Autowired
	CreateReservationService createReservationService;

	private static final Logger logger = LoggerFactory.getLogger(CreateReservationController.class);

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = DHReservationReseponse.class),
			@ApiResponse(code = 500, message = "Error", response = DHGlobalException.class) })
	@ApiOperation(value = "create reservation in the hotel based on room type and hotel code ", produces = "application/json", notes = "This functionality is used for microservices communication.")
	@RequestMapping(value = "reservations", method = RequestMethod.POST, produces = DHConstants.PRODUCERS_FRMT)
	public ResponseEntity<DHReservationReseponse> hotelBookingReservation(
			@RequestBody HotelReservationRequest hotelReservationRequest) throws DHGlobalException {
		
		logger.info("calling hotelBookingReservation controller");
		DHReservationReseponse responseEntity = createReservationService.createReservationRequest(hotelReservationRequest);
		logger.info("exit hotelBookingReservation controller");		
		return new ResponseEntity<>(responseEntity, HttpStatus.OK);
		
	}

}
	