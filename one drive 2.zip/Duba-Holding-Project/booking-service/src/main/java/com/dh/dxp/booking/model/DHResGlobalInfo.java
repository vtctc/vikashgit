/**
 * 
 */
package com.dh.dxp.booking.model;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
import java.util.List;

import com.dh.dxp.schemas.Comment;
import com.dh.dxp.schemas.HotelReservationID;
import com.dh.dxp.schemas.PaymentCard;
import com.dh.dxp.schemas.UniqueID;


/**
 * @author M1051767
 *
 */
public class DHResGlobalInfo {
	
	private List<PaymentCard> paymentCards;	
	private List<HotelReservationID> hotelResvId;	
	private List<Comment> comment;
	private List<UniqueID> profileInfo;
	
	public List<HotelReservationID> getHotelResvId() {
		return hotelResvId;
	}
	public void setHotelResvId(List<HotelReservationID> hotelResvId) {
		this.hotelResvId = hotelResvId;
	}
	
	public List<PaymentCard> getPaymentCards() {
		return paymentCards;
	}
	public void setPaymentCards(List<PaymentCard> paymentCards) {
		this.paymentCards = paymentCards;
	}
	public List<Comment> getComment() {
		return comment;
	}
	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}
	public List<UniqueID> getProfileInfo() {
		return profileInfo;
	}
	public void setProfileInfo(List<UniqueID> profileInfo) {
		this.profileInfo = profileInfo;
	}
	
}
