package com.dh.dxp.booking.utils;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.schemas.CompanyName;
import com.dh.dxp.schemas.POS;
import com.dh.dxp.schemas.RequestorID;
import com.dh.dxp.schemas.Source;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/*Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.

Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential.
*/
@Component
public class Utility {
	Logger logger = LoggerFactory.getLogger(Utility.class);

	/**
	 * @return
	 */
	public POS setPosChanel() {
		logger.info("calling createPOS");
		RequestorID requestorId = new RequestorID();
		requestorId.setIDContext(DHConstants.ID_CONTEXT);
		requestorId.setID(DHConstants.REQUESTOR_ID);

		CompanyName companyName = new CompanyName();
		companyName.setCodeContext(DHConstants.COMPANY_CODE);
		requestorId.setCompanyName(companyName);

		Source source = new Source();
		source.setRequestorId(requestorId);

		POS value = new POS();
		value.setSource(source);
		return value;
	}

	/**
	 *
	 * @param         <T>
	 * @param request
	 */
	@SuppressWarnings("unchecked")
	public <T> void jaxbObjectToXML(T request, String type, String nameSpaceURI) {
		@SuppressWarnings("rawtypes")
		JAXBElement<?> jaxbRequest = new JAXBElement(new QName(nameSpaceURI, type), request.getClass(), request);
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(request.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(jaxbRequest, sw);
			String xmlContent = sw.toString();
			logger.debug("request:{}",xmlContent);

		} catch (JAXBException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * @param response
	 */
	public <T> void jaxbObjectToJson(T response) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			String jsonString = objectMapper.writeValueAsString(response);
			logger.debug("response:{}", jsonString);
		} catch (JsonProcessingException e) {
			logger.error("Error Parsing JSON Response in Class");
		}
	}

	/**
	 * @param value
	 * @param msg
	 * @throws DHGlobalException
	 */
	public void checkNullAndEmpety(String value, String msg) throws DHGlobalException {
		if (value == null || value.trim().isEmpty()) {
			throw new DHGlobalException(msg);
		}
	}

	/**
	 * @param value
	 * @param msg
	 * @throws DHGlobalException
	 */
	public void checkNonZeroValue(Integer value, String msg) throws DHGlobalException {
		if (value <= 0) {
			throw new DHGlobalException(msg);
		}
	}
}
