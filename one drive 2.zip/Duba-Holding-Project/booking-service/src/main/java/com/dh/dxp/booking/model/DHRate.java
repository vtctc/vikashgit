package com.dh.dxp.booking.model;/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHRate {
	private DHTotal dhTotal;
	private DHBase dhBase;

	public DHTotal getDhTotal() {
		return dhTotal;
	}

	public void setDhTotal(DHTotal dhTotal) {
		this.dhTotal = dhTotal;
	}

	public DHBase getDhBase() {
		return dhBase;
	}

	public void setDhBase(DHBase dhBase) {
		this.dhBase = dhBase;
	}

}
