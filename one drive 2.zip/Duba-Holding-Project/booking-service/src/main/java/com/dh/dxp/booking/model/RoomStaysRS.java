package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.GuestCount;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class RoomStaysRS {
	private String hotelName;
	private String startDate;
	private String endDate;
	private String amountBeforeTax;
	private String amountAfterTax;
	private String taxes;
	private List <String> roomType;
	private List<GuestCount> guestCount;
	
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getAmountBeforeTax() {
		return amountBeforeTax;
	}
	public void setAmountBeforeTax(String amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}
	public String getAmountAfterTax() {
		return amountAfterTax;
	}
	public void setAmountAfterTax(String amountAfterTax) {
		this.amountAfterTax = amountAfterTax;
	}
	public String getTaxes() {
		return taxes;
	}
	public void setTaxes(String taxes) {
		this.taxes = taxes;
	}
	public List<String> getRoomType() {
		return roomType;
	}
	public void setRoomType(List<String> roomType) {
		this.roomType = roomType;
	}
	public List<GuestCount> getGuestCount() {
		return guestCount;
	}
	public void setGuestCount(List<GuestCount> guestCount) {
		this.guestCount = guestCount;
	}
}
