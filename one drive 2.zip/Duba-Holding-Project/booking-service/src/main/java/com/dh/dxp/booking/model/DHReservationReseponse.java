package com.dh.dxp.booking.model;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHReservationReseponse {

	private String crsConfirmNumber;
	private String siriusPoint;
	

	public String getSiriusPoint() {
		return siriusPoint;
	}

	public void setSiriusPoint(String siriusPoint) {
		this.siriusPoint = siriusPoint;
	}

	public String getCrsConfirmNumber() {
		return crsConfirmNumber;
	}

	public void setCrsConfirmNumber(String crsConfirmNumber) {
		this.crsConfirmNumber = crsConfirmNumber;
	}	
}
