package com.dh.dxp.booking.model;

import java.util.List;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class HotelReservationRequest {
	private String primaryLangId;	
	private List<ReservationRequest> reservationRequestList;
	
	public List<ReservationRequest> getReservationRequest() {
		return reservationRequestList;
	}
	public void setReservationRequest(List<ReservationRequest> reservationRequest) {
		this.reservationRequestList = reservationRequest;
	}
	public String getPrimaryLangId() {
		return primaryLangId;
	}
	
}
