package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.UniqueID;

import io.swagger.annotations.ApiModelProperty;

/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class ReservationRequest {
	@ApiModelProperty(position = 1, required = true)
	private List<DHRoomStays> roomStaysList;

	@ApiModelProperty(position = 2, required = true)
	private List<DHResGuests> resGuests;

	@ApiModelProperty(position = 3, required = true)
	private DHResGlobalInfo resGlobalInfo;

	@ApiModelProperty(position = 4, required = true)
	private List<DHServiceDetails> serviceDetails;
	@ApiModelProperty(position = 6, required = true)
	private UniqueID uniqueID;

	public List<DHRoomStays> getRoomStaysList() {
		return roomStaysList;
	}

	public void setRoomStaysList(List<DHRoomStays> roomStaysList) {
		this.roomStaysList = roomStaysList;
	}

	public List<DHResGuests> getResGuests() {
		return resGuests;
	}

	public void setResGuests(List<DHResGuests> resGuests) {
		this.resGuests = resGuests;
	}

	public DHResGlobalInfo getResGlobalInfo() {
		return resGlobalInfo;
	}

	public void setResGlobalInfo(DHResGlobalInfo resGlobalInfo) {
		this.resGlobalInfo = resGlobalInfo;
	}

	public List<DHServiceDetails> getServiceDetails() {
		return serviceDetails;
	}

	public void setServiceDetails(List<DHServiceDetails> serviceDetails) {
		this.serviceDetails = serviceDetails;
	}

	public UniqueID getUniqueID() {
		return uniqueID;
	}

	public void setUniqueID(UniqueID uniqueID) {
		this.uniqueID = uniqueID;
	}

}
