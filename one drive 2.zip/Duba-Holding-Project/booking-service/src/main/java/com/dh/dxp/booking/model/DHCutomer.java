package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.AddressInfo;
import com.dh.dxp.schemas.ContactPerson;
import com.dh.dxp.schemas.CustLoyalty;
import com.dh.dxp.schemas.PersonName;
import com.dh.dxp.schemas.TelephoneInfo;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHCutomer {
	private List<PersonName> personName;
	private List<TelephoneInfo> telephone;
	private List<String> email;
	private List<AddressInfo> address;
	private List<CustLoyalty> custLoyalty;
	private ContactPerson contactPerson;

	public List<PersonName> getPersonName() {
		return personName;
	}

	public void setPersonName(List<PersonName> personName) {
		this.personName = personName;
	}

	public List<TelephoneInfo> getTelephone() {
		return telephone;
	}

	public void setTelephone(List<TelephoneInfo> telephone) {
		this.telephone = telephone;
	}

	public List<String> getEmail() {
		return email;
	}

	public void setEmail(List<String> email) {
		this.email = email;
	}

	public List<AddressInfo> getAddress() {
		return address;
	}

	public void setAddress(List<AddressInfo> address) {
		this.address = address;
	}

	public List<CustLoyalty> getCustLoyalty() {
		return custLoyalty;
	}

	public void setCustLoyalty(List<CustLoyalty> custLoyalty) {
		this.custLoyalty = custLoyalty;
	}

	public ContactPerson getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(ContactPerson contactPerson) {
		this.contactPerson = contactPerson;
	}

}
