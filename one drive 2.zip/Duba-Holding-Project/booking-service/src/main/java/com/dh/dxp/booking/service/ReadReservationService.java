package com.dh.dxp.booking.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.dh.dxp.booking.config.DHConstants;
import com.dh.dxp.booking.model.ReadCancelHotelRequest;
import com.dh.dxp.booking.model.ReadReservationRS;
import com.dh.dxp.booking.model.RoomStaysRS;
import com.dh.dxp.booking.utils.Utility;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.dh.dxp.schemas.ArrayOfComment;
import com.dh.dxp.schemas.ArrayOfErrorType;
import com.dh.dxp.schemas.ArrayOfHotelReservation;
import com.dh.dxp.schemas.ArrayOfRoomStay;
import com.dh.dxp.schemas.ArrayOfRoomType;
import com.dh.dxp.schemas.ArrayOfService;
import com.dh.dxp.schemas.BasicPropertyInfoType;
import com.dh.dxp.schemas.Comment;
import com.dh.dxp.schemas.CommentType;
import com.dh.dxp.schemas.DateTimeSpanType;
import com.dh.dxp.schemas.ErrorType;
import com.dh.dxp.schemas.GuestCounts;
import com.dh.dxp.schemas.HotelReferenceGroup;
import com.dh.dxp.schemas.HotelReservation;
import com.dh.dxp.schemas.OTAHotelResRS;
import com.dh.dxp.schemas.OTAReadRQ;
import com.dh.dxp.schemas.ObjectFactory;
import com.dh.dxp.schemas.ParagraphType;
import com.dh.dxp.schemas.ReadRequest;
import com.dh.dxp.schemas.ReadRequests;
import com.dh.dxp.schemas.ResCommonDetailType;
import com.dh.dxp.schemas.ResGlobalInfo;
import com.dh.dxp.schemas.RoomDescription;
import com.dh.dxp.schemas.RoomStay;
import com.dh.dxp.schemas.RoomType;
import com.dh.dxp.schemas.Service;
import com.dh.dxp.schemas.SupplementalData;
import com.dh.dxp.schemas.TPAExtensions;
import com.dh.dxp.schemas.Total;
import com.dh.dxp.schemas.UniqueID;
import com.dh.dxp.schemas.Verification;
import com.dh.dxp.schemas.WrittenConfInst;
import com.dh.dxp.synxis.util.ServiceUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@org.springframework.stereotype.Service
public class ReadReservationService {

	private static final Logger logger = LogManager.getLogger(ReadReservationService.class);

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private Utility utility;
	
	@Autowired
	private HotelRestaurantMappingServiceImpl hotelRestaurantMappingServiceImpl;


	@Value("#{'${readReservations.action}'}")
	private String readReservationAction;

	@Value("#{'${serivce.namespaceuri}'}")
	private String nameSpaceUri;

	@HystrixCommand(ignoreExceptions = {
			DHGlobalException.class },fallbackMethod = "readReeservationFallback", commandKey = "serviceACommandKey")
	@SuppressWarnings("unchecked")
	public ReadReservationRS readReservationProcess(JAXBElement<OTAReadRQ> readlHotelRQ) throws DHGlobalException {
		logger.info(" calling Read Reservation ");
		JAXBElement<OTAHotelResRS> dhJaxbElement = (JAXBElement<OTAHotelResRS>) serviceUtils
				.sendAndRecieve(readlHotelRQ, readReservationAction);

		OTAHotelResRS hotelResRS = dhJaxbElement.getValue();
		ReadReservationRS readReservationRS = null;
		if (hotelResRS != null) {
			ArrayOfErrorType arrayOfErrorType = hotelResRS.getErrors();

			if (null != arrayOfErrorType) {
				getErrorDetail(arrayOfErrorType);

			} else {
				readReservationRS = extractReservation(hotelResRS, readReservationRS);
			}
		}
		return readReservationRS;
	}

	private ReadReservationRS extractReservation(OTAHotelResRS hotelResRS, ReadReservationRS readReservationRS) {
		ArrayOfHotelReservation hotelResvnList = hotelResRS.getHotelReservations();
		List<HotelReservation> hotelReservations;

		if (hotelResvnList != null) {
			hotelReservations = hotelResvnList.getHotelReservation();
			if (!hotelReservations.isEmpty()) {
				for (HotelReservation hotelReservation : hotelReservations) {
					readReservationRS = fetchReservation(hotelReservation);
				}
			}
		}
		return readReservationRS;
	}

	private void getErrorDetail(ArrayOfErrorType arrayOfErrorType) throws DHGlobalException {
		List<ErrorType> errorTypeList = arrayOfErrorType.getError();
		StringBuilder errorMsg = new StringBuilder();
		if (null != errorTypeList && !errorTypeList.isEmpty()) {
			for (ErrorType errorType : errorTypeList) {
				errorMsg.append((errorType.getShortText() + " "));
			}
		}
		logger.error("error:{}", errorMsg);
		throw new DHGlobalException(errorMsg.toString());
	}

	/**
	 * @param readReservationRequest
	 * @return
	 * @throws DHGlobalException
	 */
	public ReadReservationRS readReeservationFallback(JAXBElement<OTAReadRQ> readlHotelRQ) throws DHGlobalException {
		logger.debug("readlHotelRQ{}",readlHotelRQ.getValue());
		String response = "Service is down!!! Please try again later";
		logger.error(response);
		throw new DHGlobalException(response);
	}

	/**
	 * @param hotelResvn
	 * @return
	 */
	private ReadReservationRS fetchReservation(HotelReservation hotelResvn) {
		ReadReservationRS readResvnRS = new ReadReservationRS();
		if (hotelResvn != null) {

			UniqueID uniqueID = hotelResvn.getUniqueID();
			if (uniqueID != null)
				readResvnRS.setBookingNum(uniqueID.getID());

			List<RoomStaysRS> roomStayList = new ArrayList<>();
			// setting room stays details
			ArrayOfRoomStay arrayOfRoomStay = hotelResvn.getRoomStays();
			if (arrayOfRoomStay != null) {
				extractRoomStays(roomStayList, arrayOfRoomStay);
			}
			readResvnRS.setRoomStays(roomStayList);

			// end room stays details
			// setting special request
			ResGlobalInfo resGlobalInfo = hotelResvn.getResGlobalInfo();
			List<String> specialRequest = new ArrayList<>();			
			extractSpecialRequests(resGlobalInfo, specialRequest);
			readResvnRS.setSpecailRequest(specialRequest);

			
			List<String> addOnsList = new ArrayList<>();
			ArrayOfService arrayOfService = hotelResvn.getServices();
			extractAddOn(addOnsList, arrayOfService);			
			readResvnRS.setAddOns(addOnsList);

		}
		return readResvnRS;
	}

	/**
	 * @param resGlobalInfo
	 * @param addOnsList
	 */
	private void extractSpecialRequests(ResGlobalInfo resGlobalInfo, List<String> addOnsList) {
		if (resGlobalInfo != null) {
			ArrayOfComment arrayOfComment = resGlobalInfo.getComments();
			List<Comment> comments = null;
			if (arrayOfComment != null) {
				comments = arrayOfComment.getComment();
				if (!comments.isEmpty()) {
					for (Comment comment : comments) {
						String commentString = comment.getText();
						String[] commentArray = commentString.split(",");
						List<String> commentList = Arrays.asList(commentArray);
						addOnsList.addAll(commentList);
					}
				}
			}
		}
	}

	/**
	 * @param addOns
	 * @param arrayOfService
	 */
	private void extractAddOn(List<String> addOns, ArrayOfService arrayOfService) {
		List<Service> services = null;
		if (arrayOfService != null) {
			services = arrayOfService.getService();
			if (!services.isEmpty()) {
				getServiceDetail(addOns, services);
			}

		}
	}

	private void getServiceDetail(List<String> addOns, List<Service> services) {
		for (Service service : services) {
			ResCommonDetailType commonDetailType = null;
			CommentType commentType = null;
			if (service != null && (commonDetailType = service.getServiceDetails()) != null
					&& (commentType = commonDetailType.getComments()) != null) {
				List<ParagraphType> paragraphTypes = commentType.getComment();
				for (ParagraphType paragraphType : paragraphTypes) {
					if (paragraphType.getName().equals("Category")) {
						addOns.add(paragraphType.getText());
					}
				}
			}

		}
	}

	/**
	 * @param roomStayList
	 * @param arrayOfRoomStay
	 */
	private void extractRoomStays(List<RoomStaysRS> roomStayList, ArrayOfRoomStay arrayOfRoomStay) {
		List<RoomStay> roomStays = arrayOfRoomStay.getRoomStay();
		if (roomStays != null && !roomStays.isEmpty()) {
			for (RoomStay roomStay : roomStays) {
				setRoomStays(roomStayList, roomStay);
			}
		}
	}

	private void setRoomStays(List<RoomStaysRS> roomStayList, RoomStay roomStay) {
		RoomStaysRS roomStaysRS = new RoomStaysRS();
		Total totalAmount = roomStay.getTotal();
		if (totalAmount != null) {
			roomStaysRS.setAmountAfterTax(totalAmount.getAmountAfterTax());
			roomStaysRS.setAmountBeforeTax(totalAmount.getAmountBeforeTax());
		}
		// setting guest count
		GuestCounts guestCount = roomStay.getGuestCounts();
		if (guestCount != null)
			roomStaysRS.setGuestCount(guestCount.getGuestCount());

		// setting roomstay name
		ArrayOfRoomType arrayOfRoomType = roomStay.getRoomTypes();
		List<String> roomTypes = new ArrayList<>();
		if (arrayOfRoomType != null) {
			List<RoomType> roomTypesList = arrayOfRoomType.getRoomType();
			for (RoomType roomType : roomTypesList) {
				RoomDescription roomDesc = roomType.getRoomDescription();
				if (roomDesc != null) {
					roomTypes.add(roomDesc.getName());
				}
			}
		}
		// getting start and end date
		DateTimeSpanType dateTimeSpanType = roomStay.getTimeSpan();
		if (dateTimeSpanType != null) {
			roomStaysRS.setStartDate(dateTimeSpanType.getStart());
			roomStaysRS.setEndDate(dateTimeSpanType.getEnd());
		}

		// get basic property info

		HotelReferenceGroup referenceGroup = roomStay.getBasicPropertyInfo();
		if (referenceGroup != null) {
			roomStaysRS.setHotelName(referenceGroup.getHotelName());
		}
		roomStayList.add(roomStaysRS);
	}

	/**
	 * @param hotelAvailRequestObj
	 * @return
	 * @throws IOException
	 */
	/**
	 * @param readReservationRequest
	 * @return
	 * @throws DHGlobalException 
	 */
	public JAXBElement<OTAReadRQ> setJAXBReadReservastionRQ(ReadCancelHotelRequest readReservationRequest) throws DHGlobalException {
		logger.info("calling setJAXBReadReservastionRQ");
		Objects.requireNonNull(readReservationRequest,"Request can't be null");
		String bookingNum=readReservationRequest.getCrsConfirmNumber();
		String hotelCode=readReservationRequest.getHotelCode();
		utility.checkNullAndEmpety(bookingNum, DHConstants.CRS_CONFIRM_NUM_ERROR);
		utility.checkNullAndEmpety(hotelCode, DHConstants.HOTEL_CODE_ERROR);
		hotelCode=hotelRestaurantMappingServiceImpl.findBookingSystemId(hotelCode);
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		jsonObjectMapper.enable(SerializationFeature.INDENT_OUTPUT);

		ObjectFactory objectFactory = new ObjectFactory();
		OTAReadRQ otaReadRQ = objectFactory.createOTAReadRQ();

		ReadRequests readRequests = new ReadRequests();
		ReadRequest readRequest = new ReadRequest();
		UniqueID uniqueID = new UniqueID();
		
		uniqueID.setID(bookingNum);
		uniqueID.setIDContext(DHConstants.CRS_CONFIRM_CONTEXT);
		uniqueID.setType(DHConstants.CRS_CONFIRM_TYPE);
		Verification verification = new Verification();
		TPAExtensions tpaExtensions = new TPAExtensions();
		BasicPropertyInfoType basicPropertyInfoType = new BasicPropertyInfoType();
		basicPropertyInfoType.setHotelCode(hotelCode);
		tpaExtensions.setBasicPropertyInfo(basicPropertyInfoType);
		verification.setTPAExtensions(tpaExtensions);
		readRequest.setUniqueID(uniqueID);
		readRequest.setVerification(verification);
		readRequests.getReadRequest().add(readRequest);

		// WrittenConfInst
		WrittenConfInst writtenConfInst = new WrittenConfInst();
		SupplementalData supplementalData = new SupplementalData();
		writtenConfInst.setSupplementalData(supplementalData);
		otaReadRQ.setPrimaryLangId(readReservationRequest.getPrimaryLangID());
		otaReadRQ.setReturnListIndicator(DHConstants.TRUE_STRING);
		otaReadRQ.setMaxResponses(DHConstants.MAX_RESPONSE);
		otaReadRQ.setPOS(utility.setPosChanel());
		otaReadRQ.setReadRequests(readRequests);
		logger.info("otaReadRQ Response{}", otaReadRQ);
		utility.jaxbObjectToXML(otaReadRQ, "OTA_ReadRQ", nameSpaceUri);
		return new JAXBElement<>(new QName(nameSpaceUri, "OTA_ReadRQ"), OTAReadRQ.class, otaReadRQ);

	}

}
