package com.dh.dxp.booking.model;

import java.util.List;

import com.dh.dxp.schemas.UniqueID;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHProfileInfo {

	private List<UniqueID> uniqueID;
	private DHUserId userId;
	private List<DHCutomer> Cutomers;

	public List<UniqueID> getUniqueID() {
		return uniqueID;
	}

	public void setUniqueID(List<UniqueID> uniqueID) {
		this.uniqueID = uniqueID;
	}

	public DHUserId getUserId() {
		return userId;
	}

	public void setUserId(DHUserId userId) {
		this.userId = userId;
	}

	public List<DHCutomer> getCutomers() {
		return Cutomers;
	}

	public void setCutomers(List<DHCutomer> cutomers) {
		Cutomers = cutomers;
	}

	

}
