package com.dh.dxp.booking.model;
/*
*
* Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential.
* 
*/
public class DHRatePlan {
	private String ratePlanCode;
	private String ratePlanID;
	public String getRatePlanCode() {
		return ratePlanCode;
	}
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}
	public String getRatePlanID() {
		return ratePlanID;
	}
	public void setRatePlanID(String ratePlanID) {
		this.ratePlanID = ratePlanID;
	}
}
