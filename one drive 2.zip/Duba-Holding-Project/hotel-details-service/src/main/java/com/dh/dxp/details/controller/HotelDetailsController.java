/*
 *
 */
package com.dh.dxp.details.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.details.config.DHConstantUtils;
import com.dh.dxp.details.model.HotelDescriptiveRequest;
import com.dh.dxp.details.service.HotelDetailsService;

import io.swagger.annotations.ApiOperation;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
@RestController
@RequestMapping(path = DHConstantUtils.SYNXIS_BASE_PATH)
@ApiOperation(value = "Get Hotel Details", response = ResponseEntity.class)
public class HotelDetailsController {
	private static final Logger logger = LogManager.getLogger(HotelDetailsController.class);

	@Autowired
	private HotelDetailsService hotelDetailsService;

	@RequestMapping(value = "hotel-details", method = RequestMethod.POST, consumes = DHConstantUtils.CONTENT_FRMT, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<String> getHotelDetails(@RequestBody @Valid HotelDescriptiveRequest infoWrapper)
			throws DHGlobalException, IOException {
		logger.info("getHotelDetails hotelDescriptiveInfoRequest:{}", infoWrapper);
		String otaResponse = hotelDetailsService.getHotelDetailsInfo(infoWrapper);
	
		
		return new ResponseEntity<String>(otaResponse, HttpStatus.ACCEPTED);

	}
}
