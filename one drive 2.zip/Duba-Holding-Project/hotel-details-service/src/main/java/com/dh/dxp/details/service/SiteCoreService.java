package com.dh.dxp.details.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.details.config.DHConstantUtils;
import com.dh.dxp.details.model.RoomDetails;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class SiteCoreService {
	
	public static void main(String[] args) throws URISyntaxException {
		new SiteCoreService().getRoomDetailsFromSiteCore("7B484309-4129-470C-97F4-8B68A02BD6A1");
	}

	private RestTemplate restTemplate = new RestTemplate();

	private static final String SITECORE_DOMAIN_URI = "https://dxp-hospitality-dev-rg-sit-467300-cm.azurewebsites.net";

	private static final String SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS = "/sitecore/api/layout/render/jss?item=%7b{0}%7d&sc_apikey=%7b{1}%7d";

	private static final String SITECORE_API_LAYOUT_RENDER_APIKEY = "F6C5544B-E2B3-47E4-B8C0-354B492A47C8";

	private static final Logger LOGGER = LogManager.getLogger(SiteCoreService.class);

	/**
	 * @param hotelCode
	 * @return
	 * @throws URISyntaxException
	 */
	public RoomDetails getRoomDetailsFromSiteCore(final String hotelCode) throws URISyntaxException {
		LOGGER.info("Calling getRoomDetailsFromSiteCore");
		JsonNode hotelDetailSC = getHotelDataFromSitecore(hotelCode);
		JsonNode placeholders = hotelDetailSC.path("sitecore").path("route").path("placeholders");
		RoomDetails rooDetails = new RoomDetails();

		rooDetails.setBedPreferences(getPlaceholderFields(placeholders, "BedPreference", DHConstantUtils.TITLE));
		rooDetails.setSpecialRequests(getPlaceholderFields(placeholders, "SpecialRequests", DHConstantUtils.TITLE));
		rooDetails.setCancellationPolicies(
				getPlaceholderFields(placeholders, "CancellationPolicy", DHConstantUtils.DESCRIPTION));
		rooDetails.setPaymentPolicies(getPlaceholderFields(placeholders, "PaymentPolicy", DHConstantUtils.DESCRIPTION));
		rooDetails.setTaxCodes(getPlaceholderFields(placeholders, "TaxCode", DHConstantUtils.DESCRIPTION));

		return rooDetails;

	}

	/**
	 * @param placeholders
	 * @param bedPreference
	 */
	private Map<String, String> getPlaceholderFields(JsonNode placeholders, String placeHolderType, String label) {
		Map<String, String> placeholderMap = new HashMap<>();
		for (JsonNode bedPrefJson : placeholders.path(placeHolderType)) {
			JsonNode bedPrefFieldsJson = bedPrefJson.path(DHConstantUtils.FIELDS);
			for (JsonNode bedPrefItemsJson : bedPrefFieldsJson.path(DHConstantUtils.ITEMS)) {
				JsonNode bedPrefFieldJson = bedPrefItemsJson.path(DHConstantUtils.FIELDS);
				String bedPrefCode = bedPrefFieldJson.path(DHConstantUtils.CODE).path(DHConstantUtils.VALUE)
						.textValue();
				String bedPrefTitle = bedPrefFieldJson.path(label).path(DHConstantUtils.VALUE).textValue();
				placeholderMap.put(bedPrefCode, bedPrefTitle);
			}
		}
		return placeholderMap;
	}

	/**
	 * This method hits
	 * /sitecore/api/layout/render/jss?item=%{0}%7d&sc_apikey=%{1}%7d and returns
	 * same response.
	 * 
	 * @param hotelCode
	 * @return
	 * @throws URISyntaxException
	 */
	public JsonNode getHotelDataFromSitecore(final String hotelCode) throws URISyntaxException {
		final URI uri = new URI(new StringBuilder(SITECORE_DOMAIN_URI).append(SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS)
				.toString().replace("{0}", hotelCode).replace("{1}", SITECORE_API_LAYOUT_RENDER_APIKEY));
		return getDataFromSiteCore(uri);
	}

	/**
	 * This method hits sitecore and response backs the data
	 * 
	 * @param uri
	 * @return
	 */
	private JsonNode getDataFromSiteCore(final URI uri) {
		return restTemplate.getForObject(uri, JsonNode.class);
	}
}
