package com.dh.dxp.details.model;

import java.util.List;

public class HotelDetailsDTO {
	private String roomTypeCode;
	private String bedDescription;
	private List<SpecialRequestDTO> specialRequests;

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public String getBedDescription() {
		return bedDescription;
	}

	public void setBedDescription(String bedDescription) {
		this.bedDescription = bedDescription;
	}

	public List<SpecialRequestDTO> getSpecialRequestDTOList() {
		return specialRequests;
	}

	public void setSpecialRequestDTOList(List<SpecialRequestDTO> specialRequestDTOList) {
		this.specialRequests = specialRequestDTOList;
	}

}
