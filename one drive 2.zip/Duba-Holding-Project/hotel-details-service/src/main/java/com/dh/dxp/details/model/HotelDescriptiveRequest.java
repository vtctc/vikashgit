/*
 *
 */
package com.dh.dxp.details.model;

import java.util.List;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class HotelDescriptiveRequest {

	private List<GetHotelDescriptiveInfo> hotelDescriptiveInfo;
	private String echoToken;
	private String primaryLang;

	/**
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * @param echoToken the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

	/**
	 * @return the primaryLang
	 */
	public String getPrimaryLang() {
		return primaryLang;
	}

	/**
	 * @param primaryLang the primaryLang to set
	 */
	public void setPrimaryLang(String primaryLang) {
		this.primaryLang = primaryLang;
	}

	/**
	 * @return the hotelDescriptiveInfo
	 */
	public List<GetHotelDescriptiveInfo> getHotelDescriptiveInfo() {
		return hotelDescriptiveInfo;
	}

	/**
	 * @param hotelDescriptiveInfo the hotelDescriptiveInfo to set
	 */
	public void setHotelDescriptiveInfo(List<GetHotelDescriptiveInfo> hotelDescriptiveInfo) {
		this.hotelDescriptiveInfo = hotelDescriptiveInfo;
	}

}
