package com.dh.dxp.details.model;

import java.util.Map;

public class RoomDetails {
private Map<String,String> bedPreferences;
private Map<String,String> specialRequests;
private Map<String,String> paymentPolicies;
private Map<String,String> cancellationPolicies;
private Map<String,String> taxCodes;
public Map<String, String> getBedPreferences() {
	return bedPreferences;
}
public void setBedPreferences(Map<String, String> bedPreferences) {
	this.bedPreferences = bedPreferences;
}
public Map<String, String> getSpecialRequests() {
	return specialRequests;
}
public void setSpecialRequests(Map<String, String> specialRequests) {
	this.specialRequests = specialRequests;
}
public Map<String, String> getPaymentPolicies() {
	return paymentPolicies;
}
public void setPaymentPolicies(Map<String, String> paymentPolicies) {
	this.paymentPolicies = paymentPolicies;
}
public Map<String, String> getCancellationPolicies() {
	return cancellationPolicies;
}
public void setCancellationPolicies(Map<String, String> cancellationPolicies) {
	this.cancellationPolicies = cancellationPolicies;
}
public Map<String, String> getTaxCodes() {
	return taxCodes;
}
public void setTaxCodes(Map<String, String> taxCodes) {
	this.taxCodes = taxCodes;
}
	
}
