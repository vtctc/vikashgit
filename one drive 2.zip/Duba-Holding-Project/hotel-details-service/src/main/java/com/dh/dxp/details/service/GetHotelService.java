package com.dh.dxp.details.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dh.dxp.details.config.DHConstantUtils;
import com.dh.dxp.details.model.HotelDetailsDTO;
import com.dh.dxp.details.model.RoomDetails;
import com.dh.dxp.details.model.SpecialBedRequests;
import com.dh.dxp.details.model.SpecialRequestDTO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class GetHotelService {

	
	private static final Logger logger = LogManager.getLogger(GetHotelService.class);
	@Autowired
	SiteCoreService siteCoreService;

	public SpecialBedRequests getSpeicalResponceDetails(String getHotelDetails) throws IOException, URISyntaxException {
		logger.info("Hotel code :" ,getHotelDetails);
		RoomDetails roomDetails = siteCoreService.getRoomDetailsFromSiteCore("7B484309-4129-470C-97F4-8B68A02BD6A1");
		SpecialBedRequests specialBedList = new SpecialBedRequests();
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		JsonNode hotelDetailsNode = jsonObjectMapper.readTree(getHotelDetails);
		JsonNode hotelDescriptiveContentsNode = hotelDetailsNode.path(DHConstantUtils.HOTEL_DESCRIPTIVE_CONTENTS);
		
		for (JsonNode hotelDescriptiveContents : hotelDescriptiveContentsNode.path(DHConstantUtils.HOTEL_DESCRIPTIVE_CONTENT)) {

			List<HotelDetailsDTO> hotelDetailesDTOs = new ArrayList<>();

			
			JsonNode facilityInfoNode = hotelDescriptiveContents.path(DHConstantUtils.FACILITY_INFO);
			JsonNode guestRoomsNode = facilityInfoNode.path(DHConstantUtils.GUEST_ROOMS);

			for (JsonNode guestRoomsNodes : guestRoomsNode.path(DHConstantUtils.GUEST_ROOM)) {				
				List<SpecialRequestDTO> specialRequestDTOList = new ArrayList<>();
				HotelDetailsDTO hotelDetailesDTO = new HotelDetailsDTO();

				// amenities
				JsonNode amenities = guestRoomsNodes.findValue(DHConstantUtils.AMENITIES);

				for (JsonNode amenity : amenities.findValue(DHConstantUtils.AMENITY)) {
					SpecialRequestDTO specialRequestDTO = new SpecialRequestDTO();
					JsonNode roomAmenityCode = amenity.findValue(DHConstantUtils.ROOM_AMENITY_CODE);
					String specialRequestCode = roomAmenityCode.textValue();
					specialRequestDTO.setSpecialRoomAmenityCode(roomAmenityCode.asText());
					if (null != specialRequestCode) {
						Map<String, String> specialRequestMap = roomDetails.getSpecialRequests();
						String splRequestDescription = specialRequestMap.get(specialRequestCode);

						specialRequestDTO.setSpeicalCodeDetail(splRequestDescription);
					}
					specialRequestDTOList.add(specialRequestDTO);
				}
				
				JsonNode typeRoomNode = guestRoomsNodes.findValue(DHConstantUtils.TYPE_ROOM);
				JsonNode bedTypeCodeNode = typeRoomNode.findValue(DHConstantUtils.BED_TYPE_CODE);
				
				JsonNode roomTypeCode = guestRoomsNodes.findValue(DHConstantUtils.ROOM_TYPE_CODE);
				
				
				hotelDetailesDTO.setRoomTypeCode(roomTypeCode.asText());
				String bedCode = bedTypeCodeNode.textValue();
				if (null != bedCode) {
					Map<String, String> bedPrefMap = roomDetails.getBedPreferences();
					String bedDescription = bedPrefMap.get(bedCode);
					hotelDetailesDTO.setBedDescription(bedDescription);
				}

				hotelDetailesDTO.setSpecialRequestDTOList(specialRequestDTOList);
				hotelDetailesDTOs.add(hotelDetailesDTO);
			}

			specialBedList.setHotelDetailesDTO(hotelDetailesDTOs);
		}

		return specialBedList;

	}

}