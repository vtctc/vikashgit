/*
 *
 */
package com.dh.dxp.details.service;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.details.config.DHConstantUtils;
import com.dh.dxp.details.model.GetHotelDescriptiveInfo;
import com.dh.dxp.details.model.HotelDescriptiveRequest;
import com.dh.dxp.schemas.ArrayOfHotelDescriptiveInfo;
import com.dh.dxp.schemas.CompanyName;
import com.dh.dxp.schemas.FacilityInfo;
import com.dh.dxp.schemas.HotelDescriptiveInfo;
import com.dh.dxp.schemas.OTAHotelDescriptiveInfoRQ;
import com.dh.dxp.schemas.OTAHotelDescriptiveInfoRS;
import com.dh.dxp.schemas.ObjectFactory;
import com.dh.dxp.schemas.POS;
import com.dh.dxp.schemas.RequestorID;
import com.dh.dxp.schemas.Source;
import com.dh.dxp.synxis.util.ServiceUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
@Service
public class HotelDetailsService {

	private static final Logger logger = LogManager.getLogger(HotelDetailsService.class);

	@Autowired
	private ServiceUtils serviceUtils;

	@Value("#{'${hotelDescriptive.action}'}")
	private String hotelDescriptiveAction;

	@Value("#{'${serivce.namespaceuri}'}")
	private String nameSpaceUri;

	@SuppressWarnings("unchecked")
	public String getHotelDetailsInfo(HotelDescriptiveRequest hotelDescriptiveInfoWrapper)
			throws IOException, DHGlobalException {
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		String jsonReponse = null;

		logger.info(" Calling GetHotelDetailsService ");

		JAXBElement<OTAHotelDescriptiveInfoRQ> oTAHotelDescriptiveInfoRQ = setOtaRequestMessage(
				hotelDescriptiveInfoWrapper);

		final JAXBElement<OTAHotelDescriptiveInfoRS> otaResponseMessage = (JAXBElement<OTAHotelDescriptiveInfoRS>) serviceUtils
				.sendAndRecieve(oTAHotelDescriptiveInfoRQ, hotelDescriptiveAction);
		final OTAHotelDescriptiveInfoRS otaHotelDescriptiveInfoResponse = otaResponseMessage.getValue();

		logger.info("OTAHotelDescriptiveInfoResponse{}", otaHotelDescriptiveInfoResponse.toString());

		jsonReponse = jsonObjectMapper.writeValueAsString(otaHotelDescriptiveInfoResponse);
		Object json = jsonObjectMapper.readValue(jsonReponse, Object.class);
		logger.info("JSON Response{}", json);

		return jsonReponse;

	}

	/**
	 * @param hotelDescriptiveInfo
	 * @return
	 * @throws DHGlobalException
	 */
	private JAXBElement<OTAHotelDescriptiveInfoRQ> setOtaRequestMessage(HotelDescriptiveRequest hotelDescInfoWrapper)
			throws DHGlobalException {
		logger.info("Calling OTAHotelDescriptiveInfoRQ");

		ObjectMapper jsonObjectMapper = new ObjectMapper();
		jsonObjectMapper.enable(SerializationFeature.INDENT_OUTPUT);

		ArrayOfHotelDescriptiveInfo arrayHotelDesc = new ArrayOfHotelDescriptiveInfo();

		HotelDescriptiveInfo hotelDescInfo = new HotelDescriptiveInfo();

		FacilityInfo facilityInfo = new FacilityInfo();

		// Preview request Object Mapper
		formatInput(hotelDescInfoWrapper, jsonObjectMapper);

		// Set HotelDescriptiveInfo
		List<GetHotelDescriptiveInfo> hotelDescList = hotelDescInfoWrapper.getHotelDescriptiveInfo();
		if (hotelDescList != null && !hotelDescList.isEmpty()) {
			for (GetHotelDescriptiveInfo hDescInfo : hotelDescList) {
				hotelDescInfo.setChainCode(hDescInfo.getChainCode());
				hotelDescInfo.setHotelCode(hDescInfo.getHotelCode());
    			facilityInfo.setSendGuestRooms(hDescInfo.getIsSendGuestRooms());
				hotelDescInfo.setFacilityInfo(facilityInfo);
				arrayHotelDesc.getHotelDescriptiveInfo().add(hotelDescInfo);
			}
		}

		final ObjectFactory objectFactory = new ObjectFactory();
		final OTAHotelDescriptiveInfoRQ hotelDescInfoRQ = objectFactory.createOTAHotelDescriptiveInfoRQ();
		hotelDescInfoRQ.setAltLangID(hotelDescInfoWrapper.getPrimaryLang());
		hotelDescInfoRQ.setEchoToken(hotelDescInfoWrapper.getEchoToken());
		hotelDescInfoRQ.setMessageContentCode("");

		// Pos Channel Info
		POS pos = posChanel();

		hotelDescInfoRQ.setHotelDescriptiveInfos(arrayHotelDesc);

		hotelDescInfoRQ.setPOS(pos);

		return new JAXBElement<OTAHotelDescriptiveInfoRQ>(
				new QName(nameSpaceUri, "OTA_HotelDescriptiveInfoRQ"), OTAHotelDescriptiveInfoRQ.class,
				hotelDescInfoRQ);
	}

	private POS posChanel() {
		/******* Pos Channel Info Setting ******/
		CompanyName companyName = new CompanyName();
		companyName.setValue(DHConstantUtils.COMPANY_CODE);

		RequestorID requestorId = new RequestorID();
		requestorId.setCompanyName(companyName);

		requestorId.setID(DHConstantUtils.REQUESTOR_ID);

		requestorId.setIDContext(DHConstantUtils.ID_CONTEXT);

		Source source = new Source();
		source.setRequestorId(requestorId);

		POS pos = new POS();
		pos.setSource(source);
		return pos;
	}

	private void formatInput(HotelDescriptiveRequest hotelDescInfoWrapper, ObjectMapper jsonObjectMapper)
			 {
		String inputJsonRequest;
		try {
			inputJsonRequest = jsonObjectMapper.writeValueAsString(hotelDescInfoWrapper);

			Object inputJson = jsonObjectMapper.readValue(inputJsonRequest, Object.class);
			String formatedRequest = jsonObjectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(inputJson);

			logger.debug("expected Format:{}", formatedRequest);

		} catch (IOException e) {
			logger.error("Error Occured At :: Format:{} " + e.getLocalizedMessage());
		}
	}

}
