package com.dh.dxp.details.service;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.details.model.BlogResponse;

public interface SiteCoreBlogService {
	public BlogResponse getLatestBlog(String hotelCode, String langId) throws DHGlobalException;
}