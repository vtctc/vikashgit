package com.dh.dxp.details.model;

public class SpecialRequestDTO {

	private String specialRequestCode;
	private String specialReqDescription;

	/**
	 * @return the specialRoomAmenityCode
	 */
	public String getSpecialRoomAmenityCode() {
		return specialRequestCode;
	}

	/**
	 * @param specialRoomAmenityCode the specialRoomAmenityCode to set
	 */
	public void setSpecialRoomAmenityCode(String specialRequestCode) {
		this.specialRequestCode = specialRequestCode;
	}

	/**
	 * @return the speicalCodeDetail
	 */
	public String getSpeicalCodeDetail() {
		return specialReqDescription;
	}

	/**
	 * @param speicalCodeDetail the speicalCodeDetail to set
	 */
	public void setSpeicalCodeDetail(String specialReqDescription) {
		this.specialReqDescription = specialReqDescription;
	}

}
