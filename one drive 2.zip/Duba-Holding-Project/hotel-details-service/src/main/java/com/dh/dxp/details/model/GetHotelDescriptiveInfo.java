/*
 *
 */
package com.dh.dxp.details.model;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class GetHotelDescriptiveInfo {

	private String chainCode;
	private String hotelCode;
	private String isSendGuestRooms;

	public String getChainCode() {
		return chainCode;
	}

	public void setChainCode(String chainCode) {
		this.chainCode = chainCode;
	}

	public String getHotelCode() {
		return hotelCode;
	}

	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	public String getIsSendGuestRooms() {
		return isSendGuestRooms;
	}

	public void setIsSendGuestRooms(String isSendGuestRooms) {
		this.isSendGuestRooms = isSendGuestRooms;
	}

}
