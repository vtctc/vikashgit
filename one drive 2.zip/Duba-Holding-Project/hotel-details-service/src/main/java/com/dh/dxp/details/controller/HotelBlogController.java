package com.dh.dxp.details.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.details.config.DHConstantUtils;
import com.dh.dxp.details.model.BlogResponse;
import com.dh.dxp.details.service.impl.SitecoreBlogsService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = DHConstantUtils.SYNXIS_BASE_PATH)
@ApiOperation(value = "Get Hotel Blog Details", response = ResponseEntity.class)
public class HotelBlogController {

	private static final Logger logger = LogManager.getLogger(HotelBlogController.class);

	@Autowired
	private SitecoreBlogsService sitecoreBlogsService;

	@RequestMapping(value = "blog", method = RequestMethod.GET, consumes = DHConstantUtils.CONTENT_FRMT, produces = DHConstantUtils.CONTENT_FRMT)
	public BlogResponse getLatestBlog(@RequestParam String hotelCode , @RequestParam String langId) throws DHGlobalException{
		logger.info("get the blog details for hotel code:" + hotelCode);
		return sitecoreBlogsService.getLatestBlog(hotelCode,langId);
		
	}

}
