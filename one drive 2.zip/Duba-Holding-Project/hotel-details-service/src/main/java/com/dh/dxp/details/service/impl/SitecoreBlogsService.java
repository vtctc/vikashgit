package com.dh.dxp.details.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.details.model.BlogResponse;
import com.dh.dxp.details.service.SiteCoreBlogService;
import com.fasterxml.jackson.databind.JsonNode;

@Service
@PropertySource(value = { "classpath:application.properties" })
public class SitecoreBlogsService implements SiteCoreBlogService{

	private static final Logger logger = LogManager.getLogger(SitecoreBlogsService.class);

	private static final String FIELDS = "fields";
	private static final String VALUE = "value";
	
	@Value("#{'${sitecore.blogs.uri}'}")
	private String sitecoreUrl;

	public BlogResponse getLatestBlog(String hotelCode, String langId) throws DHGlobalException {
		logger.debug("Hotel code is :"+hotelCode);
		JsonNode root = restExchange(langId);
		List<BlogResponse> response = processJsonNode(root, hotelCode);

		if (CollectionUtils.isNotEmpty(response)) {
			return sortBlogs(response);
		} else {
			throw new DHGlobalException("Could not find Blogs for Code :" + hotelCode);
		}
	}

	private BlogResponse sortBlogs(List<BlogResponse> response) {

		Collections.sort(response, new Comparator<BlogResponse>() {
			DateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss'Z'");

			@Override
			public int compare(BlogResponse blog1, BlogResponse blog2) {
				try {
					return f.parse(blog1.getPublishDate()).compareTo(f.parse(blog2.getPublishDate()));
				} catch (ParseException e) {
					logger.error("Unable to parse and compare the dates : {} and {}",blog1.getPublishDate(),blog2.getPublishDate());
					throw new IllegalArgumentException(e);
				}
			}
		});
		return response.get(response.size() - 1);
	}

	private List<BlogResponse> processJsonNode(JsonNode root, String hotelCode) throws DHGlobalException {
		
		List<BlogResponse> blogResponseList = new ArrayList<>();

		JsonNode fieldsNode = root.path("sitecore").path("route").path("placeholders").path("HotelBlogs").iterator()
				.next().path(FIELDS);

		for (JsonNode itemsNode : fieldsNode.path("items")) {
			JsonNode relatedHotelsNode = itemsNode.path(FIELDS);

			for (JsonNode hotels : relatedHotelsNode.path("Related Hotels")) {
				try {
					if (hotels.path("id").asText().equalsIgnoreCase(hotelCode)) {
						logger.debug("Match found for Id :"+hotelCode);
						
						BlogResponse blogResponse = new BlogResponse();

						blogResponse.setBlogDescription(
								itemsNode.path(FIELDS).path("Short Description").path(VALUE).asText());
						blogResponse.setBlogTitle(itemsNode.path(FIELDS).path("Title").path(VALUE).asText());
						blogResponse.setCtaLink(itemsNode.path(FIELDS).path("CTA Link").path(VALUE).path("url").asText());
						blogResponse.setImageUrl(
								itemsNode.path(FIELDS).path("Thumbnail").path(VALUE).path("src").asText());
						blogResponse
								.setPublishDate(itemsNode.path(FIELDS).path("Published Date").path(VALUE).asText());

						blogResponseList.add(blogResponse);
					}
				} catch (Exception exception) {
					logger.error(exception);
					throw new DHGlobalException("An error was encountered while iterating through the blogs");
				}
			}
		}
		
		return blogResponseList;
	}

	private JsonNode restExchange(String langId) throws DHGlobalException {
		try {
			String formattedUrl = processUrl(langId);
			final URI url = new URI(formattedUrl);
			return getRestTemplate().getForObject(url, JsonNode.class);
		} catch (URISyntaxException exception) {
			throw new DHGlobalException("Not a valid URL :" + sitecoreUrl);
		}catch(Exception exception) {
			logger.error("An error occured while connecting into Sitecore .");
			logger.error(exception);
			throw new DHGlobalException(exception.getMessage());
		}
	}

	/*
	 * This method replaces the "{" and "}" characters in url which is not accepted
	 * characters in java.net, The
	 * "\\" character is used as excape character for replacing the "{","}" which
	 * are special characters in java string.
	 */
	private String processUrl(String langId) {
		String formattedUrl = sitecoreUrl.replaceAll("\\{", "%7b");
		formattedUrl = formattedUrl.replaceAll("\\}", "%7d");
		formattedUrl = formattedUrl + langId;
		logger.debug("Final forematted Url :"+formattedUrl);
		return formattedUrl;
	}

	private RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
