package com.dh.dxp.details.config;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DHConstantUtils {

	private DHConstantUtils() {
		//Adding the private constructor to hide implicit one
	}
	
	public static final String SYNXIS_BASE_PATH = "1.0/hospitality/hotels/details/";

	public static final String CONTENT_FRMT = "application/json";
	public static final String REQUESTOR_ID = "10";
	public static final String COMPANY_CODE = "WSBE";
	public static final String ID_CONTEXT = "Synxis";
	public static final String AVAILECHOTOKEN = "availability";
	public static final String RESPONSE_HEADER = "Response_Token";
	public static final String MDC_TOKEN_KEY = "Slf4jMDCFilter.UUID";
	public static final String REQUEST_HEADER = "request-Id";
	public static final String READ_RESERVATION_ECOTOKEN="Test"; 
	public static final String CANCEL_ECOTOKEN="12345";

	// hotel details
	public static final String FIELDS = "fields";
	public static final String VALUE = "value";
	public static final String DESCRIPTION = "Description";
	public static final String TITLE = "Title";
	public static final String ITEMS = "items";
	public static final String CODE = "Code";

	public static final String HOTEL_DESCRIPTIVE_CONTENTS = "hotelDescriptiveContents";
	public static final String HOTEL_DESCRIPTIVE_CONTENT = "hotelDescriptiveContent";
	public static final String FACILITY_INFO = "facilityInfo";
	public static final String GUEST_ROOMS = "guestRooms";
	public static final String GUEST_ROOM = "guestRoom";
	public static final String AMENITIES = "amenities";
	public static final String AMENITY = "amenity";
	public static final String ROOM_AMENITY_CODE = "roomAmenityCode";
	public static final String TYPE_ROOM = "typeRoom";
	public static final String BED_TYPE_CODE = "bedTypeCode";
	public static final String ROOM_TYPE_CODE = "code";


	

}
