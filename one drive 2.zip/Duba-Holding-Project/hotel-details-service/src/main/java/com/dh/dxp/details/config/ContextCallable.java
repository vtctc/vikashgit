/*
 *
 */
package com.dh.dxp.details.config;

import java.util.Map;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.microsoft.applicationinsights.core.dependencies.io.grpc.Context;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class ContextCallable<K> implements Callable<K> {
	public static final Context.Key<String> TRACE_ID_CTX_KEY = Context.key("traceId");

	private final Callable<K> callable;
	private final Map parentMDC;
	private final Context context;
	private static final Logger log = LoggerFactory.getLogger(ContextCallable.class);

	public ContextCallable(Callable<K> actual) {
		this.callable = actual;
		this.parentMDC = MDC.getCopyOfContextMap();
		String idInContext = "requestID";
		log.info("Id in Context = ", idInContext);
		context = Context.current();
	}

	@Override
	public K call() throws Exception {

		context.attach();
		String idInContext = "requestID";
		log.info("ContextCallable:call - Id in Context = ", idInContext);
		Map childMDC = MDC.getCopyOfContextMap();
		try {
			MDC.setContextMap(parentMDC);
			return callable.call();
		} finally {
			MDC.setContextMap(childMDC);
		}
	}
}
