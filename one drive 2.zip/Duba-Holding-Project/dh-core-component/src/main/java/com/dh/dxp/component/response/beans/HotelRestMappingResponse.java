package com.dh.dxp.component.response.beans;

import com.dh.dxp.component.entity.HotelRestaurantMappings;

public class HotelRestMappingResponse extends HotelRestaurantMappings {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
