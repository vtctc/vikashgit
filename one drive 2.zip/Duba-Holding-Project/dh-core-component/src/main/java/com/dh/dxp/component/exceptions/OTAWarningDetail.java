package com.dh.dxp.component.exceptions;

public class OTAWarningDetail {

	private String warningValue;
	private String warningDescription;
	private String warningCode;

	public String getWarningValue() {
		return warningValue;
	}

	public void setWarningValue(String warningValue) {
		this.warningValue = warningValue;
	}

	public String getWarningDescription() {
		return warningDescription;
	}

	public void setWarningDescription(String warningDescription) {
		this.warningDescription = warningDescription;
	}

	public String getWarningCode() {
		return warningCode;
	}

	public void setWarningCode(String warningCode) {
		this.warningCode = warningCode;
	}

}
