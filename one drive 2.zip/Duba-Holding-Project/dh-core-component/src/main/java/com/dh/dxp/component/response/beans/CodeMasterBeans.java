package com.dh.dxp.component.response.beans;

public class CodeMasterBeans {
	
	private int id;
	private String code;
	private String description;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}
	
	public String getCode() {
		return code;
	}

	public void setDescription(String description) {
		this.description = description;
	}	
}
