package com.dh.dxp.component.utils;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

@Component
public class CommonUtil {
	private RestTemplate restTemplate;
	
	private static final String CURRENCY_EXCHANGE_CACHE = "currency_exchange_cache";
	
	public CommonUtil(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	/**
	 * This method hits third party api and response backs the data
	 * Only used for get rest calls
	 * @param uri
	 * @return
	 * @throws URISyntaxException 
	 * @throws  
	 */
	//@Cacheable(value = CURRENCY_EXCHANGE_CACHE, key = "#url")
	public JsonNode getDataFromThirdParty(final String url) throws URISyntaxException {
		return restTemplate.getForObject(new URI(url), JsonNode.class);
	}

}
