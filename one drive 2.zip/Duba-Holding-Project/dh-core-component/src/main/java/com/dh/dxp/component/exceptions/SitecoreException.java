package com.dh.dxp.component.exceptions;

import org.springframework.http.HttpStatus;

import com.dh.dxp.component.exceptions.DHGlobalException;

@SuppressWarnings("serial")
public class SitecoreException extends DHGlobalException{
	
	private String message;
	private String errorCode;
	private String parameter;
	private HttpStatus status;
	
	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public SitecoreException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
	}
	
	public SitecoreException(String message, String errorCode, String parameter) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
		this.parameter = parameter;
	}
	
	public SitecoreException(String message, String errorCode, String parameter,HttpStatus status) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
		this.parameter = parameter;
		this.status = status;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
}
