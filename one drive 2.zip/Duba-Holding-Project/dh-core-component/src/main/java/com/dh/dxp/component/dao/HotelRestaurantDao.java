package com.dh.dxp.component.dao;

import java.util.Optional;

import com.dh.dxp.component.entity.HotelRestaurantMappings;
import com.dh.dxp.component.exceptions.DataNotFoundException;

public interface HotelRestaurantDao {

	public Optional<String> findBookingSystemId(String code) throws DataNotFoundException;
	
	public Optional<String> findCMSSystemId(String code) throws DataNotFoundException;
	
	public Optional<String> findJcomId(String code) throws DataNotFoundException;
	
	public HotelRestaurantMappings createHotelRestMappings(HotelRestaurantMappings mapping) throws DataNotFoundException;
	
}
