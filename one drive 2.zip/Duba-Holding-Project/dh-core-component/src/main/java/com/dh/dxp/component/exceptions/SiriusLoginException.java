package com.dh.dxp.component.exceptions;

public class SiriusLoginException extends DHGlobalException{
	private final String message;
	private final String errorCode;
	
	public SiriusLoginException(String message,String errorCode) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public String getErrorCode() {
		return errorCode;
	}	
}
