package com.dh.dxp.component;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 * 
 */
@SpringBootApplication
public class CoreCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreCommonApplication.class, args);
	}

}
