package com.dh.dxp.component.exceptions;

public class SecurityException extends Exception{

	private static final long serialVersionUID = 1L;
	private String message;
	private String errorCode;
	
	public SecurityException(String message,String errorCode) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
