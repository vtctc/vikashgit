package com.dh.dxp.component.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.dao.MappingDao;
import com.dh.dxp.component.entity.DHCodeMaster;
import com.dh.dxp.component.entity.DHCodeValue;
import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.repo.DHCodeMasterRepo;
import com.dh.dxp.component.repo.DHCodeValueRepo;

@Service
public class MappingDaoImpl implements MappingDao {

	@Autowired
	private DHCodeMasterRepo codeMasterRepo;

	@Autowired
	private DHCodeValueRepo codeValueRepo;

	public Optional<List<DHCodeMaster>> getMasterDetailsByCode(String code) throws DataNotFoundException {
		try {
			return codeMasterRepo.findByCode(code);
		} catch (Exception e) {
			throw new DataNotFoundException("Could not connect to the database!");
		}

	}

	public Optional<List<DHCodeValue>> getValueList(String code) throws DataNotFoundException {

		try {
			return codeValueRepo.findAllValues(code);
		} catch (Exception e) {
			throw new DataNotFoundException("Could not connect to the database!");
		}

	}

	public Optional<String> getHotelForSynxisValue(String hotelCode) throws DataNotFoundException {

		try {
			return codeValueRepo.findHotelForSynxisValue(hotelCode);
		} catch (Exception e) {
			throw new DataNotFoundException("Could not connect to the database! Root cause : " + e.getMessage());
		}

	}

	public Optional<String> getHotelForSitecoreValue(String hotelCode) throws DataNotFoundException {

		try {
			return codeValueRepo.findHotelForSitecoreValue(hotelCode);
		} catch (Exception e) {
			throw new DataNotFoundException("Could not connect to the database! Root cause : " + e.getMessage());
		}

	}

}
