package com.dh.dxp.component.service;

import com.dh.dxp.component.entity.HotelRestaurantMappings;
import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.response.beans.HotelRestMappingResponse;

public interface HotelRestaurantMappingService {
	
	public String findBookingSystemId(String code) throws DataNotFoundException;
	
	public String findCMSSystemId(String code) throws DataNotFoundException;
	
	public String findJcomId(String code) throws DataNotFoundException;
	
	public HotelRestMappingResponse createHotelRestMapping(HotelRestaurantMappings mapping) throws DataNotFoundException;

	
}
