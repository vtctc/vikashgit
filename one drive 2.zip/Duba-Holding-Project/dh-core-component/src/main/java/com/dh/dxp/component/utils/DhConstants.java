/**
 * 
 */
package com.dh.dxp.component.utils;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DhConstants {
	
	private DhConstants(){
		//Defining a private constructer
	}
	
	public static final String BASE_PATH_BKNG = "/api/v1/booking/";
	public static final String PRODUCERS_FRMT = "application/json";
	public static final String REQUESTOR_ID = "10";
	public static final String COMPANY_CODE = "WSBE";
	public static final String ID_CONTEXT = "Synxis";
	public static final String AVAILECHOTOKEN = "availability";
	public static final String availEchoToken = "availability";
	public static final String RESPONSE_HEADER = "Response_Token";
	public static final String MDC_TOKEN_KEY = "Slf4jMDCFilter.UUID";
	public static final String REQUEST_HEADER = "request-Id";
	public static final String DATABASE_CONNECTION_ERROR = "Could not connect to the database!";

}
