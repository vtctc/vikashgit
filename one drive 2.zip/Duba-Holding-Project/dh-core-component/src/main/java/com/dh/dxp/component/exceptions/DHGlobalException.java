package com.dh.dxp.component.exceptions;

public class DHGlobalException extends Exception {

	public DHGlobalException() {
		super();
	}

	public DHGlobalException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public DHGlobalException(String message, Throwable cause) {
		super(message, cause);
	}

	public DHGlobalException(String message) {
		super(message);
	}

	public DHGlobalException(Throwable cause) {
		super(cause);
	}
	
}
