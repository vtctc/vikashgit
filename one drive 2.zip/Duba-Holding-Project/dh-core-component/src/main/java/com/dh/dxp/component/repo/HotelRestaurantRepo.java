package com.dh.dxp.component.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dh.dxp.component.entity.HotelRestaurantMappings;

@Repository
public interface HotelRestaurantRepo extends JpaRepository<HotelRestaurantMappings, String> {

	@Query(nativeQuery = true, value = "SELECT hotel_restaurant_mapping.booking_system_id from hotel_restaurant_mapping "
			+ "where hotel_restaurant_mapping.jcom_id=(:code) OR "
			+ "hotel_restaurant_mapping.cms_id=(:code) OR " + "hotel_restaurant_mapping.pms_id=(:code)")
	Optional<String> findBookingSystemId(@Param("code") String code);

	@Query(nativeQuery = true, value = "SELECT hotel_restaurant_mapping.cms_id from hotel_restaurant_mapping "
			+ "where hotel_restaurant_mapping.jcom_id=(:code) OR "
			+ "hotel_restaurant_mapping.booking_system_id=(:code) OR " + "hotel_restaurant_mapping.pms_id=(:code)")
	Optional<String> findCMSSystemId(@Param("code") String code);

	@Query(nativeQuery = true, value = "SELECT hotel_restaurant_mapping.jcom_id from hotel_restaurant_mapping "
			+ "where hotel_restaurant_mapping.booking_system_id=(:code) OR "
			+ "hotel_restaurant_mapping.cms_id=(:code) OR " + "hotel_restaurant_mapping.pms_id=(:code)")	
	Optional<String> findJcomId(@Param("code") String code);
	

}
