package com.dh.dxp.component.exceptions;

import java.net.ConnectException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.netflix.hystrix.exception.HystrixRuntimeException;



@ControllerAdvice
public class DHExceptionhandler extends ResponseEntityExceptionHandler {

	private static LocalDateTime now = LocalDateTime.now();
	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private static final String LOGGERDATETIME = now.format(formatter);

	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		final HttpStatus methodNotAllowed = HttpStatus.METHOD_NOT_ALLOWED;
		String error = ex.getParameterName() + " parameter is missing";
		return buildResponseEntity("405", methodNotAllowed, error);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		final HttpStatus unsupportedMediaType = HttpStatus.UNSUPPORTED_MEDIA_TYPE;
		String error = " media type is not supported. Supported media types are ";
		return buildResponseEntity("415", unsupportedMediaType, error);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		final HttpStatus unprocessableEntity = HttpStatus.UNPROCESSABLE_ENTITY;
		final StringBuilder errors = new StringBuilder();
		for (final ObjectError error : ex.getBindingResult().getAllErrors()) {
			errors.append(error.getDefaultMessage());
			errors.append("  ");
		}
		return buildResponseEntity("422", unprocessableEntity, errors.toString());
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		final HttpStatus badRequest = HttpStatus.BAD_REQUEST;
		String error = "Malformed JSON request";
		return buildResponseEntity("400", badRequest, error);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		final HttpStatus notApplicable = HttpStatus.NOT_ACCEPTABLE;
		String error = "Error writing JSON output";
		return buildResponseEntity("406", notApplicable, error);
	}

	@Override
	protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		final HttpStatus forbiden = HttpStatus.FORBIDDEN;
		String error = "Error writing JSON output";
		return buildResponseEntity("403", forbiden, error);
	}

	@ExceptionHandler(javax.validation.ConstraintViolationException.class)
	public ResponseEntity<Object> handleConstraintViolation(javax.validation.ConstraintViolationException ex) {
		final HttpStatus badRequest = HttpStatus.BAD_REQUEST;
		final StringBuilder errors = new StringBuilder();
		ex.getConstraintViolations().forEach(constraintViolation->{
			errors.append(constraintViolation.getMessage());
			errors.append("  ");
		});
		
		return buildResponseEntity("400", badRequest, errors.toString());
	}

	private ResponseEntity<Object> buildResponseEntity(String errorCode, HttpStatus httpStatus, String errorMsg) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse();
		exceptionResponse.setErrorCode(errorCode);
		exceptionResponse.setErrorStatus(httpStatus);
		exceptionResponse.setLoggerDateTime(LOGGERDATETIME);
		exceptionResponse.setMessage(errorMsg);
		return new ResponseEntity<>(exceptionResponse, httpStatus);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
			WebRequest request) {
		final HttpStatus badRequestStatus = HttpStatus.BAD_REQUEST;
		String error = ex.getName() + " should be of type " + ex.getRequiredType().getName();
		return buildResponseEntity("400", badRequestStatus, error);
	}

	@ExceptionHandler(value = { DHGlobalException.class })
	public final ResponseEntity<Object> generalApplicationException(DHGlobalException ex) {
		final HttpStatus badRequestStatus = HttpStatus.BAD_REQUEST;
		String errMsg = ex.getLocalizedMessage() + "";
		return buildResponseEntity("400", badRequestStatus, errMsg);
	}

	@ExceptionHandler(value = { ConnectException.class })
	public final ResponseEntity<Object> generalApplicationException(ConnectException ex) {
		final HttpStatus badRequestStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		String errMsg = ex.getLocalizedMessage() + " : failed to get response from Synixs  ";
		return buildResponseEntity("500", badRequestStatus, errMsg);
	}
	@ExceptionHandler(OTAException.class)
	public final ResponseEntity<OTAException> handleUserNotFoundException(OTAException ex) {
		List<OTAExceptionDetail> otaException = ex.getOtaErrors();
		OTAException error = new OTAException(ex.getMessage(), otaException);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(HystrixRuntimeException.class)
	public ResponseEntity<Object> sevenRoomsTimeoutExceptionException(HystrixRuntimeException ex) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse();
		exceptionResponse.setErrorCode("408");
		exceptionResponse.setErrorStatus(HttpStatus.REQUEST_TIMEOUT);
		exceptionResponse.setLoggerDateTime(LOGGERDATETIME);
		exceptionResponse.setMessage(ex.getMessage() + " : Failed to access synxis api");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.REQUEST_TIMEOUT);
	}
	
	@ExceptionHandler(DataNotFoundException.class)
	public ResponseEntity<Object> dataNotFound(DataNotFoundException ex) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse();
		exceptionResponse.setErrorCode("404");
		exceptionResponse.setErrorStatus(HttpStatus.NOT_FOUND);
		exceptionResponse.setLoggerDateTime(LOGGERDATETIME);
		exceptionResponse.setMessage(ex.getMessage() );
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(SiriusLoginException.class)
	public ResponseEntity<Object> siriusLogin(SiriusLoginException ex) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse(HttpStatus.UNAUTHORIZED,ex.getErrorCode(),ex.getMessage(),LOGGERDATETIME);
		return new ResponseEntity<>(exceptionResponse, HttpStatus.UNAUTHORIZED);
	}
	@ExceptionHandler(SecurityException.class)
	public ResponseEntity<Object> securityException(SecurityException ex) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse();
		exceptionResponse.setErrorCode(ex.getErrorCode());
		exceptionResponse.setErrorStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		exceptionResponse.setLoggerDateTime(LOGGERDATETIME);
		exceptionResponse.setMessage(ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(SitecoreException.class)
	public ResponseEntity<Object> sitecoreHandler(SitecoreException ex) {
		DHExceptionResponse exceptionResponse = new DHExceptionResponse(ex.getStatus(),ex.getErrorCode(),ex.getMessage(),LOGGERDATETIME);
		return new ResponseEntity<>(exceptionResponse, ex.getStatus());
	}
	
}
