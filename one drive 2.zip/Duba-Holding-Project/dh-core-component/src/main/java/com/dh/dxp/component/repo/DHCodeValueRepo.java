package com.dh.dxp.component.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dh.dxp.component.entity.DHCodeValue;

@Repository
public interface DHCodeValueRepo extends JpaRepository<DHCodeValue, Integer> {

	@Query(nativeQuery = true, value = "select dh_code_value.* from dh_code_value "
			+ "where dh_code_value.code_master_id IN (SELECT dh_code_value.code_master_id "
			+ "from dh_code_value where dh_code_value.value=(:code))")
	Optional<List<DHCodeValue>> findAllValues(@Param("code") String code);

	@Query(nativeQuery = true, value = "SELECT dh_code_value.value from dh_code_value "
			+ "where dh_code_value.value=(:hotelCode) " + "and dh_code_value.value_type = 'Synxis'")
	Optional<String> findHotelForSynxisValue(@Param("hotelCode") String hotelCode);

	@Query(nativeQuery = true, value = "SELECT dh_code_value.value from dh_code_value "
			+ "where dh_code_value.value=(:hotelCode) " + "and dh_code_value.value_type = 'Sitecore'")
	Optional<String> findHotelForSitecoreValue(@Param("hotelCode") String hotelCode);

}
