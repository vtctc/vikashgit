package com.dh.dxp.component.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
@Table(name = "DH_CODE_MASTER")
public class DHCodeMaster {

	@Id
	@Column(name = "CODE_MASTER_ID",unique=true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "CODE",unique=true,nullable=false)
	private String code;

	@Column(name = "CODE_DESC")
	private String description;

	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createTime;

	@LastModifiedDate
	@Column(name = "MODIFY_TIME")
	private Date modifyTime;

	@OneToMany(mappedBy="dhCodeMaster")
	private List<DHCodeValue> dhCodeValues;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public List<DHCodeValue> getDhCodeValues() {
		return dhCodeValues;
	}

	public void setDhCodeValues(List<DHCodeValue> dhCodeValues) {
		this.dhCodeValues = dhCodeValues;
	}

}
