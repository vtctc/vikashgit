package com.dh.dxp.component.dao;

import java.util.List;
import java.util.Optional;

import com.dh.dxp.component.entity.DHCodeMaster;
import com.dh.dxp.component.entity.DHCodeValue;
import com.dh.dxp.component.exceptions.DataNotFoundException;

public interface MappingDao {

	public Optional<List<DHCodeMaster>> getMasterDetailsByCode(String code) throws DataNotFoundException;

	public Optional<List<DHCodeValue>> getValueList(String code) throws DataNotFoundException;

	public Optional<String> getHotelForSynxisValue(String hotelCode) throws DataNotFoundException;

	public Optional<String> getHotelForSitecoreValue(String hotelCode) throws DataNotFoundException;

}
