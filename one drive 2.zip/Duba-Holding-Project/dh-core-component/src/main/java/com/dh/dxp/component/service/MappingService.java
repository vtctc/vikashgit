package com.dh.dxp.component.service;

import java.util.List;

import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.response.beans.CodeMasterBeans;
import com.dh.dxp.component.response.beans.CodeValueBeans;

public interface MappingService {

	public List<CodeMasterBeans> getCodeList(String code) throws DataNotFoundException;

	public List<CodeValueBeans> getValueList(String code) throws DataNotFoundException;

	public String getBookingForSynxisValue(String hotelCode) throws DataNotFoundException;

	public String getBookingForSitecoreValue(String hotelCode) throws DataNotFoundException;

}