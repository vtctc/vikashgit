package com.dh.dxp.component.exceptions;

import java.util.List;

public class OTAException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String message;// General error message about nature of error
	private List<OTAExceptionDetail> otaErrors;// Specific errors in API request processing
	private List<OTAWarningDetail> otaWarning; // Specific Warnings in API request processing

	public List<OTAWarningDetail> getOtaWarning() {
		return otaWarning;
	}

	public void setOtaWarning(List<OTAWarningDetail> otaWarning) {
		this.otaWarning = otaWarning;
	}

	public OTAException(String message, List<OTAExceptionDetail> otaErrors) {
		this.message = message;
		this.otaErrors = otaErrors;
	}

	public OTAException(List<OTAWarningDetail> otaWarning) {
		this.otaWarning = otaWarning;
	}

	// Getter and setters
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<OTAExceptionDetail> getOtaErrors() {
		return otaErrors;
	}

	public void setOtaErrors(List<OTAExceptionDetail> otaErrors) {
		this.otaErrors = otaErrors;
	}

	@Override
	public synchronized Throwable fillInStackTrace() {
		return this;
	}

}
