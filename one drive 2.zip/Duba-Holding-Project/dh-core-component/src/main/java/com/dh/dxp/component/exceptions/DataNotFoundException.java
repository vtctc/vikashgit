package com.dh.dxp.component.exceptions;

public class DataNotFoundException extends DHGlobalException {
	
	private final String message;

	public DataNotFoundException(String message) {
		super(message);
		this.message = message;
	}

}
