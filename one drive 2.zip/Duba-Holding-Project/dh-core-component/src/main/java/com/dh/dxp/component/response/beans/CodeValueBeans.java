package com.dh.dxp.component.response.beans;

public class CodeValueBeans {

	private int codeValueId;

	private String value;

	private String description;

	private String dhValueType;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDhValueType() {
		return dhValueType;
	}

	public void setDhValueType(String dhValueType) {
		this.dhValueType = dhValueType;
	}
	
	public int getCodeValueId() {
		return codeValueId;
	}

	public void setCodeValueId(int codeValueId) {
		this.codeValueId = codeValueId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
