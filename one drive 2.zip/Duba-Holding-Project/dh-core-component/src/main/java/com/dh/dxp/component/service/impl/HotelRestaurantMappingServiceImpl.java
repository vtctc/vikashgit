package com.dh.dxp.component.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.dao.impl.HotelRestaurantDaoImpl;
import com.dh.dxp.component.entity.HotelRestaurantMappings;
import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.response.beans.HotelRestMappingResponse;
import com.dh.dxp.component.service.HotelRestaurantMappingService;
import com.microsoft.sqlserver.jdbc.StringUtils;

@Service
@RefreshScope
public class HotelRestaurantMappingServiceImpl implements HotelRestaurantMappingService {

	@Autowired
	private HotelRestaurantDaoImpl hotelRestaurantDao;

	@Override
	public String findBookingSystemId(String code) throws DataNotFoundException {
		Optional<String> bookingSystemId = hotelRestaurantDao.findBookingSystemId(code);

		if (bookingSystemId.isPresent() && !StringUtils.isEmpty(bookingSystemId.get()))
			return bookingSystemId.get();
		throw new DataNotFoundException("Booking system id is not found for this code : " + code);
	}

	@Override
	public HotelRestMappingResponse createHotelRestMapping(HotelRestaurantMappings mapping) throws DataNotFoundException {
		HotelRestaurantMappings defaultValueForMapping = defaultValueForMapping(mapping);
		HotelRestaurantMappings createHotelRestMappings = hotelRestaurantDao.createHotelRestMappings(defaultValueForMapping);
		HotelRestMappingResponse mappingResponse = new HotelRestMappingResponse();
		BeanUtils.copyProperties(createHotelRestMappings, mappingResponse);
		mappingResponse.setMessage("Successfully created");
		return mappingResponse;
	}
	
	@Override
	public String findCMSSystemId(String code) throws DataNotFoundException {
		Optional<String> cmsSystemId = hotelRestaurantDao.findCMSSystemId(code);

		if (cmsSystemId.isPresent() && !StringUtils.isEmpty(cmsSystemId.get()))
			return cmsSystemId.get();
		throw new DataNotFoundException("CMS system id is not found for this code : " + code);
	}

	@Override
	public String findJcomId(String code) throws DataNotFoundException {
		Optional<String> jcomId = hotelRestaurantDao.findJcomId(code);

		if (jcomId.isPresent() && !StringUtils.isEmpty(jcomId.get()))
			return jcomId.get();
		throw new DataNotFoundException("Jcom system id is not found for this code : " + jcomId);
	}

	private HotelRestaurantMappings defaultValueForMapping(HotelRestaurantMappings mapping) {

		if (StringUtils.isEmpty(mapping.getBookingSystemId())) {
			mapping.setBookingSystemId(null);
		}
		
		if (StringUtils.isEmpty(mapping.getJComId())) {
			mapping.setJComId(null);
		}
		
		if (StringUtils.isEmpty(mapping.getCmsId())) {
			mapping.setCmsId(null);
		}
		
		if (StringUtils.isEmpty(mapping.getPmsId())) {
			mapping.setPmsId(null);
		}
		
		return mapping;
	}

}
