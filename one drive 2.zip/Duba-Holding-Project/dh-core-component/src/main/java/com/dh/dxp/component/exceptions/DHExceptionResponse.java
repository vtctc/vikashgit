package com.dh.dxp.component.exceptions;

import org.springframework.http.HttpStatus;

public class DHExceptionResponse {

	private HttpStatus errorStatus;
	private String errorCode;
	private String message;
	private String loggerDateTime;

	public DHExceptionResponse() {
		// Default setter
	}

	public DHExceptionResponse(HttpStatus errorStatus, String errorCode, String message, String loggerDateTime) {
		super();
		this.errorStatus = errorStatus;
		this.errorCode = errorCode;
		this.message = message;
		this.loggerDateTime = loggerDateTime;
	}

	public HttpStatus getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(HttpStatus errorStatus) {
		this.errorStatus = errorStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getLoggerDateTime() {
		return loggerDateTime;
	}

	public void setLoggerDateTime(String loggerDateTime) {
		this.loggerDateTime = loggerDateTime;
	}

}
