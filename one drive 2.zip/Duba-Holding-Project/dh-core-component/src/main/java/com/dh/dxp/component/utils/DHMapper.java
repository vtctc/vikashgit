package com.dh.dxp.component.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
@Component
public class DHMapper {
	private static final String SYNXIS_HOTEL_CODE_CACHE = "synxis_hotel_code_cache";
	private static final String CMS_HOTEL_CODE_CACHE = "cms_hotel_code_cache";
	private static final long HOTEL_CODE_LAYOUT_RENDER_TTL = (long) 48 * 60 * 60 *1000;

	@Autowired
	HotelRestaurantMappingServiceImpl mappingService;
	
	@Autowired
	private HotelRestaurantMappingServiceImpl hotelRestaurantMappingServiceImpl;
	
	@Cacheable(value = CMS_HOTEL_CODE_CACHE, key = "#hotelCode")
	public  String getCmsID(String hotelCode) throws DataNotFoundException {
		return mappingService.findCMSSystemId(hotelCode);
	}
	@Cacheable(value = SYNXIS_HOTEL_CODE_CACHE, key = "#hotelCode")
	public String getSynxisID(String hotelCode) throws DataNotFoundException {
		return hotelRestaurantMappingServiceImpl.findBookingSystemId(hotelCode);
	}
	
	/**
	 * This method runs periodically and flushes cache name
	 * "sitecore_api_layout_render"
	 */
	@CacheEvict(allEntries = true, cacheNames = { SYNXIS_HOTEL_CODE_CACHE,CMS_HOTEL_CODE_CACHE
	})
	@Scheduled(fixedDelay = HOTEL_CODE_LAYOUT_RENDER_TTL)
	public boolean sitecoreApiLayoutRenderCacheEvict() {
		return true;
	}

}
