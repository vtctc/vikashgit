package com.dh.dxp.component.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dh.dxp.component.entity.DHCodeMaster;

@Repository
public interface DHCodeMasterRepo extends JpaRepository<DHCodeMaster, Integer>{

	public Optional<List<DHCodeMaster>> findByCode(String code);
	
}
