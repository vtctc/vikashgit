package com.dh.dxp.component.dao.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.dao.HotelRestaurantDao;
import com.dh.dxp.component.entity.HotelRestaurantMappings;
import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.repo.HotelRestaurantRepo;
import com.dh.dxp.component.utils.DhConstants;

@Service
public class HotelRestaurantDaoImpl implements HotelRestaurantDao {

	@Autowired
	private HotelRestaurantRepo hotelRestaurantRepo;

	@Override
	public Optional<String> findBookingSystemId(String bookingId) throws DataNotFoundException {

		try {
			return hotelRestaurantRepo.findBookingSystemId(bookingId);
		} catch (Exception e) {
			throw new DataNotFoundException(DhConstants.DATABASE_CONNECTION_ERROR);
		}

	}

	@Override
	public HotelRestaurantMappings createHotelRestMappings(HotelRestaurantMappings mapping) throws DataNotFoundException {
		try {
			return hotelRestaurantRepo.save(mapping);
		} catch (Exception e) {
			throw new DataNotFoundException("Could not update values . Root cause :" + e.getMessage());
		}
		
	}

	public Optional<String> findCMSSystemId(String code) throws DataNotFoundException{
		try {
			return hotelRestaurantRepo.findCMSSystemId(code);
		} catch (Exception e) {
			throw new DataNotFoundException(DhConstants.DATABASE_CONNECTION_ERROR);
		}
	}

	public Optional<String> findJcomId(String code) throws DataNotFoundException{
		try {
			return hotelRestaurantRepo.findJcomId(code);
		} catch (Exception e) {
			throw new DataNotFoundException(DhConstants.DATABASE_CONNECTION_ERROR);
		}
	}

}
