package com.dh.dxp.component.utils;

public class ErrorCodes {
	public String errorCode = "INVALID";
}
