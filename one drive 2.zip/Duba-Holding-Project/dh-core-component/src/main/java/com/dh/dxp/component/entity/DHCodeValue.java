package com.dh.dxp.component.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "DH_CODE_VALUE")
public class DHCodeValue {

	@Id
	@Column(name = "CODE_VALUE_ID",unique=true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codeValueId;
	
	@Column(name = "VALUE",unique=true,nullable=false)
	private String value;
	
	@Column(name = "VALUE_DESC")
	private String description;
	
	@CreatedDate
	@Column(name = "CREATED_DATE")
	private Date createTime;

	@LastModifiedDate
	@Column(name = "MODIFY_TIME")
	private Date modifyTime;

	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="CODE_MASTER_ID")
	private DHCodeMaster dhCodeMaster;
	
	@Column(name="VALUE_TYPE",nullable=false)
	private String dhValueType;
	
	public int getCodeValueId() {
		return codeValueId;
	}

	public void setCodeValueId(int codeValueId) {
		this.codeValueId = codeValueId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	@JsonIgnore
	public DHCodeMaster getDhCodeMaster() {
		return dhCodeMaster;
	}

	public void setDhCodeMaster(DHCodeMaster dhCodeMaster) {
		this.dhCodeMaster = dhCodeMaster;
	}

	public String getDhValueType() {
		return dhValueType;
	}

	public void setDhValueType(String dhValueType) {
		this.dhValueType = dhValueType;
	}
}
