package com.dh.dxp.component.exceptions;

public class OTAExceptionDetail {
	private String errorType;
	private String errorDescription;
	private String errorCode;

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public OTAExceptionDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

}
