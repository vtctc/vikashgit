package com.dh.dxp.component.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.dh.dxp.component.dao.impl.MappingDaoImpl;
import com.dh.dxp.component.entity.DHCodeMaster;
import com.dh.dxp.component.entity.DHCodeValue;
import com.dh.dxp.component.exceptions.DataNotFoundException;
import com.dh.dxp.component.response.beans.CodeMasterBeans;
import com.dh.dxp.component.response.beans.CodeValueBeans;
import com.dh.dxp.component.service.MappingService;

@Service
@RefreshScope
public class MappingServiceImpl implements MappingService {

	@Autowired
	private MappingDaoImpl codeMappingDao;

	public List<CodeMasterBeans> getCodeList(String code) throws DataNotFoundException {

		Optional<List<DHCodeMaster>> codeMappingResult = codeMappingDao.getMasterDetailsByCode(code);

		if (codeMappingResult.isPresent()) {
			List<CodeMasterBeans> codeMasterList = new ArrayList<>();

			for (DHCodeMaster codeMaster : codeMappingResult.get()) {
				CodeMasterBeans codeMasterBean = new CodeMasterBeans();
				BeanUtils.copyProperties(codeMaster, codeMasterBean);
				codeMasterList.add(codeMasterBean);
			}

			return codeMasterList;

		} else {
			throw new DataNotFoundException("Could not find Hotels/Restaurants for code : " + code);
		}
	}

	public List<CodeValueBeans> getValueList(String code) throws DataNotFoundException {
		Optional<List<DHCodeValue>> valueList = codeMappingDao.getValueList(code);

		if (valueList.isPresent()) {
			List<CodeValueBeans> codeValueList = new ArrayList<>();

			for (DHCodeValue codeValue : valueList.get()) {
				CodeValueBeans codeValueBean = new CodeValueBeans();
				BeanUtils.copyProperties(codeValue, codeValueBean);
				codeValueList.add(codeValueBean);
			}

			return codeValueList;

		} else {
			throw new DataNotFoundException("Could not find Hotels/Restaurants for code : " + code);
		}

	}

	public String getBookingForSynxisValue(String hotelCode) throws DataNotFoundException {

		Optional<String> synxisValueRes = codeMappingDao.getHotelForSynxisValue(hotelCode);
		if (synxisValueRes.isPresent() && !StringUtils.isEmpty(synxisValueRes.get()))
			return synxisValueRes.get();
		throw new DataNotFoundException("Could not find Synxis value for hotel code : " + hotelCode);

	}

	public String getBookingForSitecoreValue(String hotelCode) throws DataNotFoundException {

		Optional<String> sitecoreValueRes = codeMappingDao.getHotelForSitecoreValue(hotelCode);
		if (sitecoreValueRes.isPresent() && !StringUtils.isEmpty(sitecoreValueRes.get()))
			return sitecoreValueRes.get();
		throw new DataNotFoundException("Could not find sitecore value for hotel code : " + hotelCode);
	}

}
