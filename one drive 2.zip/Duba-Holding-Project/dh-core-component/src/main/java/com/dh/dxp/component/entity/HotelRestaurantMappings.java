package com.dh.dxp.component.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
@Table(name = "HOTEL_RESTAURANT_MAPPING")
public class HotelRestaurantMappings {
	@Id
	@Column(name = "pk",unique=true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pk;
	
	@Column(name = "mapping_domain")
	private String mappingDomain;
	
	@Column(name = "booking_system_id")
	private String bookingSystemId;
	
	@Column(name = "jcom_id")
	private String jComId;
	
	@Column(name = "cms_id")
	private String cmsId;
	
	@Column(name = "pms_id")
	private String pmsId;
	
	@CreationTimestamp
	@Column(name = "created_date")
	private Date createDate;
	
	@UpdateTimestamp
	@Column(name = "modified_date")
	private Date modifiedDate;

	public int getPk() {
		return pk;
	}

	public void setPk(int pk) {
		this.pk = pk;
	}

	public String getMappinngDomain() {
		return mappingDomain;
	}

	public void setMappinngDomain(String mappinngDomain) {
		this.mappingDomain = mappinngDomain;
	}

	public String getBookingSystemId() {
		return bookingSystemId;
	}

	public void setBookingSystemId(String bookingSystemId) {
		this.bookingSystemId = bookingSystemId;
	}

	public String getJComId() {
		return jComId;
	}

	public void setJComId(String jComId) {
		jComId = jComId;
	}

	public String getCmsId() {
		return cmsId;
	}

	public void setCmsId(String cmsId) {
		this.cmsId = cmsId;
	}

	public String getPmsId() {
		return pmsId;
	}

	public void setPmsId(String pmsId) {
		this.pmsId = pmsId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
}
