package com.dh.dxp.component.service;

import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.utils.CommonUtil;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class CurrencyExchangeService {

	private CommonUtil commonUtil;
	@Value("${ocs.money.exchange}")
	private String url;
	
	private static final String URL_CONNECTOR = "/";
	private static final String RATE ="Rate";

	public CurrencyExchangeService(CommonUtil commonUtil) {
		this.commonUtil = commonUtil;
	}

	public Double getCurrencyExchangeValue(String baseCurrency, String targetCurrency, String amount) throws URISyntaxException {
		JsonNode currencyExchangeNode = commonUtil.getDataFromThirdParty(getcurrencyExchangeURL(baseCurrency, targetCurrency));
		return getCurrencyValue(currencyExchangeNode, amount);
	}

	private String getcurrencyExchangeURL(String baseCurrency, String targetCurrency) {
		return new StringBuilder(url).append(baseCurrency).append(URL_CONNECTOR).append(targetCurrency).toString();
	}
	
	private Double getCurrencyValue(JsonNode currencyExchangeNode,String amount) {
		return currencyExchangeNode.path(0).path(RATE).asDouble()*Double.parseDouble(amount);
	}

}
