package com.dh.dxp.authorization.config;

import javax.sql.DataSource;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import com.dh.dxp.authorization.config.CustomAccessTokenConverter;
import com.dh.dxp.component.exceptions.DHGlobalException;

@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

	@Autowired
	private AuthenticationManager authenticationManger;

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private DataSource dataSource;

	@Autowired
	private CustomAccessTokenConverter customAccessTokenConverter;

	private static final Logger LOGGER = LogManager.getLogger(AuthorizationServerConfig.class);

	@Override
	public void configure(ClientDetailsServiceConfigurer client) throws DHGlobalException {
		try {
			client.jdbc(dataSource);
		} catch (Exception exception) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(exception));
			throw new DHGlobalException("Could not connect to Datasource");
		}
	}

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoint) throws DHGlobalException {
		try {
			endpoint.tokenStore(tokenStore).authenticationManager(authenticationManger);
			endpoint.accessTokenConverter(customAccessTokenConverter);
		} catch (Exception exception) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(exception));
			throw new DHGlobalException("Could not configure OAuth Server");
		}
	}

	@Override
	public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws DHGlobalException {
		try {
			oauthServer.checkTokenAccess("permitAll");
		} catch (Exception exception) {
			LOGGER.error(ExceptionUtils.getFullStackTrace(exception));
			throw new DHGlobalException("Could not initiate OAuth Server");
		}
	}

}
