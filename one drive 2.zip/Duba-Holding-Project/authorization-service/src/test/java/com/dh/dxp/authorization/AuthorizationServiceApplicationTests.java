package com.dh.dxp.authorization;

import static java.util.Collections.singleton;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.AccessTokenConverter;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dh.dxp.authorization.config.AuthorizationServerConfig;
import com.dh.dxp.authorization.config.CustomAccessTokenConverter;
import com.dh.dxp.authorization.config.CustomCorsFilter;
import com.dh.dxp.component.exceptions.DHGlobalException;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class AuthorizationServiceApplicationTests {
	
	@Mock
	OAuth2Authentication authentication;
	
	@InjectMocks
	CustomAccessTokenConverter tokenConverter;

	private String ROLE_CLIENT = "ROLE_CLIENT";
	private String ROLE_USER = "ROLE_USER";
	private OAuth2Request request;

	private UsernamePasswordAuthenticationToken userAuthentication = new UsernamePasswordAuthenticationToken("foo",
			"bar", singleton(new SimpleGrantedAuthority(ROLE_USER)));

	@Before
	public void init() {
		request = new OAuth2Request(null, "id", AuthorityUtils.commaSeparatedStringToAuthorityList(ROLE_CLIENT), true,
				singleton("read"), singleton("resource"), null, null, null);
	}

	@Test
	public void convertAccessTokenTest() { 
		Map<String,Object> dataMap = new HashMap<>();
		Date oneHourAhead = new Date(System.currentTimeMillis() + 3600 * 1000); 
		DefaultOAuth2AccessToken token = new DefaultOAuth2AccessToken("FOO");
		OAuth2Authentication authentication = new OAuth2Authentication(request, userAuthentication);
		token.setScope(authentication.getOAuth2Request().getScope());
		token.setExpiration(oneHourAhead);
		dataMap.put("jti", "JTI info");
		token.setAdditionalInformation(dataMap);
		Map<String, ?> map = tokenConverter.convertAccessToken(token, authentication);
		assertTrue(map.containsKey(AccessTokenConverter.AUD));
		assertTrue(map.containsKey(AccessTokenConverter.SCOPE));
		assertTrue(map.containsKey(AccessTokenConverter.AUTHORITIES));
		assertEquals(singleton(ROLE_USER), map.get(AccessTokenConverter.AUTHORITIES));
		OAuth2Authentication extracted = tokenConverter.extractAuthentication(map);
		assertTrue(extracted.getOAuth2Request().getResourceIds().contains("resource"));
		assertEquals("[ROLE_USER]", extracted.getAuthorities().toString());
	}
	
	@Test
	public void CorsFilterTest() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		FilterChain filterChain = new MockFilterChain();
		
		request.setMethod("OPTIONS");
		CustomCorsFilter corsFilterTest = new CustomCorsFilter();
		try {
			corsFilterTest.doFilter(request, response, filterChain);
		} catch (IOException | ServletException e) {
			e.printStackTrace();
		}
		assertTrue(response.getStatus() == 200);
	
	}
	
	@Test
	public void CorsFilterTest1() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		FilterChain filterChain = new MockFilterChain();
		
		request.setMethod("GET");
		CustomCorsFilter corsFilterTest = new CustomCorsFilter();
		try {
			corsFilterTest.doFilter(request, response, filterChain);
		} catch (IOException | ServletException e) {
			assertTrue(e instanceof ServletException);
		}
		assertTrue(response.getStatus() == 200);
	
	}
	
	@Test
	public void SecurityConfigurerTest() {
		AuthorizationServerConfig authServer = new AuthorizationServerConfig();
		AuthorizationServerSecurityConfigurer oauthServer = null;
		try {
			authServer.configure(oauthServer);
		} catch (DHGlobalException e) {
			assertTrue(e.getMessage().equals("Could not initiate OAuth Server"));
		}
	}
	
	@Test
	public void EndpointConfigurerTest() {
		AuthorizationServerConfig authServer = new AuthorizationServerConfig();
		AuthorizationServerEndpointsConfigurer oauthServer = null;
		try {
			authServer.configure(oauthServer);
		} catch (DHGlobalException e) {
			assertTrue(e.getMessage().equals("Could not configure OAuth Server"));
		}
	}
	
	@Test
	public void ClientConfigurerTest() {
		AuthorizationServerConfig authServer = new AuthorizationServerConfig();
		ClientDetailsServiceConfigurer client = null;
		try {
			authServer.configure(client);
		} catch (DHGlobalException e) {
			assertTrue(e.getMessage().equals("Could not connect to Datasource"));
		}
	}

}