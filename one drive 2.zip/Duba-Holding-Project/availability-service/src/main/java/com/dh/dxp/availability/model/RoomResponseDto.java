package com.dh.dxp.availability.model;

import java.util.List;
import java.util.Map;

public class RoomResponseDto {

	private String roomName;
	private String roomDescription;
	private Map<String, String> roomLabels;
	private String numberOfUnits;
	private String roomTypeCode;
	private List<String> images;
	private List<RoomRateDetails> roomRateDetails;
	private String minimalPrice;
	private AreaDescriptionDTO roomArea;
	private List<BedPreferences> bedPreferencesList;
	private List<SpecialRequestDTO> specialDetailList;

	public Map<String, String> getRoomLabels() {
		return roomLabels;
	}

	public void setRoomLabels(Map<String, String> roomLabels) {
		this.roomLabels = roomLabels;
	}

	public List<BedPreferences> getBedPreferencesList() {
		return bedPreferencesList;
	}

	public void setBedPreferencesList(List<BedPreferences> bedPreferencesList) {
		this.bedPreferencesList = bedPreferencesList;
	}

	public List<SpecialRequestDTO> getSpecialDetailList() {
		return specialDetailList;
	}

	public void setSpecialDetailList(List<SpecialRequestDTO> specialDetailList) {
		this.specialDetailList = specialDetailList;
	}


	public AreaDescriptionDTO getRoomArea() {
		return roomArea;
	}

	public void setRoomArea(AreaDescriptionDTO roomArea) {
		this.roomArea = roomArea;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getRoomDescription() {
		return roomDescription;
	}

	public void setRoomDescription(String roomDescription) {
		this.roomDescription = roomDescription;
	}

	public String getNumberOfUnits() {
		return numberOfUnits;
	}

	public void setNumberOfUnits(String numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public List<RoomRateDetails> getRoomRateDetails() {
		return roomRateDetails;
	}

	public void setRoomRateDetails(List<RoomRateDetails> roomRateDetails) {
		this.roomRateDetails = roomRateDetails;
	}

	public String getMinimalPrice() {
		return minimalPrice;
	}

	public void setMinimalPrice(String minimalPrice) {
		this.minimalPrice = minimalPrice;
	}

}
