package com.dh.dxp.availability.model;

public class Amenities {
private String title;
private String icon;
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getIcon() {
	return icon;
}
public void setIcon(String icon) {
	this.icon = icon;
}

}
