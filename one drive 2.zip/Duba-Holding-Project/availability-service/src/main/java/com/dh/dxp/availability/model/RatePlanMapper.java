package com.dh.dxp.availability.model;

import java.util.List;

public class RatePlanMapper {
	private String ratePlanName;
	private String ratePlanDescription;
	private List<CancellationPolicy> cancelPolicy;
	
	
	
	public List<CancellationPolicy> getCancelPolicy() {
		return cancelPolicy;
	}
	public void setCancelPolicy(List<CancellationPolicy> cancelPolicy) {
		this.cancelPolicy = cancelPolicy;
	}
	public String getRatePlanName() {
		return ratePlanName;
	}
	public void setRatePlanName(String ratePlanName) {
		this.ratePlanName = ratePlanName;
	}
	public String getRatePlanDescription() {
		return ratePlanDescription;
	}
	public void setRatePlanDescription(String ratePlanDescription) {
		this.ratePlanDescription = ratePlanDescription;
	}
	
	
}
