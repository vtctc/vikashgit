package com.dh.dxp.availability.config;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DHConstantUtils {

	private DHConstantUtils() {
		// This is DHConstantUtils
	}

	public static final String CONTENT_FRMT = "application/json";
	public static final String REQUESTOR_ID = "10";
	public static final String COMPANY_CODE = "WSBE";
	public static final String ID_CONTEXT = "Synxis";
	public static final String ECO_TOKEN = "availability";
	public static final String RESPONSE_HEADER = "Response_Token";
	public static final String MDC_TOKEN_KEY = "Slf4jMDCFilter.UUID";
	public static final String REQUEST_HEADER = "request-Id";
	public static final String READ_RESERVATION_ECOTOKEN = "Test";
	public static final String CANCEL_ECOTOKEN = "12345";

	// hotel details
	public static final String FIELDS = "fields";
	public static final String VALUE = "value";
	public static final String DESCRIPTION = "Description";
	public static final String TITLE = "Title";
	public static final String ITEMS = "items";
	public static final String CODE = "Code";

	public static final String HOTEL_DESCRIPTIVE_CONTENTS = "hotelDescriptiveContents";
	public static final String HOTEL_DESCRIPTIVE_CONTENT = "hotelDescriptiveContent";
	public static final String FACILITY_INFO = "facilityInfo";
	public static final String GUEST_ROOMS = "guestRooms";
	public static final String GUEST_ROOM = "guestRoom";
	public static final String AMENITIES = "amenities";
	public static final String AMENITY = "amenity";
	public static final String ROOM_AMENITY_CODE = "roomAmenityCode";
	public static final String TYPE_ROOM = "typeRoom";
	public static final String BED_TYPE_CODE = "bedTypeCode";
	public static final String ROOM_TYPE_CODE = "code";

	public static final String MASTER_DATA_CODE = "7B484309-4129-470C-97F4-8B68A02BD6A1";

	public static final String DEFAULT_ROOM_QUATIY = "1";

	public static final String BASE = "base";
	public static final String SERVICEDETAILS = "serviceDetails";
	public static final String PRICE = "price";
	public static final String STATUS = "status";

	public static final String START = "start";
	public static final String END = "end";
	public static final String ROOMDESCIPTION = "roomDescription";
	public static final String RATE_PLAN_CODE = "ratePlanCode";
	public static final String TOTAL = "total";
	public static final String JSS_MAIN = "jss-main";

	public static final String COMPONENET_NAME = "componentName";

	public static final String CONTENT_CAROUSEL2 = "ContentCarousel2";

	public static final String HOTEL_ROOMS = "Hotel Rooms";

	public static final String ROOM_CODE = "Room Code";
	public static final String SERVICE_INVENTORY_CODE = "serviceInventoryCode";
}
