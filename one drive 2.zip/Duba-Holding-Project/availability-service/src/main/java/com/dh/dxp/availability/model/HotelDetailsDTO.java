package com.dh.dxp.availability.model;

import java.util.List;

public class HotelDetailsDTO {
	private String bedTypeCode;
	private String roomTypeCode;
	private String bedDescription;
	private List<SpecialRequestDTO> requestDTOs;

	public String getBedTypeCode() {
		return bedTypeCode;
	}

	public void setBedTypeCode(String bedTypeCode) {
		this.bedTypeCode = bedTypeCode;
	}

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public String getBedDescription() {
		return bedDescription;
	}

	public void setBedDescription(String bedDescription) {
		this.bedDescription = bedDescription;
	}

	public List<SpecialRequestDTO> getRequestDTOs() {
		return requestDTOs;
	}

	public void setRequestDTOs(List<SpecialRequestDTO> requestDTOs) {
		this.requestDTOs = requestDTOs;
	}

}
