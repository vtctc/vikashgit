package com.dh.dxp.availability.model;

import java.io.Serializable;
import java.util.List;


/**
 * @author M1039977
 * 
 * This class is model class for data coming from sitecore
 *
 */
public class SitecoreRoomDetail implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6976937628771133598L;
	private String roomCode;
	private String areaSquareFeet;
	private String areaSquareMeter;
	private String roomTitle;
	private String roomTagline;
	private String shortDescription;
	private List<String> roomAmenities;
	private List<String> roomFacilities;
	private List<String> roomHighlights;
	private List<String>images;
	public String getRoomCode() {
		return roomCode;
	}
	public SitecoreRoomDetail setRoomCode(String roomCode) {
		this.roomCode = roomCode;
		return this;
	}
	public String getAreaSquareFeet() {
		return areaSquareFeet;
	}
	public SitecoreRoomDetail setAreaSquareFeet(String areaSquareFeet) {
		this.areaSquareFeet = areaSquareFeet;
		return this;
	}
	public String getAreaSquareMeter() {
		return areaSquareMeter;
	}
	public SitecoreRoomDetail setAreaSquareMeter(String areaSquareMeter) {
		this.areaSquareMeter = areaSquareMeter;
		return this;
	}
	public String getRoomTitle() {
		return roomTitle;
	}
	public SitecoreRoomDetail setRoomTitle(String roomTitle) {
		this.roomTitle = roomTitle;
		return this;
	}
	public String getRoomTagline() {
		return roomTagline;
	}
	public SitecoreRoomDetail setRoomTagline(String roomTagline) {
		this.roomTagline = roomTagline;
		return this;
	}
	public List<String> getRoomAmenities() {
		return roomAmenities;
	}
	public SitecoreRoomDetail setRoomAmenities(List<String> roomAmenities) {
		this.roomAmenities = roomAmenities;
		return this;
	}
	public List<String> getRoomFacilities() {
		return roomFacilities;
	}
	public SitecoreRoomDetail setRoomFacilities(List<String> roomFacilities) {
		this.roomFacilities = roomFacilities;
		return this;
	}
	public List<String> getRoomHighlights() {
		return roomHighlights;
	}
	public SitecoreRoomDetail setRoomHighlights(List<String> roomHighlights) {
		this.roomHighlights = roomHighlights;
		return this;
	}
	public List<String> getImages() {
		return images;
	}
	public SitecoreRoomDetail setImages(List<String> images) {
		this.images = images;
		return this;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public SitecoreRoomDetail setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
		return this;
	}

}
