package com.dh.dxp.availability.model;

import java.io.Serializable;
import java.util.List;


/**
 * @author M1039977
 * 
 * This class is model class for data coming from sitecore
 */
public class CMSRoomDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1444927343508938503L;
	private List<SitecoreRoomDetail> roomDetail;

	public List<SitecoreRoomDetail> getRoomDetail() {
		return roomDetail;
	}

	public CMSRoomDetails setRoomDetail(List<SitecoreRoomDetail> roomDetail) {
		this.roomDetail = roomDetail;
		return this;
	}

}
