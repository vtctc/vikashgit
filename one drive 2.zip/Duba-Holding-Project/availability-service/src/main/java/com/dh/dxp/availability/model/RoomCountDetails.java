package com.dh.dxp.availability.model;

import java.util.List;

public class RoomCountDetails {

	private String roomQuantity;
	private List<GuestDetails> guestDetails;

	public String getRoomQuantity() {
		return roomQuantity;
	}

	public void setRoomQuantity(String roomQuantity) {
		this.roomQuantity = roomQuantity;
	}

	public List<GuestDetails> getGuestDetails() {
		return guestDetails;
	}

	public void setGuestDetails(List<GuestDetails> guestDetails) {
		this.guestDetails = guestDetails;
	}

	@Override
	public String toString() {
		return "RoomCountDetails [roomQuantity=" + roomQuantity + ", guestDetails=" + guestDetails + "]";
	}

}
