package com.dh.dxp.availability.model;

import java.util.List;

public class RoomAmenityDetails {
	private String roomTypeCode;
	private List<RateTypesAmenites> rateTypeCodes;

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public List<RateTypesAmenites> getRateTypeCodes() {
		return rateTypeCodes;
	}

	public void setRateTypeCodes(List<RateTypesAmenites> rateTypeCodes) {
		this.rateTypeCodes = rateTypeCodes;
	}

}