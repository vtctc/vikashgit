package com.dh.dxp.availability.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.AreaDescriptionDTO;
import com.dh.dxp.availability.model.BedAndSpecialRequest;
import com.dh.dxp.availability.model.BedPreferences;
import com.dh.dxp.availability.model.CancellationPolicy;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.model.HotelDetailsDTO;
import com.dh.dxp.availability.model.RatePlanMapper;
import com.dh.dxp.availability.model.RoomDetails;
import com.dh.dxp.availability.model.RoomIterator;
import com.dh.dxp.availability.model.RoomRateDetails;
import com.dh.dxp.availability.model.RoomResponseDto;
import com.dh.dxp.availability.model.TaxDetails;
import com.dh.dxp.availability.utils.DHDataResource;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.utils.DhConstants;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@RefreshScope
public class RoomDetailService extends DHSoapAdapterService {
	private static final Logger logger = LogManager.getLogger(RoomDetailService.class);
	private static final long HOTEL_DETAILS_RENDER_TTL = (long) 4 * 60 * 60 * 1000;
	private static final String HOTEL_DETAILS_CACHE = "hotel_details_cache";

	@Autowired
	GetHotelService getHoteService;

	@Autowired
	private SiteCoreService siteCoreService;

	@Autowired
	DHDataResource siteCoreWrapper;

	@Autowired
	private SiteCoreAmenitiesService siteCoreAmenitiesService;

	@Value("${sitecore.master.item.id}")
	private String cmsID;

	@Autowired
	private RoomMeasurementsService roomMeasurementsService;

    RoomDetails siteCoreMaster;
	
	JsonNode siteCoreRoomData;

	public List<RoomResponseDto> getAllRoomDetails(HotelAvailRequest hotelAvailRequest) throws DHGlobalException {
		logger.info("calling getAllRoomDetails");
		HotelAvailRequest updatedHotelAvailRequest = setDefaultParameters(hotelAvailRequest);
		// calling synixis
		String jsonStr = processJAXB(updatedHotelAvailRequest);
		return finalOutPutResponse(jsonStr, hotelAvailRequest);
	}

	private List<RoomResponseDto> finalOutPutResponse(String inputJson, HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException {
		logger.info("calling finalOutPutResponse");
		String cmsHotelCode = siteCoreWrapper.getCmsID(hotelAvailRequest.getHotelCode().get(0));
		String langId = hotelAvailRequest.getPrimaryLangID();
		
		//getting site core room data
		siteCoreRoomData = siteCoreService.getHotelDataFromSitecore(cmsHotelCode, langId);
		// getting master Site core data
		siteCoreMaster = siteCoreService.getRoomDetailsFromSiteCore(cmsID, langId);
		List<RoomResponseDto> response = processJsonResponse(inputJson, hotelAvailRequest);
		// setting roomDetail data from Site core
		 
		if (response != null) {
			response = setDataFromSiteCore(response, siteCoreRoomData);
		}
		logger.info("exiting finalOutPutResponse");
		return response;

	}

	private List<RoomResponseDto> setDataFromSiteCore(List<RoomResponseDto> response, JsonNode siteCoreRoomData) {
		logger.info("calling setDataFromSiteCore");
		RoomDetails roomDetails = siteCoreAmenitiesService.getRoomtDescriptions(siteCoreRoomData);
		if (roomDetails != null) {
			Map<String, String> roomDescriptions = roomDetails.getShortDescription();
			Map<String, List<String>> roomImages = roomDetails.getRoomImage();
			Map<String, String> roomTitles = roomDetails.getRoomTitle();
			for (RoomResponseDto roomResponseDto : response) {
				String roomCode = roomResponseDto.getRoomTypeCode();
				String shortDecription = "";
				List<String> roomImage = null;
				String roomTitle = "";

				if (roomDescriptions != null || roomTitles != null || roomImages != null)
					shortDecription = roomDescriptions.get(roomCode);
				roomTitle = roomTitles.get(roomCode);
				roomImage = roomImages.get(roomCode);

				if (shortDecription != null && !shortDecription.isEmpty()) {
					roomResponseDto.setRoomDescription(shortDecription);
				}
				if (roomTitle != null && !roomTitle.isEmpty()) {
					roomResponseDto.setRoomName(roomTitle);
				}
				if (roomImage != null && !roomImage.isEmpty()) {
					roomResponseDto.setImages(roomImage);
				}
			}
		}
		logger.info("returning setDataFromSiteCore");
		return response;
	}

	private List<RoomResponseDto> processJsonResponse(String jsonStr, HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException {

		ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomRateMap = siteCoreService.getCMSRateData(siteCoreRoomData);

		// Bed and Special Request
		BedAndSpecialRequest bedRequests = initBedAndSpecialInfo(hotelAvailRequest.getHotelCode().get(0));

		ObjectMapper jsonObjectMapper = new ObjectMapper();
		List<RoomResponseDto> updatedRooms;
		JsonNode synxixNode;
		try {
			synxixNode = jsonObjectMapper.readTree(jsonStr);
		} catch (IOException e) {
			throw new DHGlobalException(e.getMessage());
		}

		// The RoomIterator object is used to avoid looping through the
		List<RoomIterator> roomDetailList = new ArrayList<>();

		JsonNode roomStayNodes = synxixNode.path("roomStays").path("roomStay");

		for (JsonNode roomStayNode : roomStayNodes) {
			JsonNode roomTypeNodes = roomStayNode.path("roomTypes").path("roomType");
			for (JsonNode roomTypeNode : roomTypeNodes) {
				RoomIterator roomIterator = new RoomIterator();
				roomIterator
						.setRoomDescription(roomTypeNode.path(DHConstantUtils.ROOMDESCIPTION).path("text").asText());
				roomIterator.setRoomName(roomTypeNode.path(DHConstantUtils.ROOMDESCIPTION).path("name").asText());
				String roomTypeCode = roomTypeNode.path("roomTypeCode").asText();
				roomIterator.setRoomTypeCode(roomTypeCode);
				roomIterator.setNumberOfUnits(roomTypeNode.path("numberOfUnits").asText());
				roomIterator.setCurrentNode(roomStayNode);
				// setting special request & bed preferences
				getBedAndSpecialInfo(bedRequests, roomIterator, roomTypeCode);

				// Remove these lines if the Image Url needs to be resolved from Sitecore
				List<String> imageUrls = new ArrayList<>();
				imageUrls.add(roomTypeNode.path(DHConstantUtils.ROOMDESCIPTION).path("image").asText());
				roomIterator.setImages(imageUrls);
				roomDetailList.add(roomIterator);
			}

		}

		updatedRooms = computeTotalPrice(roomDetailList, roomRateMap, synxixNode, siteCoreMaster);
		return updatedRooms;
	}
	@Cacheable(value = HOTEL_DETAILS_CACHE, key = "#hotelCode")
	public BedAndSpecialRequest initBedAndSpecialInfo(String hotelCode ) throws DHGlobalException {
		logger.info("calling initBedAndSpecialInfo");
		String synxisHotelCode = siteCoreWrapper.getSynxisID(hotelCode);
		BedAndSpecialRequest bedRequests = getHoteService.getSpecialReqInfo(synxisHotelCode, siteCoreMaster);
		return bedRequests;
	}

	public void getBedAndSpecialInfo(BedAndSpecialRequest bedRequests, RoomIterator roomIterator, String roomTypeCode) {
		if (!roomTypeCode.isEmpty() && null != bedRequests) {

			// Short Description Room Title

			List<HotelDetailsDTO> hotelDetailsDTOs = bedRequests.getHotelDetailesDTO();

			for (HotelDetailsDTO hotelDetailsDTO : hotelDetailsDTOs) {
				if (hotelDetailsDTO.getRoomTypeCode().equalsIgnoreCase(roomTypeCode)) {
					String bedPrefDesc = hotelDetailsDTO.getBedDescription();

					String bedTypeCode = hotelDetailsDTO.getBedTypeCode();

					List<BedPreferences> bedPrefList = new ArrayList<>();
					BedPreferences bedPreferences = new BedPreferences();
					bedPreferences.setBedDecription(bedPrefDesc);
					bedPreferences.setBedTypeCode(bedTypeCode);
					bedPrefList.add(bedPreferences);

					roomIterator.setBedPreferencesList(bedPrefList);
					roomIterator.setSpecialDetailList(hotelDetailsDTO.getRequestDTOs());
					break;
				}
			}
		}
	}

	private List<RoomResponseDto> computeTotalPrice(List<RoomIterator> rooms,
			ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomRateHashMap, JsonNode rootNode,
			RoomDetails siteCoreMaster) throws DHGlobalException {
		logger.info("calling computeTotalPrice");
		List<RoomResponseDto> updatedRoomInfo = new ArrayList<>();

		String hotelCode = rootNode.findPath("hotelRef").path("hotelCode").asText();
		hotelCode = siteCoreWrapper.getCmsID(hotelCode);
		String lang = rootNode.path("primaryLangID").asText();
		Map<String, AreaDescriptionDTO> roomMeasurment = roomMeasurementsService.getRoomAreaFromSiteCore(hotelCode,
				lang);
		// These maps are used to avoid 2 more levels of deep nesting with "for" loop
		// into the json tree
		Map<String, RoomResponseDto> roomMap = new HashMap<>();
		Map<String, RatePlanMapper> ratePlanMap = new HashMap<>();

		Map<String, String> masterCancel = siteCoreMaster.getCancellationPolicies();
		Map<String, String> masterTaxCodes = siteCoreMaster.getTaxCodes();

		for (RoomIterator room : rooms) {

			for (JsonNode rateNode : room.getCurrentNode().path("ratePlans").path("ratePlan")) {
				String ratePlanCode = rateNode.path(DHConstantUtils.RATE_PLAN_CODE).asText();

				ratePlanMatcher(ratePlanMap, masterCancel, rateNode, ratePlanCode);
			}

			for (JsonNode roomRate : room.getCurrentNode().path("roomRates").path("roomRate")) {

				if (room.getRoomTypeCode().equals(roomRate.path("roomTypeCode").asText())) {

					if (!roomMap.containsKey(room.getRoomTypeCode())) {
						roomTypeMatcher(new RoomTypeMatcherParameter(roomRateHashMap, siteCoreMaster, roomMeasurment, 
								roomMap, ratePlanMap, masterTaxCodes, room,
								roomRate));
					}

					else {
						priceMatcher(roomMap, ratePlanMap, room, roomRate);
					}

				}

			}
		}

		for (Map.Entry<String, RoomResponseDto> roomData : roomMap.entrySet()) {
			updatedRoomInfo.add(roomMap.get(roomData.getKey()));
		}

		logger.info("returning computeTotalPrice");
		return updatedRoomInfo;
	}

	public void priceMatcher(Map<String, RoomResponseDto> roomMap, Map<String, RatePlanMapper> ratePlanMap,
			RoomIterator room, JsonNode roomRate) {
		RoomRateDetails roomRateDetails = new RoomRateDetails();
		String amountAfterTax = roomRate.findValue(DHConstantUtils.TOTAL).path("amountAfterTax").asText();
		String ratePlanCode = roomRate.findValue(DHConstantUtils.RATE_PLAN_CODE).asText();
		roomRateDetails.setAmountBeforeTax(roomRate.findValue(DHConstantUtils.TOTAL).path("amountBeforeTax").asText());
		roomRateDetails.setAmountAfterTax(amountAfterTax);
		roomRateDetails.setRatePlanCode(ratePlanCode);

		roomRateDetails.setRatePlanName(ratePlanMap.get(ratePlanCode).getRatePlanName());
		roomRateDetails.setRatePlanDescription(ratePlanMap.get(ratePlanCode).getRatePlanDescription());

		String minPrice = roomMap.get(room.getRoomTypeCode()).getMinimalPrice();

		if (Double.parseDouble(amountAfterTax) < Double.parseDouble(minPrice)) {
			roomMap.get(room.getRoomTypeCode()).setMinimalPrice(minPrice);
		}

		roomMap.get(room.getRoomTypeCode()).getRoomRateDetails().add(roomRateDetails);
	}

	public void roomTypeMatcher(RoomTypeMatcherParameter parameterObject) {
		String roomTypeCode = parameterObject.room.getRoomTypeCode();
		AreaDescriptionDTO areaDescriptionDTO = parameterObject.roomMeasurment.get(roomTypeCode);
		RoomResponseDto updatedRoom = new RoomResponseDto();
		List<RoomRateDetails> roomRateList = new ArrayList<>();

		updatedRoom.setImages(parameterObject.room.getImages());
		updatedRoom.setRoomLabels(parameterObject.roomDetails.getRoomLabels());
		updatedRoom.setRoomDescription(parameterObject.room.getRoomDescription());
		updatedRoom.setRoomName(parameterObject.room.getRoomName());
		updatedRoom.setRoomTypeCode(parameterObject.room.getRoomTypeCode());
		updatedRoom.setSpecialDetailList(parameterObject.room.getSpecialDetailList());
		updatedRoom.setBedPreferencesList(parameterObject.room.getBedPreferencesList());
		updatedRoom.setRoomArea(areaDescriptionDTO);

		RoomRateDetails roomRateDetails = new RoomRateDetails();
		String amountAfterTax = parameterObject.roomRate.findValue(DHConstantUtils.TOTAL).path("amountAfterTax").asText();

		String ratePlanCode = parameterObject.roomRate.findValue(DHConstantUtils.RATE_PLAN_CODE).asText();
		roomRateDetails.setAmountAfterTax(amountAfterTax);
		roomRateDetails.setRatePlanCode(ratePlanCode);

		roomRateDetails.setRatePlanName(parameterObject.ratePlanMap.get(ratePlanCode).getRatePlanName());
		roomRateDetails.setRatePlanDescription(parameterObject.ratePlanMap.get(ratePlanCode).getRatePlanDescription());

		roomRateDetails.setAmountBeforeTax(parameterObject.roomRate.findValue(DHConstantUtils.TOTAL).path("amountBeforeTax").asText());
		roomRateDetails = setSitecoreRateInfo(roomRateDetails, roomTypeCode, parameterObject.roomRateHashMap,
				parameterObject.ratePlanMap.get(ratePlanCode), parameterObject.roomRate, parameterObject.masterTaxCodes);

		updatedRoom.setMinimalPrice(amountAfterTax);
		roomRateList.add(roomRateDetails);

		updatedRoom.setRoomRateDetails(roomRateList);
		parameterObject.roomMap.put(parameterObject.room.getRoomTypeCode(), updatedRoom);
	}

	public void ratePlanMatcher(Map<String, RatePlanMapper> ratePlanMap, Map<String, String> masterCancel,
			JsonNode rateNode, String ratePlanCode) {
		if (!ratePlanMap.containsKey(ratePlanCode)) {
			RatePlanMapper ratePlanObject = new RatePlanMapper();
			ratePlanObject.setRatePlanName(rateNode.path("ratePlanName").asText());
			ratePlanObject.setRatePlanDescription(rateNode.path("ratePlanDescription").path("text").asText());
			List<CancellationPolicy> policyList = new ArrayList<>();
			for (JsonNode cancelPolicy : rateNode.path("cancelPenalties").path("cancelPenalty")) {
				CancellationPolicy cancellationPolicy = new CancellationPolicy();
				String cancelCode = cancelPolicy.path("policyCode").asText();
				if (!cancelCode.isEmpty()) {
					cancellationPolicy.setCode(cancelCode);
					cancellationPolicy.setDescription(masterCancel.get(cancelCode));
				}
				policyList.add(cancellationPolicy);
			}
			ratePlanObject.setCancelPolicy(policyList);
			ratePlanMap.put(ratePlanCode, ratePlanObject);
		}
	}

	private RoomRateDetails setSitecoreRateInfo(RoomRateDetails roomRateDetails, String roomTypeCode,
			ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomRateMap, RatePlanMapper ratePlanMapper,
			JsonNode roomRate, Map<String, String> masterTaxCodes) {
		String ratePlanCode = roomRate.findValue(DHConstantUtils.RATE_PLAN_CODE).asText();

		try {
			roomRateDetails.setRatePlanName(roomRateMap.get(roomTypeCode).get(ratePlanCode).getRatePlanName());
			roomRateDetails
					.setRatePlanDescription(roomRateMap.get(roomTypeCode).get(ratePlanCode).getRatePlanDescription());
			roomRateDetails.setRateFeatures(roomRateMap.get(roomTypeCode).get(ratePlanCode).getRateFeatures());

		} catch (NullPointerException e) {
			logger.error("Could not set Sitecore Room Rate Details for room code : " + roomTypeCode + " and rate plan :"
					+ ratePlanCode);
		}

		roomRateDetails.setCancellationPolicies(ratePlanMapper.getCancelPolicy());

		// Set Tax details from Sitecore map
		JsonNode taxCodeSynxis = roomRate.findValue(DHConstantUtils.TOTAL).path("taxes");
		List<TaxDetails> taxDetailsList = new ArrayList<>();

		for (JsonNode taxNode : taxCodeSynxis.path("tax")) {
			TaxDetails taxDetails = new TaxDetails();
			String taxCode = taxNode.path("code").asText();
			if (!taxCode.isEmpty()) {
				taxDetails.setTaxCode(taxCode);
				taxDetails.setTaxDescription(masterTaxCodes.get(taxCode));
			}
			taxDetailsList.add(taxDetails);

		}
		roomRateDetails.setTaxDetails(taxDetailsList);
		return roomRateDetails;
	}

	@Override
	protected <T> T processJsonResponse(String jsonStr) throws DHGlobalException {
		return null;
	}

	@Override
	protected <T> T processJsonAddOnResponse(String jsonStr, String hotelCode) throws DHGlobalException {
		return null;
	}

	/**
	 * This method runs periodically and flushes cache name
	 * "sitecore_api_layout_render"
	 */
	@CacheEvict(allEntries = true, cacheNames = { HOTEL_DETAILS_CACHE })
	@Scheduled(fixedDelay = HOTEL_DETAILS_RENDER_TTL)
	public boolean sitecoreApiLayoutRenderCacheEvict() {
		logger.debug("Cache is getting flushed-------");
		return true;
	}

	public HotelAvailRequest setDefaultParameters(HotelAvailRequest hotelAvailRequest) {

		HotelAvailRequest updatedRequest = hotelAvailRequest;

		// Setting isCalendarPricing to false since the default parameters are set here.
		updatedRequest.setCalenderPricing(false);

		updatedRequest.setEchoToken(DhConstants.availEchoToken);
		updatedRequest.setExactMatchOnly(false);
		updatedRequest.setBestOnly(false);
		updatedRequest.setSummaryOnly(false);
		updatedRequest.setHotelStayOnly(false);

		return updatedRequest;
	}

}
