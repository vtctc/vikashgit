package com.dh.dxp.availability.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.AddOnComments;
import com.dh.dxp.availability.model.AddOnDatePrice;
import com.dh.dxp.availability.model.AddOnsResponse;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.model.TimeSpan;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class AddOnService extends DHSoapAdapterService {

	@Autowired
	private SiteCoreService siteCoreService;

	private static final Logger logger = LogManager.getLogger(AddOnService.class);

	public AddOnsResponse getAddOnDetails(HotelAvailRequest hotelAvailRequest) throws DHGlobalException {

		logger.debug(" calling adOnAvailabality ");

		String jsonStr = processJAXB(hotelAvailRequest);
		return processJsonAddOnResponse(jsonStr, hotelAvailRequest.getCmsId());
	}

	@SuppressWarnings("unchecked")
	@Override
	protected AddOnsResponse processJsonAddOnResponse(String jsonStr, String cmsId) throws DHGlobalException {
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		try {
			JsonNode otaNode = jsonObjectMapper.readTree(jsonStr);
			AddOnsResponse response = new AddOnsResponse();
			String lang = otaNode.path("primaryLangID").asText();
			JsonNode addOnNode = siteCoreService.getHotelDataFromSitecore(cmsId, lang);
			// reading data from sitecore
			Map<String, AddOnComments> addOnnSiteCore = readingDataFromSiteCore(addOnNode);
			JsonNode servicesNode = otaNode.path("services");
			AddOnComments comments = null;

			List<TimeSpan> timeSpans = new ArrayList<>();

			Map<String, AddOnDatePrice> addonDatePrice = new HashMap<>();

			for (JsonNode hotelServiceNode : servicesNode.path("service")) {
				TimeSpan timeSpan = new TimeSpan();
				String servieInventoryNode = hotelServiceNode.path("serviceInventoryCode").asText();
				if (servieInventoryNode.equalsIgnoreCase("BABY")) {
					if (!CollectionUtils.isEmpty(addOnnSiteCore))
						comments = addOnnSiteCore.get(servieInventoryNode);

					if (comments == null) {
						comments = new AddOnComments();
						JsonNode serviceDetailsNode = hotelServiceNode.path(DHConstantUtils.SERVICEDETAILS)
								.path("comments");

						addOnCommentsMatcher(comments, hotelServiceNode, serviceDetailsNode);
					}

					JsonNode timeSpanNode = hotelServiceNode.path(DHConstantUtils.SERVICEDETAILS).path("timeSpan");
					timeSpan.setStart(timeSpanNode.path("start").asText().replace("T", ""));
					timeSpan.setEnd(timeSpanNode.path("end").asText().replace("T", ""));
					timeSpan.setIncrement(timeSpanNode.path("increment").asText());

					timeSpans.add(timeSpan);

					addOnPriceMaycher(timeSpans, addonDatePrice, hotelServiceNode);
				}

			}

			// converting Map to List
			List<AddOnDatePrice> addOnDatePrices = convertingMapToList(addonDatePrice);

			if (comments != null) {
				response.setServiceInventoryCode(comments.getServiceInventoryCode());
				response.setDescription(comments.getText());
				response.setImage(comments.getImage());
				response.setTitle(comments.getName());
			}
			response.setAddOnDateRange(addOnDatePrices);

			return response;

		} catch (IOException e) {
			throw new DHGlobalException(e.getLocalizedMessage());

		}

	}

	public void addOnCommentsMatcher(AddOnComments comments, JsonNode hotelServiceNode, JsonNode serviceDetailsNode) {
		for (JsonNode commentNode : serviceDetailsNode.path("comment")) {

			if (commentNode.path("name").asText().equalsIgnoreCase("Image")) {
				comments.setImage(commentNode.path("image").asText());
			} else if (commentNode.path("name").asText().equalsIgnoreCase("Title")) {
				comments.setName(commentNode.path("text").asText());
			} else if (commentNode.path("name").asText().equalsIgnoreCase("Description")) {
				comments.setText(commentNode.path("text").asText());
			}

			comments.setServiceInventoryCode(hotelServiceNode.path(DHConstantUtils.SERVICE_INVENTORY_CODE).asText());

		}
	}

	public void addOnPriceMaycher(List<TimeSpan> timeSpans, Map<String, AddOnDatePrice> addonDatePrice,
			JsonNode hotelServiceNode) {
		for (JsonNode priceNode : hotelServiceNode.path("price")) {
			AddOnDatePrice addOnDatePrice = new AddOnDatePrice();
			JsonNode baseNode = priceNode.path("base");
			JsonNode effectiveDateNode = priceNode.path("effectiveDate");
			addOnDatePrice.setAmountTaxAfter(baseNode.path("amountAfterTax").asText());
			addOnDatePrice.setAmountTaxBefore(baseNode.path("amountBeforeTax").asText());
			addOnDatePrice.setTimeSpan(timeSpans); // setting in map
			addonDatePrice.put(effectiveDateNode.asText(), addOnDatePrice);

		}
	}

	private Map<String, AddOnComments> readingDataFromSiteCore(JsonNode addOnNode) {
		Map<String, AddOnComments> addOnnSiteCore = new HashMap<>();
		for (JsonNode addONNodeList : addOnNode.findPath("Add On")) {
			AddOnComments addOnComments = new AddOnComments();
			JsonNode addOnFields = addONNodeList.path("fields");
			String inventoryCode = addOnFields.path("Add on Code").path(DHConstantUtils.VALUE).asText();
			addOnComments.setText(addOnFields.path("Tagline").path(DHConstantUtils.VALUE).asText());
			addOnComments.setImage(addOnFields.path("Thumbnail").path(DHConstantUtils.VALUE).path("src").asText());
			addOnComments.setName(addOnFields.path("Title").path(DHConstantUtils.VALUE).asText());
			addOnComments.setServiceInventoryCode(inventoryCode);
			if (inventoryCode != null && !inventoryCode.isEmpty())
				addOnnSiteCore.put(inventoryCode, addOnComments);

		}
		return addOnnSiteCore;
	}

	private List<AddOnDatePrice> convertingMapToList(Map<String, AddOnDatePrice> map) {
		List<AddOnDatePrice> addOnDateRangeList = new ArrayList<>();
		for (Entry<String, AddOnDatePrice> key : map.entrySet()) {
			AddOnDatePrice dateRange = new AddOnDatePrice();

			dateRange.setDateRange(key.getKey());
			AddOnDatePrice addOnTimeSpan = map.get(key.getKey());
			dateRange.setAmountTaxAfter(addOnTimeSpan.getAmountTaxAfter());
			dateRange.setAmountTaxBefore(addOnTimeSpan.getAmountTaxBefore());
			dateRange.setTimeSpan(addOnTimeSpan.getTimeSpan());
			addOnDateRangeList.add(dateRange);

		}
		return addOnDateRangeList;
	}

	@Override
	protected <T> T processJsonResponse(String jsonStr) {

		return null;
	}

}
