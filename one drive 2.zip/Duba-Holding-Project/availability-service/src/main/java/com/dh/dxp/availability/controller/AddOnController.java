package com.dh.dxp.availability.controller;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.AddOnsResponse;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.service.AddOnService;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.exceptions.OTAException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RefreshScope
@RestController
@RequestMapping("${synxis.base.path}")
@Api(value = "Everything about Hotel Availability Info", tags = { "Hotel Room Deatils , Hotel Price Details etc.," })
public class AddOnController {

	@Autowired
	private AddOnService adOnService;

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = OTAException.class) })
	@ApiOperation(value = "Fetch details of Add-Ons information based on Hotel Code.", produces = "application/json", notes = "This functionality is used for microservices communication. ")
	@RequestMapping(value = "addons", method = RequestMethod.POST, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<AddOnsResponse> addonsDetails(@RequestBody HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException {

		hotelAvailRequest.setNonRoom(true);
		AddOnsResponse adOnDTO = adOnService.getAddOnDetails(hotelAvailRequest);
		return new ResponseEntity<>(adOnDTO, HttpStatus.ACCEPTED);

	}
}
