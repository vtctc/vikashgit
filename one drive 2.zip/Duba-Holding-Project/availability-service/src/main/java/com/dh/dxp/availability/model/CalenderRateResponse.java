package com.dh.dxp.availability.model;

import java.util.List;

import com.dh.dxp.component.exceptions.OTAWarningDetail;

public class CalenderRateResponse {

	private String hotelCode;
	private String hotelName;
	private List<AvailableStatusDetail> availableDetails;
	private OTAWarningDetail oTAWarningDetail;
	public String getHotelCode() {
		return hotelCode;
	}
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public List<AvailableStatusDetail> getAvailableDetails() {
		return availableDetails;
	}
	public void setAvailableDetails(List<AvailableStatusDetail> availableDetails) {
		this.availableDetails = availableDetails;
	}
	public OTAWarningDetail getoTAWarningDetail() {
		return oTAWarningDetail;
	}
	public void setoTAWarningDetail(OTAWarningDetail oTAWarningDetail) {
		this.oTAWarningDetail = oTAWarningDetail;
	}

}
