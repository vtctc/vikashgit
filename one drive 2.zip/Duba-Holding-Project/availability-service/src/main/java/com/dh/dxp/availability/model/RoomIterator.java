package com.dh.dxp.availability.model;

import com.fasterxml.jackson.databind.JsonNode;

public class RoomIterator extends RoomResponseDto {

	private JsonNode currentNode;

	public JsonNode getCurrentNode() {
		return currentNode;
	}

	public void setCurrentNode(JsonNode currentNode) {
		this.currentNode = currentNode;
	}

}
