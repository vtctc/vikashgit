package com.dh.dxp.availability.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.HotelDetailsDTO;
import com.dh.dxp.availability.model.RoomDetails;
import com.dh.dxp.availability.model.BedAndSpecialRequest;
import com.dh.dxp.availability.model.GetHotelDescriptiveInfo;
import com.dh.dxp.availability.model.HotelDescriptiveRequest;
import com.dh.dxp.availability.model.SpecialRequestDTO;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class GetHotelService {

	@Autowired
	private HotelDetailsService hotelDetailsService;

	public BedAndSpecialRequest getSpecialReqInfo(String hotelCode, RoomDetails siteCoreMaster) throws DHGlobalException {
		HotelDescriptiveRequest hotelDescriptiveInfoWrapper = new HotelDescriptiveRequest();
		hotelDescriptiveInfoWrapper.setEchoToken("12345");
		List<GetHotelDescriptiveInfo> hotelDescriptiveInfo = new ArrayList<>();
		GetHotelDescriptiveInfo descriptiveInfo = new GetHotelDescriptiveInfo();
		descriptiveInfo.setHotelCode(hotelCode);
		descriptiveInfo.setChainCode("JG");
		descriptiveInfo.setIsSendGuestRooms("True");
		hotelDescriptiveInfo.add(descriptiveInfo);
		hotelDescriptiveInfoWrapper.setHotelDescriptiveInfo(hotelDescriptiveInfo);
		// getHoteService.getSpeicalResponceDetails
		String hotelDescriptiveJson = hotelDetailsService.getHotelDetailsInfo(hotelDescriptiveInfoWrapper);
		return processSpeicalReqInfo(hotelDescriptiveJson, siteCoreMaster);
	}

	public BedAndSpecialRequest processSpeicalReqInfo(String getHotelDetails, RoomDetails siteCoreMaster)
			throws DHGlobalException {
		BedAndSpecialRequest specialBedList = new BedAndSpecialRequest();
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		JsonNode hotelDetailsNode;
		try {
			hotelDetailsNode = jsonObjectMapper.readTree(getHotelDetails);
		} catch (IOException e) {
               throw new DHGlobalException(e.getMessage());
		}
		JsonNode hotelDescriptiveContentsNode = hotelDetailsNode.path(DHConstantUtils.HOTEL_DESCRIPTIVE_CONTENTS);
		List<HotelDetailsDTO> hotelDetailesDTOs = new ArrayList<>();
		for (JsonNode guestRoomsNodes : hotelDescriptiveContentsNode.findPath(DHConstantUtils.GUEST_ROOM)) {
			List<SpecialRequestDTO> specialRequestDTOList = new ArrayList<>();
			HotelDetailsDTO hotelDetailesDTO = new HotelDetailsDTO();

			// amenities
			JsonNode amenities = guestRoomsNodes.findValue(DHConstantUtils.AMENITIES);

			for (JsonNode amenity : amenities.findValue(DHConstantUtils.AMENITY)) {
				SpecialRequestDTO specialRequestDTO = new SpecialRequestDTO();
				JsonNode roomAmenityCode = amenity.findValue(DHConstantUtils.ROOM_AMENITY_CODE);
				String specialRequestCode = roomAmenityCode.textValue();
				specialRequestDTO.setSpecialRoomAmenityCode(roomAmenityCode.asText());
				if (null != specialRequestCode) {
					Map<String, String> specialRequestMap = siteCoreMaster.getSpecialRequests();
					String splRequestDescription = specialRequestMap.get(specialRequestCode);

					specialRequestDTO.setSpeicalCodeDetail(splRequestDescription);
				}
				specialRequestDTOList.add(specialRequestDTO);
			}

			JsonNode typeRoomNode = guestRoomsNodes.findValue(DHConstantUtils.TYPE_ROOM);
			JsonNode bedTypeCodeNode = typeRoomNode.findValue(DHConstantUtils.BED_TYPE_CODE);

			JsonNode roomTypeCode = guestRoomsNodes.findValue(DHConstantUtils.ROOM_TYPE_CODE);

			hotelDetailesDTO.setRoomTypeCode(roomTypeCode.asText());
			String bedCode = bedTypeCodeNode.textValue();
			hotelDetailesDTO.setBedTypeCode(bedCode);
			if (null != bedCode) {
				Map<String, String> bedPrefMap = siteCoreMaster.getBedPreferences();
				String bedDescription = bedPrefMap.get(bedCode);
				hotelDetailesDTO.setBedDescription(bedDescription);
			}
			hotelDetailesDTO.setRequestDTOs(specialRequestDTOList);
			hotelDetailesDTOs.add(hotelDetailesDTO);
		}

		specialBedList.setHotelDetailesDTO(hotelDetailesDTOs);

		return specialBedList;

	}

}