package com.dh.dxp.availability.service;

import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import com.dh.dxp.availability.model.AreaDescriptionDTO;
import com.dh.dxp.availability.model.RatePlanMapper;
import com.dh.dxp.availability.model.RoomDetails;
import com.dh.dxp.availability.model.RoomIterator;
import com.dh.dxp.availability.model.RoomRateDetails;
import com.dh.dxp.availability.model.RoomResponseDto;
import com.fasterxml.jackson.databind.JsonNode;

public class RoomTypeMatcherParameter {
	ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomRateHashMap;
	RoomDetails roomDetails;
	Map<String, AreaDescriptionDTO> roomMeasurment;
	Map<String, RoomResponseDto> roomMap;
	Map<String, RatePlanMapper> ratePlanMap;
	Map<String, String> masterTaxCodes;
	RoomIterator room;
	JsonNode roomRate;

	public RoomTypeMatcherParameter(ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomRateHashMap,
			RoomDetails roomDetails, Map<String, AreaDescriptionDTO> roomMeasurment,
			Map<String, RoomResponseDto> roomMap, Map<String, RatePlanMapper> ratePlanMap,
			Map<String, String> masterTaxCodes, RoomIterator room, JsonNode roomRate) {
		this.roomRateHashMap = roomRateHashMap;
		this.roomDetails = roomDetails;
		this.roomMeasurment = roomMeasurment;
		this.roomMap = roomMap;
		this.ratePlanMap = ratePlanMap;
		this.masterTaxCodes = masterTaxCodes;
		this.room = room;
		this.roomRate = roomRate;
	}
}