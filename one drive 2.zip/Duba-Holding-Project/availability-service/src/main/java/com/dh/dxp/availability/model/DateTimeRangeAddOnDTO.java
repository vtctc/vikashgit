package com.dh.dxp.availability.model;

import java.util.List;

public class DateTimeRangeAddOnDTO {

	private String timeStat;
	private String timeEnd;
	private String increment;
	private List<EffectiveDateRangeAddOnDTO> effectiveDateRangeAddOnDTO;

	public String getTimeStat() {
		return timeStat;
	}

	public void setTimeStat(String timeStat) {
		this.timeStat = timeStat;
	}

	public String getTimeEnd() {
		return timeEnd;
	}

	public void setTimeEnd(String timeEnd) {
		this.timeEnd = timeEnd;
	}

	public String getIncrement() {
		return increment;
	}

	public void setIncrement(String increment) {
		this.increment = increment;
	}

	public List<EffectiveDateRangeAddOnDTO> getEffectiveDateRangeAddOnDTO() {
		return effectiveDateRangeAddOnDTO;
	}

	public void setEffectiveDateRangeAddOnDTO(List<EffectiveDateRangeAddOnDTO> effectiveDateRangeAddOnDTO) {
		this.effectiveDateRangeAddOnDTO = effectiveDateRangeAddOnDTO;
	}

}
