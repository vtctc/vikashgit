package com.dh.dxp.availability.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;

import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.utils.OtaMessageUtil;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.exceptions.OTAException;
import com.dh.dxp.component.exceptions.OTAExceptionDetail;
import com.dh.dxp.schemas.OTAHotelAvailRQ;
import com.dh.dxp.schemas.OTAHotelAvailRS;
import com.dh.dxp.synxis.util.ServiceUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@RefreshScope
public abstract class DHSoapAdapterService {

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private OtaMessageUtil paramSetterUtil;

	@Value("#{'${checkAvailabality.action}'}")
	private String availabilityAction;

	protected String processJAXB(HotelAvailRequest hotelAvailRequest) throws DHGlobalException{

		ObjectMapper jsonObjectMapper = new ObjectMapper();
		String jsonResponseString = null;

		JAXBElement<OTAHotelAvailRQ> oTAHotelAvailRQ = paramSetterUtil.getAvailableOtaRequestMessage(hotelAvailRequest);

		@SuppressWarnings("unchecked")
		final JAXBElement<OTAHotelAvailRS> dhJaxbElement = (JAXBElement<OTAHotelAvailRS>) serviceUtils
				.sendAndRecieve(oTAHotelAvailRQ, availabilityAction);
		final OTAHotelAvailRS oTAHotelAvailResponse = dhJaxbElement.getValue();
		try {
			jsonResponseString = jsonObjectMapper.writeValueAsString(oTAHotelAvailResponse);
			otaValidator(jsonResponseString);
		} catch (JsonProcessingException e) {
			throw new DHGlobalException("Error Parsing JSON Response in Class :" + this.getClass());
		}
		return jsonResponseString;
	}

	/**
	 * @param jsonObjectMapper
	 * @param jsonResponseString
	 * @throws IOException
	 */
	private void otaValidator(String jsonResponseString) throws DHGlobalException {
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		JsonNode rootNode = null;
		try {
			rootNode = jsonObjectMapper.readTree(jsonResponseString);
		} catch (IOException e) {
			throw new DHGlobalException("Error Parsing JSON Response in otaValidator method :" + this.getClass());
		}
		JsonNode otaErrors = rootNode.path("errors");

		if (otaErrors != null && otaErrors.size() > 0) {
			ArrayNode slaidsErrorNode = (ArrayNode) otaErrors.get("error");
			Iterator<JsonNode> slaidsErrorIterator = slaidsErrorNode.elements();
			List<OTAExceptionDetail> oTAExceptionList = new ArrayList<>();
			OTAExceptionDetail otaExceptionDetail = new OTAExceptionDetail();
			while (slaidsErrorIterator.hasNext()) {

				// Error Block
				JsonNode slaidErrNode = slaidsErrorIterator.next();
				otaExceptionDetail.setErrorCode(slaidErrNode.get("code").asText());
				otaExceptionDetail.setErrorDescription(slaidErrNode.get("shortText").asText());
				otaExceptionDetail.setErrorType(slaidErrNode.get("type").asText());
				oTAExceptionList.add(otaExceptionDetail);
			}

			throw new OTAException("Validation Failed", oTAExceptionList);
		}
	}

	protected abstract <T> T processJsonResponse(String jsonStr) throws DHGlobalException, IOException;

	protected abstract <T> T processJsonAddOnResponse(String jsonStr, String hotelCode) throws DHGlobalException, IOException;
}
