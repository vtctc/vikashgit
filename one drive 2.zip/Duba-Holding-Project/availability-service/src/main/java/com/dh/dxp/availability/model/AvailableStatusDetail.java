package com.dh.dxp.availability.model;

public class AvailableStatusDetail {
	
	private String availabalityStatus;
	private String startDate;
	private String endDate;
	private String price;
	private String currencyCode;
	public String getAvailabalityStatus() {
		return availabalityStatus;
	}
	public void setAvailabalityStatus(String availabalityStatus) {
		this.availabalityStatus = availabalityStatus;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	
	

}
