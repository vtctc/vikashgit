package com.dh.dxp.availability.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.CalenderRateResponse;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.model.RoomResponseDto;
import com.dh.dxp.availability.service.CalendarPricingService;
import com.dh.dxp.availability.service.RoomDetailService;
import com.dh.dxp.availability.service.SiteCoreService;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.exceptions.OTAException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
@RefreshScope
@RestController
@RequestMapping("${synxis.base.path}")
@Api(value = "Everything about Hotel Availability Info", tags = { "Hotel Room Deatils , Hotel Price Details etc.," })
public class AvailabilityController {

	@Autowired
	private CalendarPricingService calendarPricingService;

	@Autowired
	private RoomDetailService roomDetailService;

	@Autowired
	private SiteCoreService siteCoreService;

	@Autowired
	private org.springframework.core.env.Environment environment;

	private static final Logger logger = LogManager.getLogger(AvailabilityController.class);

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = OTAException.class) })
	@ApiOperation(value = "Fetch details of available hotel and rooms based on Hotel Code.", produces = "application/json", notes = "This functionality is used for microservices communication. ")

	@RequestMapping(value = "room-details", method = RequestMethod.POST, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<List<RoomResponseDto>> roomDetails(@RequestBody @Valid HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException {
		logger.info("room-details hotelAvailRequest:{}", hotelAvailRequest);
		List<RoomResponseDto> responseDTO = roomDetailService.getAllRoomDetails(hotelAvailRequest);
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);

	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = OTAException.class) })
	@ApiOperation(value = "Fetch details of calendar pricing information based on Hotel Code.", produces = "application/json", notes = "This functionality is used for microservices communication. ")
	@RequestMapping(value = "calendar-pricing", method = RequestMethod.POST, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<CalenderRateResponse> rateAvailabality(
			@RequestBody @Valid HotelAvailRequest hotelAvailRequest) throws DHGlobalException, IOException {
		logger.info("calendar-pricing hotelAvailRequest:{}", hotelAvailRequest);
		hotelAvailRequest.setCalenderPricing(true);
		return new ResponseEntity<>(calendarPricingService.getRateDetails(hotelAvailRequest), HttpStatus.ACCEPTED);

	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = OTAException.class) })
	@ApiOperation(value = "Fetch all details of Synxix system based on Hotel Code.", produces = "application/json", notes = "This functionality is used for microservices communication. ")

	@RequestMapping(value = "get-availability", method = RequestMethod.POST, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<String> checkAvailability(@RequestBody @Valid HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException, IOException {
		logger.info("checkAvailabilityByHotelCode hotelAvailRequest:{}", hotelAvailRequest);
		String otaResponse = calendarPricingService.getHotelAvailabilityInfo(hotelAvailRequest);
		return new ResponseEntity<>(otaResponse, HttpStatus.ACCEPTED);
	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ResponseEntity.class) })
	@ApiOperation(value = "Health Check.", produces = "application/json", notes = "This functionality is used for check health of application ")
	@GetMapping()
	public String[] ping() {
		return environment.getActiveProfiles();

	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ResponseEntity.class) })
	@ApiOperation(value = "cacheFlush", produces = "application/json", notes = "This functionality is used for cache clean up of application ")
	@GetMapping(value = "cacheFlush")
	public boolean cacheFlush() {
		boolean status = false;
		try {
			status = siteCoreService.sitecoreApiLayoutRenderCacheEvict();
		} catch (Exception e) {
			logger.error("Exception is thrown while evicting cache");
		}
		return status;
	}

}
