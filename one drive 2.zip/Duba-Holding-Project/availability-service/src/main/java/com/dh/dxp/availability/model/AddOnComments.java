package com.dh.dxp.availability.model;

public class AddOnComments {
	private String text;
	private String image;
	private String name;
	private String serviceInventoryCode;
	private String servicePricingType;
	private String ratePlanCode;
	private DateRange dateRangeAddOn;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getServiceInventoryCode() {
		return serviceInventoryCode;
	}

	public void setServiceInventoryCode(String serviceInventoryCode) {
		this.serviceInventoryCode = serviceInventoryCode;
	}

	public String getServicePricingType() {
		return servicePricingType;
	}

	public void setServicePricingType(String servicePricingType) {
		this.servicePricingType = servicePricingType;
	}

	public String getRatePlanCode() {
		return ratePlanCode;
	}

	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	public DateRange getDateRangeAddOn() {
		return dateRangeAddOn;
	}

	public void setDateRangeAddOn(DateRange dateRangeAddOn) {
		this.dateRangeAddOn = dateRangeAddOn;
	}

}
