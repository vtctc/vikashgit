package com.dh.dxp.availability.model;

import java.util.List;

public class DateRange {
	private String amountTaxBefore;
	private String amountTaxAfter;
	private String currencyCode;
	private String date;
	private List<TimeSpan> addOnTimeSpan;

	public String getAmountBeforeTax() {
		return amountTaxBefore;
	}

	public void setAmountBeforeTax(String amountBeforeTax) {
		this.amountTaxBefore = amountBeforeTax;
	}

	public String getAmountAfterTax() {
		return amountTaxAfter;
	}

	public void setAmountAfterTax(String amountAfterTax) {
		this.amountTaxAfter = amountAfterTax;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<TimeSpan> getAddOnTimeSpan() {
		return addOnTimeSpan;
	}

	public void setAddOnTimeSpan(List<TimeSpan> addOnTimeSpan) {
		this.addOnTimeSpan = addOnTimeSpan;
	}

}
