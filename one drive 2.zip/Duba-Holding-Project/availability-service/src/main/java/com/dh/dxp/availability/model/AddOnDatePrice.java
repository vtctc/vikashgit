package com.dh.dxp.availability.model;

import java.util.List;

public class AddOnDatePrice {
	private String amountTaxBefore;
	private String amountTaxAfter;
	private String dateRange;
	private List<TimeSpan> timeSpan;

	public String getAmountTaxBefore() {
		return amountTaxBefore;
	}

	public void setAmountTaxBefore(String amountTaxBefore) {
		this.amountTaxBefore = amountTaxBefore;
	}

	public String getAmountTaxAfter() {
		return amountTaxAfter;
	}

	public void setAmountTaxAfter(String amountTaxAfter) {
		this.amountTaxAfter = amountTaxAfter;
	}

	public String getDateRange() {
		return dateRange;
	}

	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}

	public List<TimeSpan> getTimeSpan() {
		return timeSpan;
	}

	public void setTimeSpan(List<TimeSpan> timeSpan) {
		this.timeSpan = timeSpan;
	}

}
