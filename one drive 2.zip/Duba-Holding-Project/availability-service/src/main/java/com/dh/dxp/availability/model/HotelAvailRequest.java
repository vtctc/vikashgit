package com.dh.dxp.availability.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.dh.dxp.schemas.Position;
import com.dh.dxp.schemas.Radius;
import com.dh.dxp.schemas.StayDateRangeType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Component
@ApiModel(description = "Request for Calender Pricing")
public class HotelAvailRequest {

	@ApiModelProperty(hidden = true)
	private String chainCode;

	@ApiModelProperty(hidden = true)
	private String areaId;

	private String quantity;

	@ApiModelProperty(hidden = true)
	private boolean isCalenderPricing;

	@ApiModelProperty(hidden = true)
	private String pricingMethod;

	private String primaryLangID;

	@ApiModelProperty(hidden = true)
	private String echoToken;

	@ApiModelProperty(hidden = true)
	private boolean hotelStayOnly;

	@ApiModelProperty(hidden = true)
	private boolean summaryOnly;

	@ApiModelProperty(hidden = true)
	private boolean bestOnly;

	@ApiModelProperty(hidden = true)
	private boolean exactMatchOnly;

	@ApiModelProperty(hidden = true)
	private String requestedCurrency;

	@ApiModelProperty(hidden = true)
	private int maxResponses;

	@ApiModelProperty(hidden = true)
	private String promotionCode;

	private List<String> hotelCode;

	@ApiModelProperty(hidden = true)
	private PosChanelInfo posRequest;

	private StayDateRangeType stayDateRangeType;

	@ApiModelProperty(hidden = true)
	private Position position;

	@ApiModelProperty(hidden = true)
	private Radius radius;

	@ApiModelProperty(hidden = true)
	private boolean nonRoom;
	private List<RoomCountDetails> roomCountDetails;
	@ApiModelProperty(required = false)
	private String cmsId;

	public String getCmsId() {
		return cmsId;
	}

	public void setCmsId(String cmsId) {
		this.cmsId = cmsId;
	}

	public String getChainCode() {
		return chainCode;
	}

	public void setChainCode(String chainCode) {
		this.chainCode = chainCode;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public boolean isCalenderPricing() {
		return isCalenderPricing;
	}

	public void setCalenderPricing(boolean isCalenderPricing) {
		this.isCalenderPricing = isCalenderPricing;
	}

	public String getPricingMethod() {
		return pricingMethod;
	}

	public void setPricingMethod(String pricingMethod) {
		this.pricingMethod = pricingMethod;
	}

	public String getPrimaryLangID() {
		return primaryLangID;
	}

	public void setPrimaryLangID(String primaryLangID) {
		this.primaryLangID = primaryLangID;
	}

	public String getEchoToken() {
		return echoToken;
	}

	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

	public boolean isHotelStayOnly() {
		return hotelStayOnly;
	}

	public void setHotelStayOnly(boolean hotelStayOnly) {
		this.hotelStayOnly = hotelStayOnly;
	}

	public boolean isSummaryOnly() {
		return summaryOnly;
	}

	public void setSummaryOnly(boolean summaryOnly) {
		this.summaryOnly = summaryOnly;
	}

	public boolean isBestOnly() {
		return bestOnly;
	}

	public void setBestOnly(boolean bestOnly) {
		this.bestOnly = bestOnly;
	}

	public boolean isExactMatchOnly() {
		return exactMatchOnly;
	}

	public void setExactMatchOnly(boolean exactMatchOnly) {
		this.exactMatchOnly = exactMatchOnly;
	}

	public String getRequestedCurrency() {
		return requestedCurrency;
	}

	public void setRequestedCurrency(String requestedCurrency) {
		this.requestedCurrency = requestedCurrency;
	}

	public int getMaxResponses() {
		return maxResponses;
	}

	public void setMaxResponses(int maxResponses) {
		this.maxResponses = maxResponses;
	}

	public String getPromotionCode() {
		return promotionCode;
	}

	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}

	public List<String> getHotelCode() {
		return hotelCode;
	}

	public void setHotelCode(List<String> hotelCode) {
		this.hotelCode = hotelCode;
	}

	public PosChanelInfo getPosRequest() {
		return posRequest;
	}

	public void setPosRequest(PosChanelInfo posRequest) {
		this.posRequest = posRequest;
	}

	public StayDateRangeType getStayDateRangeType() {
		return stayDateRangeType;
	}

	public void setStayDateRangeType(StayDateRangeType stayDateRangeType) {
		this.stayDateRangeType = stayDateRangeType;
	}

	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public Radius getRadius() {
		return radius;
	}

	public void setRadius(Radius radius) {
		this.radius = radius;
	}

	public boolean isNonRoom() {
		return nonRoom;
	}

	public void setNonRoom(boolean nonRoom) {
		this.nonRoom = nonRoom;
	}

	public List<RoomCountDetails> getRoomCountDetails() {
		return roomCountDetails;
	}

	public void setRoomCountDetails(List<RoomCountDetails> roomCountDetails) {
		this.roomCountDetails = roomCountDetails;
	}

}
