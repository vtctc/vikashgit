package com.dh.dxp.availability.model;

import java.io.Serializable;

public class TaxDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8941296313220745850L;
	private String taxCode;
	private String taxName;
	private String taxDescription;
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getTaxName() {
		return taxName;
	}
	public void setTaxName(String taxName) {
		this.taxName = taxName;
	}
	public String getTaxDescription() {
		return taxDescription;
	}
	public void setTaxDescription(String taxDescription) {
		this.taxDescription = taxDescription;
	}
	
	
}
