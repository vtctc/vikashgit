package com.dh.dxp.availability.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.AvailableStatusDetail;
import com.dh.dxp.availability.model.CalenderRateResponse;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.utils.DHDataResource;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.exceptions.OTAWarningDetail;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CalendarPricingService extends DHSoapAdapterService {
	@Autowired
	private HotelRestaurantMappingServiceImpl hotelRestaurantMappingServiceImpl;
	@Autowired
	DHDataResource siteCoreWrapper;

	private static final Logger logger = LogManager.getLogger(CalendarPricingService.class);

	public CalenderRateResponse getRateDetails(HotelAvailRequest hotelAvailRequest)
			throws DHGlobalException, IOException {
		String jsonStr = processJAXB(hotelAvailRequest);
		return processJsonResponse(jsonStr);

	}

	/**
	 * @param jsonObjectMapper
	 * @param jsonStr
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected CalenderRateResponse processJsonResponse(String jsonStr) throws DHGlobalException, IOException {
		ObjectMapper jsonObjectMapper = new ObjectMapper();
		JsonNode otaNode = jsonObjectMapper.readTree(jsonStr);
		JsonNode hotelStaysNode = otaNode.path("hotelStays");
			CalenderRateResponse response = new CalenderRateResponse();

			// Fix Bug for hotel availability for past calendar date
			JsonNode otaWarningNode = otaNode.findValue("value");
			if (otaWarningNode != null) {
				OTAWarningDetail oTAWarningDetail = new OTAWarningDetail();
				oTAWarningDetail.setWarningDescription(otaWarningNode.asText());
				response.setoTAWarningDetail(oTAWarningDetail);
			}
			List<AvailableStatusDetail> availableDetailsList = new ArrayList<>();
			for (JsonNode hotelStayNode : hotelStaysNode.path("hotelStay")) {

				response.setHotelCode(hotelStayNode.path("basicPropertyInfo").path("hotelCode").asText());
				response.setHotelName(hotelStayNode.path("basicPropertyInfo").path("hotelName").asText());
				String availStatusNode = hotelStayNode.path(DHConstantUtils.ECO_TOKEN).path("status").asText();

				if (availStatusNode.equalsIgnoreCase("open")) {
					for (JsonNode priceNode : hotelStayNode.path("price")) {
						AvailableStatusDetail availableDetails = new AvailableStatusDetail();
						String startDateNode = nodeDateFormat(priceNode.path(DHConstantUtils.START).asText());
						String endDateNode = nodeDateFormat(priceNode.path(DHConstantUtils.END).asText());
						LocalDate localDate = nodeDateFormatLocalDate(startDateNode);
						LocalDate localDate2 = nodeDateFormatLocalDate(endDateNode);
						if (localDate.isBefore(LocalDate.now()) && localDate2.isBefore(LocalDate.now())) {
							String startDate = nodeDateFormat(priceNode.path(DHConstantUtils.START).asText());
							String endDate = nodeDateFormat(priceNode.path(DHConstantUtils.END).asText());

							availableDetails.setStartDate(startDate);
							availableDetails.setEndDate(endDate);
							availableDetails.setPrice(priceNode.path("amountBeforeTax").asText());
							availableDetails.setCurrencyCode(priceNode.path("currencyCode").asText());
							availableDetails.setAvailabalityStatus("close");
							availableDetailsList.add(availableDetails);
						} else {
							String startDate = nodeDateFormat(priceNode.path(DHConstantUtils.START).asText());
							String endDate = nodeDateFormat(priceNode.path(DHConstantUtils.END).asText());

							availableDetails.setStartDate(startDate);
							availableDetails.setEndDate(endDate);
							availableDetails.setPrice(priceNode.path("amountBeforeTax").asText());
							availableDetails.setCurrencyCode(priceNode.path("currencyCode").asText());
							availableDetails.setAvailabalityStatus(hotelStayNode.path(DHConstantUtils.ECO_TOKEN)
									.path(DHConstantUtils.STATUS).asText());

							availableDetailsList.add(availableDetails);
						}

					}

				} else if (availStatusNode.equalsIgnoreCase("close")) {
					AvailableStatusDetail availableDetails = new AvailableStatusDetail();

					String startDate = nodeDateFormat(
							hotelStayNode.path(DHConstantUtils.ECO_TOKEN).path(DHConstantUtils.START).asText());
					String endDate = nodeDateFormat(
							hotelStayNode.path(DHConstantUtils.ECO_TOKEN).path(DHConstantUtils.END).asText());

					availableDetails.setStartDate(startDate);
					availableDetails.setEndDate(endDate);
					availableDetails.setAvailabalityStatus(
							hotelStayNode.path(DHConstantUtils.ECO_TOKEN).path(DHConstantUtils.STATUS).asText());
					availableDetailsList.add(availableDetails);
				}

				response.setAvailableDetails(availableDetailsList);

			}

			return response;
		
	}

	// Dummy method for getting entire hotel avail response.
	public String getHotelAvailabilityInfo(HotelAvailRequest hotelAvailRequest) throws DHGlobalException, IOException {

		ObjectMapper jsonObjectMapper = new ObjectMapper();

		List<String> hotelCodes = hotelAvailRequest.getHotelCode();
		List<String> hotelCodeList = new ArrayList<>();
		for (String hotelCode : hotelCodes) {
			hotelCodeList.add(hotelRestaurantMappingServiceImpl.findBookingSystemId(hotelCode));
		}
		hotelAvailRequest.setHotelCode(hotelCodeList);

		String jsonStr = processJAXB(hotelAvailRequest);
		Object json = jsonObjectMapper.readValue(jsonStr, Object.class);
		String indented = jsonObjectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
		logger.info("JSON Response{}", indented);

		return jsonStr;

	}

	public static String nodeDateFormat(String synxisDate) {

		return synxisDate.replaceAll("/", "-");
	}

	public static LocalDate nodeDateFormatLocalDate(String synxisDate) {

		String[] responseDate = synxisDate.split("-");
		int year = Integer.parseInt(responseDate[2]);
		int month = Integer.parseInt(responseDate[0]);
		int day = Integer.parseInt(responseDate[1]);

		return LocalDate.of(year, month, day);

	}

	@Override
	protected <T> T processJsonAddOnResponse(String jsonStr, String hotelCode) throws DHGlobalException {

		return null;
	}

}
