package com.dh.dxp.availability.model;

import java.io.Serializable;
import java.util.List;

public class RoomRateDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String amountBeforeTax;
	private String amountAfterTax;
	private String currencyCode;
	private String ratePlanCode;
	private String roomTypeCode;
	private String ratePlanName;
	private String ratePlanDescription;
	private List<RateFeatures> rateFeatures;
	private List<TaxDetails> taxDetails;
	private List<CancellationPolicy> cancellationPolicies;

	public List<CancellationPolicy> getCancellationPolicies() {
		return cancellationPolicies;
	}

	public void setCancellationPolicies(List<CancellationPolicy> cancellationPolicies) {
		this.cancellationPolicies = cancellationPolicies;
	}

	public String getRatePlanName() {
		return ratePlanName;
	}

	public List<TaxDetails> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<TaxDetails> taxDetails) {
		this.taxDetails = taxDetails;
	}

	public void setRatePlanName(String ratePlanName) {
		this.ratePlanName = ratePlanName;
	}

	public String getAmountBeforeTax() {
		return amountBeforeTax;
	}

	public void setAmountBeforeTax(String amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}

	public String getAmountAfterTax() {
		return amountAfterTax;
	}

	public void setAmountAfterTax(String amountAfterTax) {
		this.amountAfterTax = amountAfterTax;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getRatePlanCode() {
		return ratePlanCode;
	}

	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	public String getRatePlanDescription() {
		return ratePlanDescription;
	}

	public void setRatePlanDescription(String ratePlanDescription) {
		this.ratePlanDescription = ratePlanDescription;
	}

	public List<RateFeatures> getRateFeatures() {
		return rateFeatures;
	}

	public void setRateFeatures(List<RateFeatures> rateFeatures) {
		this.rateFeatures = rateFeatures;
	}

}
