package com.dh.dxp.availability.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.AreaDescriptionDTO;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class RoomMeasurementsService {

	private RestTemplate restTemplate = new RestTemplate();

	@Value("#{'${sitecore.domain}'}")
	private String siteCoreURL;

	private static final String SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS = "/sitecore/api/layout/render/jss?item=%7b{0}%7d&sc_apikey=%7b{1}%7d&sc_lang={2}";

	private static final String SITECORE_API_LAYOUT_RENDER_APIKEY = "F6C5544B-E2B3-47E4-B8C0-354B492A47C8";

	private static final Logger LOGGER = LogManager.getLogger(RoomMeasurementsService.class);

	private static final long SITECORE_API_LAYOUT_RENDER_TTL = (long) 4 * 60 * 60 * 1000;

	private static final String SITECORE_API_LAYOUT_RENDER_NAME_ROOM_MEASURMENT = "sitecore_api_layout_render_room_measurment";

	@Autowired
	HotelRestaurantMappingServiceImpl mappingService;

	/**
	 * @param hotelCode
	 * 
	 * @return
	 * @throws URISyntaxException
	 */
	@Cacheable(value = SITECORE_API_LAYOUT_RENDER_NAME_ROOM_MEASURMENT, key = "#hotelCode+':'+#language")
	public Map<String, AreaDescriptionDTO> getRoomAreaFromSiteCore(final String hotelCode, final String lang)
			throws DHGlobalException {
		LOGGER.info("Calling getRoomDetailsFromSiteCore");
		JsonNode roomAreaNode = getHotelDataFromSitecore(hotelCode, lang);

		JsonNode jssMainNodes = roomAreaNode.findPath("jss-main");
		Map<String, AreaDescriptionDTO> roomAmenityMap = new HashMap<>();
		for (JsonNode jssMainNode : jssMainNodes) {
			JsonNode jsonNodeComponent = jssMainNode.findPath("componentName");
			if (jsonNodeComponent.asText().equalsIgnoreCase("ContentCarousel2")) {
				JsonNode jsonHotelRooms = jssMainNode.findPath("Hotel Rooms");

				for (JsonNode jsonHotelRoom : jsonHotelRooms) {
					AreaDescriptionDTO areaDescription = new AreaDescriptionDTO();
					JsonNode hotelRoomFields = jsonHotelRoom.path(DHConstantUtils.FIELDS);
					JsonNode roomTypeCode = hotelRoomFields.path("Room Code");
					String icon = hotelRoomFields.path("Room size icon").path(DHConstantUtils.VALUE).path("src")
							.asText();
					String roomCode = roomTypeCode.path(DHConstantUtils.VALUE).asText();
					JsonNode squareFeetNod = hotelRoomFields.findPath("Square Feet").path(DHConstantUtils.VALUE);
					JsonNode squareMeterNod = hotelRoomFields.findPath("Square Meter").path(DHConstantUtils.VALUE);

					areaDescription.setSquareFeet(squareFeetNod.asText());
					areaDescription.setSquareMeter(squareMeterNod.asText());
					areaDescription.setIcon(icon);
					roomAmenityMap.put(roomCode, areaDescription);

				}

			}
		}
		return roomAmenityMap;

	}

	/**
	 * This method hits
	 * /sitecore/api/layout/render/jss?item=%{0}%7d&sc_apikey=%{1}%7d and returns
	 * same response.
	 * 
	 * @param hotelCode
	 * @return
	 * @throws URISyntaxException
	 */
	public JsonNode getHotelDataFromSitecore(final String hotelCode, final String lang) throws DHGlobalException {
		URI uri;
		try {
			uri = new URI(new StringBuilder(siteCoreURL).append(SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS)
					.toString().replace("{0}", hotelCode).replace("{1}", SITECORE_API_LAYOUT_RENDER_APIKEY)
					.replace("{2}", lang));
		} catch (URISyntaxException e) {
			throw new DHGlobalException("URISyntaxException"+e.getMessage());
		}
		return getDataFromSiteCore(uri);
	}

	/**
	 * This method hits sitecore and response backs the data
	 * 
	 * @param uri
	 * @return
	 */
	private JsonNode getDataFromSiteCore(final URI uri) {
		LOGGER.info("site core end point:-{}", uri.toString());
		return restTemplate.getForObject(uri, JsonNode.class);
	}

	/**
	 * This method runs periodically and flushes cache name
	 * "sitecore_api_layout_render"
	 */
	@CacheEvict(allEntries = true, cacheNames = { SITECORE_API_LAYOUT_RENDER_NAME_ROOM_MEASURMENT })
	@Scheduled(fixedDelay = SITECORE_API_LAYOUT_RENDER_TTL)
	public boolean sitecoreApiLayoutRenderCacheEvict() {
		LOGGER.debug("Cache is getting flushed-------");
		return true;
	}

}
