package com.dh.dxp.availability.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.GuestDetails;
import com.dh.dxp.availability.model.HotelAvailRequest;
import com.dh.dxp.availability.model.RoomCountDetails;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.schemas.ArrayOfAvailRequestSegment;
import com.dh.dxp.schemas.ArrayOfGuestCount;
import com.dh.dxp.schemas.ArrayOfHotelSearchCriterion;
import com.dh.dxp.schemas.ArrayOfRatePlanCandidate;
import com.dh.dxp.schemas.ArrayOfRoomStayCandidate;
import com.dh.dxp.schemas.AvailRequestSegment;
import com.dh.dxp.schemas.CompanyName;
import com.dh.dxp.schemas.GuestCount;
import com.dh.dxp.schemas.HotelReferenceGroup;
import com.dh.dxp.schemas.HotelSearchCriterion;
import com.dh.dxp.schemas.OTAHotelAvailRQ;
import com.dh.dxp.schemas.ObjectFactory;
import com.dh.dxp.schemas.POS;
import com.dh.dxp.schemas.RatePlanCandidate;
import com.dh.dxp.schemas.RequestorID;
import com.dh.dxp.schemas.RoomStayCandidate;
import com.dh.dxp.schemas.Source;
import com.dh.dxp.schemas.StayDateRangeType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Service
public class OtaMessageUtil {

	private static final Logger logger = LogManager.getLogger(OtaMessageUtil.class);

	@Value("#{'${serivce.namespaceuri}'}")
	private String nameSpaceUri;
	
	@Autowired
	DHDataResource siteCoreWrapper;

	public JAXBElement<OTAHotelAvailRQ> getAvailableOtaRequestMessage(HotelAvailRequest hotelAvailRequestObj)
			throws DHGlobalException {

		String chainCode;
		int maxResponses;
		POS pos;

		ArrayOfRatePlanCandidate arrayOfRatePlanCandidate;
		StayDateRangeType stayDateRange;
		ArrayOfHotelSearchCriterion arrayOfHotelSearchCriterion;
		ObjectMapper jsonObjectMapper;
		HotelSearchCriterion criterionByLatLong;
		AvailRequestSegment availRequestSegments;
		ArrayOfAvailRequestSegment arrayOfAvailRequestSegment;

		ArrayOfRoomStayCandidate arrayOfRoomStayCandidate;

		List<String> hotelCode = null;

		List<AvailRequestSegment> listAvailRequestSegment;
		final ObjectFactory objectFactory;
		final OTAHotelAvailRQ hotelAvailRQ;

		// Conditional fields
		boolean summaryOnly;
		boolean hotelStayOnly;
		boolean bestOnly;
		boolean exactMatchOnly;
		String pricingMethod;

		// Set Default for Calendar based pricing is enabled , use existing
		// values if
		// disabled.

		if (hotelAvailRequestObj.isCalenderPricing()) {
			summaryOnly = false;
			hotelStayOnly = true;
			bestOnly = false;
			exactMatchOnly = false;
			pricingMethod = "Average";

		} else {
			summaryOnly = hotelAvailRequestObj.isSummaryOnly();
			hotelStayOnly = hotelAvailRequestObj.isHotelStayOnly();
			bestOnly = hotelAvailRequestObj.isBestOnly();
			exactMatchOnly = hotelAvailRequestObj.isExactMatchOnly();
			pricingMethod = hotelAvailRequestObj.getPricingMethod();

		}

		maxResponses = hotelAvailRequestObj.getMaxResponses();

		jsonObjectMapper = new ObjectMapper();
		jsonObjectMapper.enable(SerializationFeature.INDENT_OUTPUT);

		objectFactory = new ObjectFactory();
		hotelAvailRQ = objectFactory.createOTAHotelAvailRQ();

		hotelAvailRQ.setPrimaryLangID(hotelAvailRequestObj.getPrimaryLangID());
		hotelAvailRQ.setEchoToken(DHConstantUtils.ECO_TOKEN); // Constant

		hotelAvailRQ.setSummaryOnly(summaryOnly); // Check Availability Summary
		hotelAvailRQ.setHotelStayOnly(hotelStayOnly); // Check Daily Hotel
														// Availability Status
														// Over Date Range
		hotelAvailRQ.setBestOnly(bestOnly);
		hotelAvailRQ.setPricingMethod(pricingMethod); // Check Daily Hotel
														// Availability Status
														// with Calendar Pricing
		hotelAvailRQ.setExactMatchOnly(exactMatchOnly);
		hotelAvailRQ.setRequestedCurrency(hotelAvailRequestObj.getRequestedCurrency());
		hotelAvailRQ.setMaxResponses(maxResponses);

		// Hotel Code and Multiple Properties Search
		hotelCode = hotelAvailRequestObj.getHotelCode();
		arrayOfRoomStayCandidate = evaluateRoomstayCandidates(hotelAvailRequestObj);
		// Preview request Object Mapper
		consoleFormate(hotelAvailRequestObj, jsonObjectMapper);

		// Pos Channel Info
		pos = getHotelPosInfo();

		// Specific Rate Availability Check
		arrayOfRatePlanCandidate = evaluateRatePlanCandidate(hotelAvailRequestObj);

		// Date range
		stayDateRange = evaluateStayDates(hotelAvailRequestObj);
		arrayOfHotelSearchCriterion = new ArrayOfHotelSearchCriterion();
		chainCode = hotelAvailRequestObj.getChainCode();

		criterionByLatLong = new HotelSearchCriterion();

		arrayOfHotelSearchCriterion.getCriterion().add(criterionByLatLong);
		availRequestSegments = new AvailRequestSegment();
		availRequestSegments.setStayDateRange(stayDateRange);
		availRequestSegments.setRatePlanCandidates(arrayOfRatePlanCandidate);

		// Room Stay Candiate goes here
		availRequestSegments.setRoomStayCandidates(arrayOfRoomStayCandidate);

		availRequestSegments.setHotelSearchCriteria(arrayOfHotelSearchCriterion);
		if (hotelAvailRequestObj.isNonRoom()) {

			availRequestSegments.setAvailReqType("NonRoom");
		}

		listAvailRequestSegment = new ArrayList<>();
		listAvailRequestSegment.add(availRequestSegments);

		arrayOfAvailRequestSegment = new ArrayOfAvailRequestSegment();
		arrayOfAvailRequestSegment.getAvailRequestSegment().add(availRequestSegments);

		hotelAvailRQ.setPOS(pos);
		hotelAvailRQ.setAvailRequestSegments(arrayOfAvailRequestSegment);

		if (hotelCode != null && !hotelCode.isEmpty()) {

			for (String hotelCodeList : hotelCode) {
				
				HotelSearchCriterion hotelSearchCriterion = new HotelSearchCriterion();
				HotelReferenceGroup hotelReferenceGroup = new HotelReferenceGroup();
				hotelReferenceGroup.setChainCode(chainCode);
				hotelReferenceGroup.setHotelCode(siteCoreWrapper.getSynxisID(hotelCodeList));// Get and Set Synxis ID for HotelCode Ex.AQL-
				hotelSearchCriterion.setHotelRef(hotelReferenceGroup);
				arrayOfHotelSearchCriterion.getCriterion().add(hotelSearchCriterion);
			}

		} else {
			throw new DHGlobalException("Hotel Code can not be empty or null");
		}

		return new JAXBElement<>(new QName(nameSpaceUri, "OTA_HotelAvailRQ"), OTAHotelAvailRQ.class, hotelAvailRQ);
	}

	private StayDateRangeType evaluateStayDates(HotelAvailRequest hotelAvailRequestObj) {
		StayDateRangeType stayDateRange = new StayDateRangeType();
		stayDateRange.setEnd(hotelAvailRequestObj.getStayDateRangeType().getEnd());
		stayDateRange.setStart(hotelAvailRequestObj.getStayDateRangeType().getStart());
		return stayDateRange;
	}

	private void consoleFormate(HotelAvailRequest hotelAvailRequestObj, ObjectMapper jsonObjectMapper) {
		String inputJsonRequest;
		try {
			inputJsonRequest = jsonObjectMapper.writeValueAsString(hotelAvailRequestObj);

			Object inputJson = jsonObjectMapper.readValue(inputJsonRequest, Object.class);
			String formatedRequest = jsonObjectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(inputJson);

			logger.debug("expected Formate:{}", formatedRequest);

		} catch (IOException e) {
			logger.error("Error Occured At :: Formate:{} " + e.getLocalizedMessage());
		}
	}

	private ArrayOfRatePlanCandidate evaluateRatePlanCandidate(HotelAvailRequest hotelAvailRequestObj) {
		RatePlanCandidate ratePlanCandidates = new RatePlanCandidate();
		ratePlanCandidates.setPromotionCode(hotelAvailRequestObj.getPromotionCode()); // testing value DPKGTEST

		List<RatePlanCandidate> listRatePlanCandidate = new ArrayList<>();
		listRatePlanCandidate.add(ratePlanCandidates);

		ArrayOfRatePlanCandidate arrayOfRatePlanCandidate = new ArrayOfRatePlanCandidate();
		arrayOfRatePlanCandidate.getRatePlanCandidate().add(ratePlanCandidates);
		return arrayOfRatePlanCandidate;
	}

	private ArrayOfRoomStayCandidate evaluateRoomstayCandidates(HotelAvailRequest hotelAvailRequestObj)
			throws DHGlobalException {
		boolean adultStatus = false;
		RoomStayCandidate roomStayCandidatee = new RoomStayCandidate();
		ArrayOfRoomStayCandidate roomStayCandidates = new ArrayOfRoomStayCandidate();
		ArrayOfGuestCount arrayOfGuestCount = new ArrayOfGuestCount();
		List<RoomCountDetails> list = hotelAvailRequestObj.getRoomCountDetails();
		if (list != null && !list.isEmpty()) {
			for (RoomCountDetails listGuestDetails : list) {

				roomStayCandidatee.setQuantity(DHConstantUtils.DEFAULT_ROOM_QUATIY);
				for (GuestDetails guestDetails : listGuestDetails.getGuestDetails()) {
					GuestCount guestCount = new GuestCount();
					String ageCode = guestDetails.getAgeQualifyingCode();
					if (ageCode.equalsIgnoreCase("10")) {
						adultStatus = true;
					}
					String count = guestDetails.getGuestCount();
					guestCount.setAgeQualifyingCode(ageCode);
					guestCount.setCount(count);

					arrayOfGuestCount.getGuestCount().add(guestCount);
				}
				roomStayCandidatee.setGuestCounts(arrayOfGuestCount);
				roomStayCandidates.getRoomStayCandidate().add(roomStayCandidatee);

			}

		} else {
			throw new DHGlobalException("Please select atleast one Guest");

		}

		if (!adultStatus) {
			throw new DHGlobalException("Please Select atleast one Adult");
		}

		return roomStayCandidates;

	}

	public POS getHotelPosInfo() {
		/******* Pos Channel Info Setting ******/
		CompanyName companyName = new CompanyName();
		companyName.setValue(DHConstantUtils.COMPANY_CODE);

		RequestorID requestorId = new RequestorID();
		requestorId.setCompanyName(companyName);

		requestorId.setID(DHConstantUtils.REQUESTOR_ID);

		requestorId.setIDContext(DHConstantUtils.ID_CONTEXT);

		Source source = new Source();
		source.setRequestorId(requestorId);

		POS pos = new POS();
		pos.setSource(source);
		return pos;
	}
}
