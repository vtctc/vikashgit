package com.dh.dxp.availability.service;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.RoomDetails;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class SiteCoreAmenitiesService {

	private static final Logger LOGGER = LogManager.getLogger(SiteCoreAmenitiesService.class);

	// Added for today-Begin

	private static final String VALUE = "value";
	private static final String SHORT_DESCRIPTION = "Short Description";
	private static final String ROOM_TITLE = "Room Title";
	private static final String IMAGES = "Images";
	private static final String SRC = "src";
	// Added for today-End

	/**
	 * @param hotelCode
	 * 
	 * @return
	 * @throws URISyntaxException
	 */

	public RoomDetails getRoomtDescriptions(JsonNode siteCoreRoomDetail) {
		LOGGER.info("calling getRoomtDescriptions");
		RoomDetails roomDetails = new RoomDetails();
		Map<String, String> shortDescription = new HashMap<>();
		Map<String, String> roomTitle = new HashMap<>();
		Map<String, List<String>> roomImages = new HashMap<>();

		JsonNode hotelRooms = getHotelRoomDetail(siteCoreRoomDetail);
		for (JsonNode hotelRoom : hotelRooms) {
			shortDescription.put(hotelRoom.findPath(DHConstantUtils.ROOM_CODE).findPath(VALUE).asText(),
					hotelRoom.findPath(SHORT_DESCRIPTION).findPath(VALUE).asText());
			roomTitle.put(hotelRoom.findPath(DHConstantUtils.ROOM_CODE).findPath(VALUE).asText(),
					hotelRoom.findPath(ROOM_TITLE).findPath(VALUE).asText());

			List<String> images = new ArrayList<>();
			for (JsonNode image : hotelRoom.findPath(IMAGES)) {
				images.add(image.findPath(SRC).asText());
			}
			roomImages.put(hotelRoom.findPath(DHConstantUtils.ROOM_CODE).findPath(VALUE).asText(), images);

		}
		roomDetails.setShortDescription(shortDescription);
		roomDetails.setRoomTitle(roomTitle);
		roomDetails.setRoomImage(roomImages);
		LOGGER.info("exit getRoomtDescriptions");
		return roomDetails;
	}

	private JsonNode getHotelRoomDetail(JsonNode siteCoreRoomDetail) {
		JsonNode jssMainNodes = siteCoreRoomDetail.findPath(DHConstantUtils.JSS_MAIN);
		JsonNode hotelRooms = new ObjectMapper().createObjectNode();
		for (JsonNode jssMainNode : jssMainNodes) {
			JsonNode jsonNodeComponent = jssMainNode.findPath(DHConstantUtils.COMPONENET_NAME);
			if (DHConstantUtils.CONTENT_CAROUSEL2.equalsIgnoreCase(jsonNodeComponent.asText())) {
				hotelRooms = jssMainNode.findPath(DHConstantUtils.HOTEL_ROOMS);
			}
		}
		return hotelRooms;
	}

}
