package com.dh.dxp.availability.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.netflix.hystrix.contrib.javanica.aop.aspectj.HystrixCommandAspect;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
@Configuration
public class HystrixConfig {

	@Bean
	public HystrixCommandAspect hystrixAspect() {
		return new HystrixCommandAspect();
	}

	@Bean
	public CustomHystrixConcurrencyStrategy customHystrixConcurrencyStrategy() {
		return new CustomHystrixConcurrencyStrategy();
	}

}
