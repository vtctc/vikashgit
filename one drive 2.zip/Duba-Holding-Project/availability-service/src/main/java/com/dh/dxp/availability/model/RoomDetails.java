package com.dh.dxp.availability.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author M1051767
 *
 */
public class RoomDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1786065201463552637L;
	private Map<String, String> bedPreferences;
	private Map<String, String> specialRequests;
	private Map<String, String> paymentPolicies;
	private Map<String, String> cancellationPolicies;
	private Map<String, String> taxCodes;
	private Map<String, String> roomLabels;

	private Map<String, String> shortDescription;
	private Map<String, String> roomTitle;
	private Map<String, List<String>> roomImage;

	public Map<String, String> getBedPreferences() {
		return bedPreferences;
	}

	public void setBedPreferences(Map<String, String> bedPreferences) {
		this.bedPreferences = bedPreferences;
	}

	public Map<String, String> getSpecialRequests() {
		return specialRequests;
	}

	public void setSpecialRequests(Map<String, String> specialRequests) {
		this.specialRequests = specialRequests;
	}

	public Map<String, String> getPaymentPolicies() {
		return paymentPolicies;
	}

	public void setPaymentPolicies(Map<String, String> paymentPolicies) {
		this.paymentPolicies = paymentPolicies;
	}

	public Map<String, String> getCancellationPolicies() {
		return cancellationPolicies;
	}

	public void setCancellationPolicies(Map<String, String> cancellationPolicies) {
		this.cancellationPolicies = cancellationPolicies;
	}

	public Map<String, String> getTaxCodes() {
		return taxCodes;
	}

	public void setTaxCodes(Map<String, String> taxCodes) {
		this.taxCodes = taxCodes;
	}

	public Map<String, String> getRoomLabels() {
		return roomLabels;
	}

	public void setRoomLabels(Map<String, String> roomLabels) {
		this.roomLabels = roomLabels;
	}

	public Map<String, String> getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(Map<String, String> shortDescription) {
		this.shortDescription = shortDescription;
	}

	public Map<String, String> getRoomTitle() {
		return roomTitle;
	}

	public void setRoomTitle(Map<String, String> roomTitle) {
		this.roomTitle = roomTitle;
	}

	public Map<String, List<String>> getRoomImage() {
		return roomImage;
	}

	public void setRoomImage(Map<String, List<String>> roomImage) {
		this.roomImage = roomImage;
	}

}
