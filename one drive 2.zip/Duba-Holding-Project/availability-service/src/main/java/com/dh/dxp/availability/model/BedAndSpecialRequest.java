package com.dh.dxp.availability.model;

import java.util.List;

public class BedAndSpecialRequest {

	private List<HotelDetailsDTO> hotelDetailesDTO;

	/**
	 * @return the hotelDetailesDTO
	 */
	public List<HotelDetailsDTO> getHotelDetailesDTO() {
		return hotelDetailesDTO;
	}

	/**
	 * @param hotelDetailesDTO the hotelDetailesDTO to set
	 */
	public void setHotelDetailesDTO(List<HotelDetailsDTO> hotelDetailesDTO) {
		this.hotelDetailesDTO = hotelDetailesDTO;
	}

}
