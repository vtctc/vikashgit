package com.dh.dxp.availability.service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.model.RateFeatures;
import com.dh.dxp.availability.model.RoomDetails;
import com.dh.dxp.availability.model.RoomRateDetails;
import com.dh.dxp.availability.utils.DHDataResource;
import com.dh.dxp.component.exceptions.DHGlobalException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class SiteCoreService {

	private RestTemplate restTemplate = new RestTemplate();

	@Autowired
	DHDataResource daoUtil;

	@Value("#{'${sitecore.domain}'}")
	private String siteCoreAPIURL;

	private static final String SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS = "/sitecore/api/layout/render/jss?item=%7b{0}%7d&sc_apikey=%7b{1}%7d&sc_lang={2}";

	private static final String SITECORE_API_LAYOUT_RENDER_APIKEY = "F6C5544B-E2B3-47E4-B8C0-354B492A47C8";

	private static final long SITECORE_API_LAYOUT_RENDER_TTL = (long) 4 * 60 * 60 * 1000;

	private static final String SITECORE_API_LAYOUT_RENDER_NAME = "sitecore_api_layout_render_master";

	private static final String SITECORE_API_LAYOUT_RENDER_MASTER_DATA = "sitecore_api_layout_render_masterData";

	private static final String SITECORE_API_LAYOUT_HOTEL_DETAIL_CACHE = "sitecore_api_layout_hotel_Details_Cache";

	private static final Logger logger = LogManager.getLogger(SiteCoreService.class);

	/**
	 * @param hotelCode
	 * 
	 * @return
	 * @throws DHGlobalException 
	 * @throws URISyntaxException
	 * @throws IOException 
	 */
	@Cacheable(value = SITECORE_API_LAYOUT_RENDER_NAME, key = "#hotelCode+':'+#lang")
	public RoomDetails getRoomDetailsFromSiteCore(final String hotelCode, final String lang) throws DHGlobalException {
		logger.info("Calling getRoomDetailsFromSiteCore");
		JsonNode hotelDetailSC = getHotelDataFromSitecore(hotelCode, lang);
		JsonNode placeholders = hotelDetailSC.path("sitecore").path("route").path("placeholders");
		RoomDetails rooDetails = new RoomDetails();

		rooDetails.setBedPreferences(getPlaceholderFields(placeholders, "BedPreference", DHConstantUtils.TITLE));
		rooDetails.setSpecialRequests(getPlaceholderFields(placeholders, "SpecialRequests", DHConstantUtils.TITLE));
		rooDetails.setCancellationPolicies(
				getPlaceholderFields(placeholders, "CancellationPolicy", DHConstantUtils.DESCRIPTION));
		rooDetails.setPaymentPolicies(getPlaceholderFields(placeholders, "PaymentPolicy", DHConstantUtils.DESCRIPTION));
		rooDetails.setTaxCodes(getPlaceholderFields(placeholders, "TaxCode", DHConstantUtils.DESCRIPTION));
		rooDetails.setRoomLabels(getPlaceholderLabels(placeholders));

		return rooDetails;

	}

	/**
	 * @param placeholders
	 * @param bedPreference
	 */
	private Map<String, String> getPlaceholderLabels(JsonNode placeholders) {
		Map<String, String> placeholderMap = new ConcurrentHashMap<>();
		for (JsonNode bedPrefJson : placeholders.path("Customize Stay")) {
			JsonNode bedPrefFieldsJson = bedPrefJson.path(DHConstantUtils.FIELDS);
			for (JsonNode bedPrefItemsJson : bedPrefFieldsJson.path(DHConstantUtils.ITEMS)) {
				JsonNode bedPrefFieldJson = bedPrefItemsJson.path(DHConstantUtils.FIELDS);
				String title = bedPrefFieldJson.path(DHConstantUtils.TITLE).path(DHConstantUtils.VALUE).textValue();
				String image = bedPrefFieldJson.path("Image").path(DHConstantUtils.VALUE).path("src").asText();
				placeholderMap.put(title, image);
			}
		}
		return placeholderMap;
	}

	/**
	 * @param placeholders
	 * @param bedPreference
	 */
	private Map<String, String> getPlaceholderFields(JsonNode placeholders, String placeHolderType, String label) {
		Map<String, String> placeholderMap = new HashMap<>();
		for (JsonNode bedPrefJson : placeholders.path(placeHolderType)) {
			JsonNode bedPrefFieldsJson = bedPrefJson.path(DHConstantUtils.FIELDS);
			for (JsonNode bedPrefItemsJson : bedPrefFieldsJson.path(DHConstantUtils.ITEMS)) {
				JsonNode bedPrefFieldJson = bedPrefItemsJson.path(DHConstantUtils.FIELDS);
				String bedPrefCode = bedPrefFieldJson.path(DHConstantUtils.CODE).path(DHConstantUtils.VALUE)
						.textValue();
				String bedPrefTitle = bedPrefFieldJson.path(label).path(DHConstantUtils.VALUE).textValue();
				placeholderMap.put(bedPrefCode, bedPrefTitle);
			}
		}
		return placeholderMap;
	}

	public ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> getCMSRateData(JsonNode rateResponseNode) {

		return processRoomTypeNode(rateResponseNode);

	}

	private ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> processRoomTypeNode(
			JsonNode rateResponseNode) {
		ConcurrentMap<String, ConcurrentMap<String, RoomRateDetails>> roomTypeMap = new ConcurrentHashMap<>();

		JsonNode hotelRoomsNode = rateResponseNode.path("sitecore").path("route").path("placeholders").path("jss-main")
				.findValue("Hotel Rooms");

		for (JsonNode hotelRoom : hotelRoomsNode) {
			ConcurrentHashMap<String, RoomRateDetails> rateTypeMap = new ConcurrentHashMap<>();
			String roomType = hotelRoom.path(DHConstantUtils.FIELDS).path("Room Code").path(DHConstantUtils.VALUE)
					.asText();

			for (JsonNode rateTypes : hotelRoom.path(DHConstantUtils.FIELDS).path("Rate Types")) {
				List<RateFeatures> rateFeaturesList = new ArrayList<>();
				RoomRateDetails rateDetails = new RoomRateDetails();

				JsonNode rateTypeFields = rateTypes.path(DHConstantUtils.FIELDS);
				rateDetails.setRatePlanName(rateTypeFields.path("Tagline").path(DHConstantUtils.VALUE).asText());
				rateDetails.setRatePlanDescription(
						rateTypes.path("fields").path("Title").path(DHConstantUtils.VALUE).asText());

				for (JsonNode amenitiesNode : rateTypes.path(DHConstantUtils.FIELDS).path("Amenities")) {
					RateFeatures rateFeature = new RateFeatures();
					JsonNode amenityFields = amenitiesNode.path(DHConstantUtils.FIELDS);
					rateFeature.setName(amenityFields.path("Title").path(DHConstantUtils.VALUE).asText());
					rateFeature.setCode(amenityFields.path("Code").path(DHConstantUtils.VALUE).asText());
					rateFeature.setIcon(amenityFields.path("Icon").path(DHConstantUtils.VALUE).path("src").asText());
					rateFeaturesList.add(rateFeature);
				}

				rateDetails.setRateFeatures(rateFeaturesList);
				rateTypeMap.put(rateTypeFields.path("Code").path(DHConstantUtils.VALUE).asText(), rateDetails);
			}
			roomTypeMap.put(roomType, rateTypeMap);
		}
		return roomTypeMap;
	}

	/**
	 * This method hits
	 * /sitecore/api/layout/render/jss?item=%{0}%7d&sc_apikey=%{1}%7d and returns
	 * same response.
	 * 
	 * @param hotelCode
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException 
	 */

	public JsonNode getHotelDataFromSitecore(final String hotelCode, final String lang) throws DHGlobalException {
		String siteCoreData=getDataFromSitecore(hotelCode, lang);
		ObjectMapper objectMapper=new ObjectMapper();
		try {
			return objectMapper.readTree(siteCoreData);
		} catch (IOException e) {
			 throw new DHGlobalException("IOException while reading from ObjectMapper :"+e.getMessage());
		}
	}
	
	@Cacheable(value = SITECORE_API_LAYOUT_HOTEL_DETAIL_CACHE, key = "#hotelCode+':'+#lang")
	public String getDataFromSitecore(String hotelCode,String lang) throws DHGlobalException { //URISyntaxException
		URI uri;
		try {
			uri = new URI(new StringBuilder(siteCoreAPIURL).append(SITECORE_API_LAYOUT_RENDER_HOTEL_DETAILS)
					.toString().replace("{0}", hotelCode).replace("{1}", SITECORE_API_LAYOUT_RENDER_APIKEY)
					.replace("{2}", lang));
		} catch (URISyntaxException e) {
           throw new DHGlobalException("URISyntaxException :"+e.getMessage());
		}
		return fethingFromSiteCore(uri);
	}

	/**
	 * This method hits sitecore and response backs the data
	 * 
	 * @param uri
	 * @return
	 */
	private String fethingFromSiteCore(final URI uri) {
		logger.info("site core end point:-{}", uri.toString());
		return restTemplate.getForObject(uri, String.class);
	}

	/**
	 * This method runs periodically and flushes cache name
	 * "sitecore_api_layout_render"
	 */
	@CacheEvict(allEntries = true, cacheNames = { SITECORE_API_LAYOUT_RENDER_NAME,
			SITECORE_API_LAYOUT_RENDER_MASTER_DATA, SITECORE_API_LAYOUT_HOTEL_DETAIL_CACHE })
	@Scheduled(fixedDelay = SITECORE_API_LAYOUT_RENDER_TTL)
	public boolean sitecoreApiLayoutRenderCacheEvict() {
		logger.info("Cache is getting flushed-------");
		return true;
	}

}
