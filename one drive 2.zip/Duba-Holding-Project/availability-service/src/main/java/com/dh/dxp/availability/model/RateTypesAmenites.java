package com.dh.dxp.availability.model;

import java.util.List;

public class RateTypesAmenites {
	private String rateTypeCode;
	private String rateTypeDescription;
	private String rateTypeTitle;
	private List<Amenities> ameneties;

	public String getRateTypeTitle() {
		return rateTypeTitle;
	}

	public void setRateTypeTitle(String rateTypeTitle) {
		this.rateTypeTitle = rateTypeTitle;
	}

	public String getRateTypeCode() {
		return rateTypeCode;
	}

	public void setRateTypeCode(String rateTypeCode) {
		this.rateTypeCode = rateTypeCode;
	}

	public String getRateTypeDescription() {
		return rateTypeDescription;
	}

	public void setRateTypeDescription(String rateTypeDescription) {
		this.rateTypeDescription = rateTypeDescription;
	}

	public List<Amenities> getAmeneties() {
		return ameneties;
	}

	public void setAmeneties(List<Amenities> ameneties) {
		this.ameneties = ameneties;
	}

}
