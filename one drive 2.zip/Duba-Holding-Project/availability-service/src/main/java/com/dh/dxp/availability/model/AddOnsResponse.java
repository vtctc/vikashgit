package com.dh.dxp.availability.model;

import java.util.List;

public class AddOnsResponse {
	private String title;
	private String image;
	private String description;
	private String serviceInventoryCode;
	private List<AddOnDatePrice> addOnDateRange;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServiceInventoryCode() {
		return serviceInventoryCode;
	}

	public void setServiceInventoryCode(String serviceInventoryCode) {
		this.serviceInventoryCode = serviceInventoryCode;
	}

	public List<AddOnDatePrice> getAddOnDateRange() {
		return addOnDateRange;
	}

	public void setAddOnDateRange(List<AddOnDatePrice> addOnDateRange) {
		this.addOnDateRange = addOnDateRange;
	}

}
