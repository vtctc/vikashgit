package com.dh.dxp.availability.model;

public class GuestDetails {

	private String ageQualifyingCode;
	private String guestCount;

	public String getAgeQualifyingCode() {
		return ageQualifyingCode;
	}

	public void setAgeQualifyingCode(String ageQualifyingCode) {
		this.ageQualifyingCode = ageQualifyingCode;
	}

	public String getGuestCount() {
		return guestCount;
	}

	public void setGuestCount(String guestCount) {
		this.guestCount = guestCount;
	}

	@Override
	public String toString() {
		return "GuestDetails [ageQualifyingCode=" + ageQualifyingCode + ", guestCount=" + guestCount + "]";
	}

	
}
