/*package com.dh.dxp.availability.service.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.dh.dxp.availability.model.CMSRoomDetails;
import com.dh.dxp.availability.service.SitecoreInteractor;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

*//**
 * @author M1039977
 * This class tests SitecoreInteractor class
 *
 *//*
@RunWith(SpringRunner.class)
@SpringBootTest
public class SitecoreInteractorTest {
	@Autowired
	private SitecoreInteractor sitecoreInteractor;
	
	
	*//**
	 * This test case tests sitecoreApiLayoutRenderCacheEvict method
	 * whether is it able to evict the cache or not
	 *//*
	@Test
	public void sitecoreApiLayoutRenderCacheEvictTest() {
		try {
			sitecoreInteractor.sitecoreApiLayoutRenderCacheEvict();
		}catch(Exception exc) {
			fail("Exception is thrown while evicting cache");
		}
	}
	
	*//**
	 * This test case tests getRoomDetailsFromSiteCore 
	 *//*
	@Test
	public void getRoomDetailsFromSiteCoreTest1() {
		try {
			sitecoreInteractor.getRoomDetailsFromSiteCore("EE23C456-990B-4F7B-B7DB-DE9ED2DD4D8A", "en");
		}catch(Exception exc) {
			fail("Exception is thrown while evicting cache");
		}
	}
	
	@Test
	public void getRoomDetailsFromSiteCoreTest2() {
		try {
			sitecoreInteractor.sitecoreApiLayoutRenderCacheEvict();
			File file = ResourceUtils.getFile("classpath:mockData/sitecore_api_layout_render.json");
			InputStream inputStream = new FileInputStream(file);
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode node = mapper.readTree(inputStream);
	        SitecoreInteractor mockedSitecoreInteractor = mock(SitecoreInteractor.class);
	        Mockito.when(mockedSitecoreInteractor.getHotelDataFromSitecore(Mockito.anyString(), Mockito.anyString())).thenReturn(node);
	        CMSRoomDetails sitecoreRoomDetails = mockedSitecoreInteractor.getRoomDetailsFromSiteCore("", "");
	        sitecoreRoomDetails.getRoomDetail().forEach(sitecoreRoomDetail ->{
	        	assertNotNull(sitecoreRoomDetail.getAreaSquareFeet());
	        	assertNotNull(sitecoreRoomDetail.getAreaSquareMeter());
	        	assertNotNull(sitecoreRoomDetail.getRoomAmenities());
	        });
		}catch(Exception exc) {
			exc.printStackTrace();
			fail("Exception is thrown while evicting cache");
		}
	}
	
	@Test
	public void getRoomDetailsFromSiteCoreTest3() {
		try {
			sitecoreInteractor.sitecoreApiLayoutRenderCacheEvict();
			File file = ResourceUtils.getFile("classpath:mockData/sitecore_api_layout_render1.json");
			InputStream inputStream = new FileInputStream(file);
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode node = mapper.readTree(inputStream);
	        SitecoreInteractor mockedSitecoreInteractor = mock(SitecoreInteractor.class);
	        Mockito.when(mockedSitecoreInteractor.getHotelDataFromSitecore(Mockito.anyString(), Mockito.anyString())).thenReturn(node);
	        CMSRoomDetails sitecoreRoomDetails = mockedSitecoreInteractor.getRoomDetailsFromSiteCore("", "");
	        assertNull(sitecoreRoomDetails);
		}catch(Exception exc) {
			exc.printStackTrace();
			fail("Exception is thrown while evicting cache");
		}
	}

}
*/