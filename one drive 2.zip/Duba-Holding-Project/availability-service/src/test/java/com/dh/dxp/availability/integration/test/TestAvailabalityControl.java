package com.dh.dxp.availability.integration.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.WebApplicationContext;

import com.dh.dxp.availability.config.DHConstantUtils;
import com.dh.dxp.availability.controller.AvailabilityController;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebMvcTest(AvailabilityController.class)
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAvailabalityControl {

	@Autowired
	private MockMvc mvc;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private WebApplicationContext wac;

	@Before
	public void setUp() throws Exception {
		// mockMvc = MockMvcBuilders.standaloneSetup(helloResource).build();
		this.mvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

	@Test
	public void testPing() throws Exception {
		mvc.perform(get("${synxis.base.path}").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void test_calendarPricing_success_response() throws Exception {
		File file = ResourceUtils.getFile("classpath:mockData/mock.json");
		InputStream inputStream = new FileInputStream(file);
		String inputJsonStr = readMockData(inputStream);
		mvc.perform(post("${synxis.base.path}" + "calendar-pricing").contentType(MediaType.APPLICATION_JSON)
				.content(inputJsonStr).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isAccepted())
				.andDo(print());

	}
	@Test
	public void test_calendarPricing_date_validation() throws Exception {
		File file = ResourceUtils.getFile("classpath:mockData/mock_v2.json");
		InputStream inputStream = new FileInputStream(file);
		String inputJsonStr = readMockData(inputStream);
		mvc.perform(post("${synxis.base.path}" + "calendar-pricing").contentType(MediaType.APPLICATION_JSON)
				.content(inputJsonStr).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andDo(print());

	}

	@Test
	public void test_roomdetail_success_response() throws Exception {
		File file = ResourceUtils.getFile("classpath:mockData/mock.json");
		InputStream inputStream = new FileInputStream(file);
		String inputJsonStr = readMockData(inputStream);
		mvc.perform(post("${synxis.base.path}" + "room-details").contentType(MediaType.APPLICATION_JSON)
				.content(inputJsonStr).accept(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted())
				.andDo(print());

	}

	@Test
	public void test_addOns_success_response() throws Exception {
		File file = ResourceUtils.getFile("classpath:mockData/mock.json");
		InputStream inputStream = new FileInputStream(file);
		String inputJsonStr = readMockData(inputStream);
		mvc.perform(post("${synxis.base.path}" + "addons").contentType(MediaType.APPLICATION_JSON)
				.content(inputJsonStr).accept(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted())
				.andDo(print());

	}

	public static String readMockData(InputStream input) throws IOException {
		try (BufferedReader buffer = new BufferedReader(new InputStreamReader(input))) {
			return buffer.lines().collect(Collectors.joining("\n"));
		}
	}
}
