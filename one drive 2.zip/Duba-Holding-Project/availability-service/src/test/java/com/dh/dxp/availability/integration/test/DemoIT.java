package com.dh.dxp.availability.integration.test;

import org.junit.Test;

public class DemoIT {

	@Test
    public void test() {
        System.out.println("This is a integration test.==============");
    }
}
