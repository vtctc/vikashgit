package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShiftDetailstTest {
	public static final String time = "19/6/2019";
	public static final String type = "aaaaaaaaaaaaa";
	public static final String accessPersistentId = "bbbbbbbbbb";
	ShiftDetails shiftDetails = new ShiftDetails();

	@Test
	public void getvlaues() {
		Assert.assertEquals(time, shiftDetails.getTime());
		Assert.assertEquals(type, shiftDetails.getType());
		Assert.assertEquals(accessPersistentId, shiftDetails.getAccessPersistentId());
	}

	@Before
	public void setValues() {
		shiftDetails.setTime(time);
		shiftDetails.setType(type);
		shiftDetails.setAccessPersistentId(accessPersistentId);
	}
}
