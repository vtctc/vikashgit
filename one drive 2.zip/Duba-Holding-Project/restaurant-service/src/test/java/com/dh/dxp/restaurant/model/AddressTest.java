package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AddressTest {
	public static final String addressLine = "Global village teck park";
	public static final String country = "India";
	public static final String state = "Karnataka";
	public static final String Street = "Bhel layout";
	public static final String currencyCode = "Rupees";
	public static final String venueName = "Mindtree";
	public static final String PhoneNumber = "124365879884";
	public Address address = new Address();

	@Test
	public void getValues() {
		Assert.assertEquals(addressLine, address.getAddressLine());
		Assert.assertEquals(country, address.getCountry());
		Assert.assertEquals(state, address.getState());
		Assert.assertEquals(Street, address.getStreet());
		Assert.assertEquals(currencyCode, address.getCurrencyCode());
		Assert.assertEquals(venueName, address.getVenueName());
		Assert.assertEquals(PhoneNumber, address.getPhoneNumber());
	}

	@Before
	public void SetValues() {
		address.setAddressLine(addressLine);
		address.setCountry(country);
		address.setState(state);
		address.setStreet(Street);
		address.setCurrencyCode(currencyCode);
		address.setVenueName(venueName);
		address.setPhoneNumber(PhoneNumber);
	}
}
