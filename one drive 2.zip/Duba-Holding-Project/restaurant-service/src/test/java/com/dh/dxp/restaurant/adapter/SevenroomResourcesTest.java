package com.dh.dxp.restaurant.adapter;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.config.DHConstantUtils;
import com.dh.dxp.restaurant.config.RestTemplateConfig;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SevenroomResourcesTest {
	@Mock
	RestTemplateConfig restTemplateConfig;
	@InjectMocks
	private SevenRoomResources sevenRoomResources;

	@Test
	public void testFindTheShiftDetailsData() throws RestClientException, DHGlobalException {
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "sevenRoomVenueId" + "/shifts";
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(URL)
				.queryParam("end_date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
				.queryParam("start_date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		// request entity is created with request body and headers
		final HttpEntity<String> requestEntity = new HttpEntity<>(requestHeaders);
		Mockito.when(
				restTemplateConfig.getRestTemplate().exchange(builder.build().encode().toUri(), HttpMethod.GET, requestEntity, String.class))
				.thenReturn(new ResponseEntity<>("hello", HttpStatus.OK));
		final ResponseEntity<String> result = sevenRoomResources.getGetServiceWithURIBuilder(builder, requestEntity);
		assertEquals("hello", result.getBody());
	}

	@Test
	public void testFindTheVenueAvailabilityData() throws RestClientException, DHGlobalException {
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "sevenRoomVenueId" + "/availability";
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(URL)
				.queryParam("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
				.queryParam("end_time", "23:00:00").queryParam(DHConstantUtils.PARTY_SIZE, 2)
				.queryParam("start_time", "7:30:00");
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		// request entity is created with request body and headers
		final HttpEntity<String> requestEntity = new HttpEntity<>(requestHeaders);
		Mockito.when(
				restTemplateConfig.getRestTemplate().exchange(builder.build().encode().toUri(), HttpMethod.GET, requestEntity, String.class))
				.thenReturn(new ResponseEntity<>("hello", HttpStatus.OK));
		final ResponseEntity<String> result = sevenRoomResources.getGetServiceWithURIBuilder(builder, requestEntity);
		assertEquals("hello", result.getBody());
	}

	@Test
	public void testToCreateBookingVenue() throws RestClientException, DHGlobalException {
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "sevenRoomsVenueId" + "/book";
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("access_persistent_id", "lllllllllllllllltrrrrrrrrrrrrrrrrrrr");
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "ktk");
		body.add("last_name", "mkt");
		body.add(DHConstantUtils.PARTY_SIZE, 2);
		body.add("phone", "8500691116");
		body.add("time", "12:30:00");
		body.add("email", "ktkmkt@gmail.com");
		body.add("salutation", "Mr");
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		// request entity is created with request body and headers
		Mockito.when(restTemplateConfig.getRestTemplate().exchange(URL, HttpMethod.PUT, requestEntity, String.class))
				.thenReturn(new ResponseEntity<>("hello", HttpStatus.OK));
		final ResponseEntity<String> result = sevenRoomResources.getPutService(URL, requestEntity);
		assertEquals("hello", result.getBody());
	}

	@Test
	public void testToCreateCharge() throws RestClientException, DHGlobalException {
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/reservations/" + "reservationId" + "/add_charge";
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("card_id", "nknk");
		body.add("card_last4", "4356");
		body.add("subtotal", 200);
		body.set("transaction_id", "rerklerlwr");
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		// request entity is created with request body and headers
		Mockito.when(restTemplateConfig.getRestTemplate().exchange(URL, HttpMethod.POST, requestEntity, String.class))
				.thenReturn(new ResponseEntity<>("hello", HttpStatus.OK));
		final ResponseEntity<String> result = sevenRoomResources.getPostService(URL, requestEntity);
		assertEquals("hello", result.getBody());
	}

	@Test
	public void testToCreateReservationHold() throws RestClientException, DHGlobalException {
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "sevenRoomVenueId" + "/hold";
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("time", "12:00:00");
		body.add(DHConstantUtils.PARTY_SIZE, 2);
		body.add("access_persistent_id", "kkkkjhuuuuuyyyyyyyyyyyy");
		body.add("shift_persistent_id", "llllllllllllllllooooooooooooooee");
		body.add("hold_wait_time_sec", 120);
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		// request entity is created with request body and headers
		Mockito.when(restTemplateConfig.getRestTemplate().exchange(URL, HttpMethod.PUT, requestEntity, String.class))
				.thenReturn(new ResponseEntity<>("hello", HttpStatus.OK));
		final ResponseEntity<String> result = sevenRoomResources.getPutService(URL, requestEntity);
		assertEquals("hello", result.getBody());
	}
}
