package com.dh.dxp.restaurant.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.DHRestaurantsApplication;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.BookingResponse;
import com.dh.dxp.restaurant.service.BookingRestaurantService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=DHRestaurantsApplication.class)
public class CreateReservationControllerTest {
	@Mock
	BookingRestaurantService bookingRestaurant;
	@InjectMocks
	CreateReservationController createReservationController;
	BookingRequest bookingReq = new BookingRequest();
	BookingResponse bookingResponse = new BookingResponse();

	@Test
	public void bookingVenueTest1() {
		bookingReq.setType("book");
		bookingResponse.setReservationReferenceCode("33U45SW");
		bookingResponse.setReservationId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yJQsSG25pZ2h0bG9vcF9SZXNlcnZhdGlvbkFjdHVhbBigsZP5BQw");
		try {
			Mockito.when(bookingRestaurant.createBooking(bookingReq)).thenReturn(bookingResponse);
			final ResponseEntity<BookingResponse> bookresponse = createReservationController.bookingVenue(bookingReq);
			assertNotNull(bookresponse);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	@Test(expected = DHGlobalException.class)
	public void bookingVenueTest2() throws DHGlobalException {
		bookingReq.setType("request");
		bookingResponse.setBookingRequestid(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yKQsSHG5pZ2h0bG9vcF9SZXNlcnZhdGlvblJlcXVlc3QYgIDQx8Do6AkM");
		Mockito.when(bookingRestaurant.createBooking(bookingReq)).thenReturn(null);
		final ResponseEntity<BookingResponse> bookingVenue = createReservationController.bookingVenue(bookingReq);
		assertNull(bookingVenue);
	}

	@Before
	public void setUp() {
		bookingReq.setVenueId("ALQ_HANAAYA");
		bookingReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		bookingReq.setTime("21:15");
		bookingReq.setPartySize(2);
		bookingReq.setFirstName("raman");
		bookingReq.setLastName("KUMAR");
		bookingReq.setEmail("cvx@gmail.com");
		bookingReq.setPhone("9998876546");
		bookingReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		bookingReq.setCardNumber("32436545653");
		bookingReq.setCardHolderName("acbs");
		bookingReq.setCvcNumber("2334");
		bookingReq.setExpiryDate("22/2");
		bookingReq.setTitle("Mr");
		bookingReq.setNotes("this is special");
		bookingReq.setReservationHoldId("1560245153.324295");
	}
}
