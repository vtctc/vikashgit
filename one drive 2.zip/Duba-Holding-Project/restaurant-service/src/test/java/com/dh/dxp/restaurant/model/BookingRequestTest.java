package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BookingRequestTest {
	public static final String venueId = "aaaaaaaaaaaaaaaaaaaa";
	public static final String date = "19/6/2019";
	public static final String time = "5:30pm";
	public static final int partySize = 2;
	public static final String firstName = "Shailaja";
	public static final String lastName = "badiger";
	public static final String phone = "8754321212456";
	public static final String accessPersistentId = "bbbbbbbbbbbbbbb";
	public static final String cardNumber = "111111111111111111";
	public static final String cvcNumber = "333";
	public static final String title = "ccccc";
	public static final String type = "dddddd";
	public static final String email = "shailaja@gmail.com";
	public static final String notes = "2";
	public static final String cardHolderName = "shailaja";
	public static final String expiryDate = "19/6/2050";
	public static final String reservationHoldId = "15020202";
	BookingRequest bookingRequest = new BookingRequest();

	@Test
	public void getvalues() {
		Assert.assertEquals(venueId, bookingRequest.getVenueId());
		Assert.assertEquals(date, bookingRequest.getDate());
		Assert.assertEquals(time, bookingRequest.getTime());
		Assert.assertEquals(partySize, bookingRequest.getPartySize());
		Assert.assertEquals(firstName, bookingRequest.getFirstName());
		Assert.assertEquals(lastName, bookingRequest.getLastName());
		Assert.assertEquals(phone, bookingRequest.getPhone());
		Assert.assertEquals(accessPersistentId, bookingRequest.getAccessPersistentId());
		Assert.assertEquals(cardNumber, bookingRequest.getCardNumber());
		Assert.assertEquals(cvcNumber, bookingRequest.getCvcNumber());
		Assert.assertEquals(title, bookingRequest.getTitle());
		Assert.assertEquals(type, bookingRequest.getType());
		Assert.assertEquals(email, bookingRequest.getEmail());
		Assert.assertEquals(notes, bookingRequest.getNotes());
		Assert.assertEquals(cardHolderName, bookingRequest.getCardHolderName());
		Assert.assertEquals(expiryDate, bookingRequest.getExpiryDate());
		Assert.assertEquals(reservationHoldId, bookingRequest.getReservationHoldId());
	}

	@Before
	public void setValues() {
		bookingRequest.setVenueId(venueId);
		bookingRequest.setDate(date);
		bookingRequest.setTime(time);
		bookingRequest.setPartySize(partySize);
		bookingRequest.setFirstName(firstName);
		bookingRequest.setLastName(lastName);
		bookingRequest.setPhone(phone);
		bookingRequest.setAccessPersistentId(accessPersistentId);
		bookingRequest.setCardNumber(cardNumber);
		bookingRequest.setCvcNumber(cvcNumber);
		bookingRequest.setTitle(title);
		bookingRequest.setType(type);
		bookingRequest.setEmail(email);
		bookingRequest.setNotes(notes);
		bookingRequest.setCardHolderName(cardHolderName);
		bookingRequest.setExpiryDate(expiryDate);
		bookingRequest.setReservationHoldId("15020202");
	}
}
