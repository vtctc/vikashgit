package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ReservationHoldResponseTest {
	public static final String EXPECTED_ACCESSPERSISTENTID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw";
	public static final String EXPECTED_SHIFTPERSISTENTID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufY";
	public static final int EXPECTED_HOLDWAITTIMESEC = 120;
	public static final String EXPECTED_RESERVATIONHOLDID = "1500123456";
	final ReservationHoldResponse reservationHoldRes = new ReservationHoldResponse();

	@Before
	public void setUp() throws Exception {
		reservationHoldRes
				.setAccessPersistentId("ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw");
		reservationHoldRes
				.setShiftPersistentId("ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufY");
		reservationHoldRes.setReservationHoldId("1500123456");
		reservationHoldRes.setHoldDurationSec(120);
	}

	@Test
	public void testResesrvationHoldRequest() {
		Assert.assertEquals(EXPECTED_ACCESSPERSISTENTID, reservationHoldRes.getAccessPersistentId());
		Assert.assertEquals(EXPECTED_SHIFTPERSISTENTID, reservationHoldRes.getShiftPersistentId());
		Assert.assertEquals(EXPECTED_HOLDWAITTIMESEC, reservationHoldRes.getHoldDurationSec());
		Assert.assertEquals(EXPECTED_RESERVATIONHOLDID, reservationHoldRes.getReservationHoldId());
	}
}
