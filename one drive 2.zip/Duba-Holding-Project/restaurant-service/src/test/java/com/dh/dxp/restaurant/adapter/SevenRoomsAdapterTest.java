package com.dh.dxp.restaurant.adapter;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.util.UriComponentsBuilder;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.dh.dxp.restaurant.config.DHConstantUtils;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SevenRoomsAdapterTest {
	@InjectMocks
	SavenRoomsAdapter savenRoomsAdapter;
	@Mock
	SevenRoomResources sevenRoomResources;
	@Mock
	AuthorizationResource authorizationResource;
	@Mock
	HotelRestaurantMappingServiceImpl mappingsService;

	private BookingRequest bookingRequestToExcptionalCase()
			throws FileNotFoundException, IOException, JsonProcessingException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationrequest.json");
		mapper.readTree(file);
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", 1);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);

		final BookingRequest request = new BookingRequest();
		request.setVenueId("BAA_TORTUGA");
		request.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		request.setTime("21:15");
		request.setPartySize(3);
		request.setFirstName("raman");
		request.setReservationHoldId("1561014781.706820");
		request.setExpiryDate("22/22");
		request.setTitle("Mr.");
		request.setLastName("KUMAR");
		request.setEmail("cvx@gmail.com");
		request.setPhone("9998876546");
		request.setAccessPersistentId("");
		request.setCardHolderName("vikash");
		request.setCardNumber("0988776554323456");
		request.setCvcNumber("212");
		request.setType("request");
		request.setNotes("hello");
		request.setAdults(1);
		request.setChildren(1);
		request.setInfants(1);
		request.setCountryCode("+91");

		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("bvejbvejbckcjhfew7f8wte7");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "raman");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "9998876546");
		body.add("time", "21:15");
		body.add("email", "cvx@gmail.com");
		body.add("notes", "hello");
		body.add("phone", "+919998876546");

		final StringBuilder bookingReqNotes = new StringBuilder();
		bookingReqNotes.append("hello");
		bookingReqNotes.append("\n");
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);

		new HttpEntity<>(body, requestHeaders);
		return request;
	}

	@Test
	public void createBookingRequestTest1() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationrequest.json");
		final JsonNode root = mapper.readTree(file);
		
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", 1);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);

		final BookingRequest request = new BookingRequest();
		request.setVenueId("BAA_TORTUGA");
		request.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		request.setTime("21:15");
		request.setPartySize(3);
		request.setFirstName("raman");
		request.setLastName("KUMAR");
		request.setEmail("cvx@gmail.com");
		request.setCountryCode("+91");
		request.setPhone("9998876546");
		request.setAccessPersistentId("");
		request.setCardHolderName("vikash");
		request.setCardNumber("0988776554323456");
		request.setCvcNumber("212");
		request.setType("request");
		request.setNotes("hello");
		request.setAdults(1);
		request.setChildren(1);
		request.setInfants(1);

		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("bvejbvejbckcjhfew7f8wte7");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		final StringBuilder bookingReqNotes = new StringBuilder();
		bookingReqNotes.append("hello");
		bookingReqNotes.append("\n");
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);
		body.add("notes", bookingReqNotes);
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "raman");
		body.add("last_name", "KUMAR");
		body.add("party_size", 3);
		body.add("phone", "9998876546");
		body.add("time", "21:15");
		body.add("email", "cvx@gmail.com");
		body.add("notes", "hello");
		body.add("phone", "+918500691116");

		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "BAA_TORTUGA" + "/request";

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(request.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		savenRoomsAdapter.createBookingRequest(request);

	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void createBookingRequestTest2() throws DHGlobalException, JsonProcessingException, IOException {

		final BookingRequest request = bookingRequestToExcptionalCase();

		Mockito.when(sevenRoomResources.getPutService(any(String.class), any(HttpEntity.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));
		savenRoomsAdapter.createBookingRequest(request);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void createBookingRequestTest3() throws DHGlobalException, JsonProcessingException, IOException {

		final BookingRequest request = bookingRequestToExcptionalCase();
		Mockito.when(sevenRoomResources.getPutService(any(String.class), any(HttpEntity.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.FORBIDDEN));
		savenRoomsAdapter.createBookingRequest(request);
	}

	@Test(expected = DHGlobalException.class)
	public void createBookingRequestTest4() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationrequest.json");
		final JsonNode root = mapper.readTree(file);
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		final BookingRequest request = new BookingRequest();
		request.setVenueId("BAA_TORTUGA");
		request.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MMMM/dd")));
		request.setTime("21:15");
		request.setPartySize(2);
		request.setFirstName("raman");
		request.setLastName("KUMAR");
		request.setEmail("cvx@gmail.com");
		request.setPhone("9998876546");
		request.setAccessPersistentId("");
		request.setCardHolderName("vikash");
		request.setCardNumber("0988776554323456");
		request.setCvcNumber("212");
		request.setType("request");
		request.setNotes("hello");

		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("bvejbvejbckcjhfew7f8wte7");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "raman");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "9998876546");
		body.add("time", "21:15");
		body.add("email", "cvx@gmail.com");
		body.add("notes", "hello");
		body.add("phone", "+91");

		informationAboutGuest.put("adults", 3);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "BAA_TORTUGA" + "/request";

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(request.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		final ResponseEntity<String> createBookingRes = savenRoomsAdapter.createBookingRequest(request);
		assertEquals(root.toString(), createBookingRes.getBody().toString());
	}

	@Test(expected = DHGlobalException.class)
	public void createBookingRequestTest5() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationrequest.json");
		final JsonNode root = mapper.readTree(file);
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		final BookingRequest request = new BookingRequest();
		request.setVenueId("BAA_TORTUGA");
		request.setDate("2019-06-11");
		request.setTime("21:15");
		request.setPartySize(2);
		request.setFirstName("raman");
		request.setLastName("KUMAR");
		request.setEmail("cvx@gmail.com");
		request.setPhone("9998876546");
		request.setAccessPersistentId("");
		request.setCardHolderName("vikash");
		request.setCardNumber("0988776554323456");
		request.setCvcNumber("212");
		request.setType("request");
		request.setNotes("hello");

		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("bvejbvejbckcjhfew7f8wte7");
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "raman");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "9998876546");
		body.add("time", "21:15");
		body.add("email", "cvx@gmail.com");
		body.add("notes", "hello");
		body.add("phone", "+91");

		informationAboutGuest.put("adults", 3);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/" + "BAA_TORTUGA" + "/request";

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(request.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		final ResponseEntity<String> createBookingRes = savenRoomsAdapter.createBookingRequest(request);
		assertEquals(root.toString(), createBookingRes.getBody().toString());
	}

	// For Reservation
	@SuppressWarnings("unchecked")
	@Test
	public void createBookingVenueTest1() throws DHGlobalException, JsonProcessingException, IOException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservation.json");
		final JsonNode root = mapper.readTree(file);

		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", 1);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);

		final BookingRequest bookingReq = new BookingRequest();
		bookingReq.setVenueId("BAA_TORTUGA");
		bookingReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		bookingReq.setTime("223ded21:15");
		bookingReq.setPartySize(2);
		bookingReq.setFirstName("raman");
		bookingReq.setLastName("KUMAR");
		bookingReq.setEmail("cvx@gmail.com");
		bookingReq.setPhone("9998876546");
		bookingReq.setAccessPersistentId("");
		bookingReq.setCardHolderName("vikash");
		bookingReq.setCardNumber("0988776554323456");
		bookingReq.setCvcNumber("212");
		bookingReq.setType("book");
		bookingReq.setTitle("Mr.");
		bookingReq.setReservationHoldId("1561014781.706820");
		bookingReq.setNotes("this is");
		bookingReq.setAdults(1);
		bookingReq.setChildren(1);
		bookingReq.setInfants(1);
		bookingReq.setCountryCode("+91");

		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("access_persistent_id",
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "rajiva");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "+919998876546");
		body.add("time", "22:15");
		body.add("email", "cvyx@gmail.com");
		body.add("salutation", "Mr.");
		body.add("reservation_hold_id", "1560245153.324295");

		final StringBuilder bookingReqNotes = new StringBuilder();
		bookingReqNotes.append("hello");
		bookingReqNotes.append("\n");
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(bookingReq.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(any(String.class), any(HttpEntity.class)))
				.thenReturn(ResponseEntity.ok(root.toString()));

		Mockito.when(sevenRoomResources.getPostService(any(String.class), any(HttpEntity.class)))
				.thenReturn(ResponseEntity.ok(root.toString()));

		final ResponseEntity<String> result = savenRoomsAdapter.createBookingVenue(bookingReq);

	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void createBookingVenueTest2() throws DHGlobalException, JsonProcessingException, IOException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservation.json");
		final JsonNode root = mapper.readTree(file);
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", 1);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);

		final BookingRequest bookingReq = new BookingRequest();
		bookingReq.setVenueId("BAA_TORTUGA");
		bookingReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		bookingReq.setTime("223ded21:15");
		bookingReq.setPartySize(2);
		bookingReq.setFirstName("raman");
		bookingReq.setLastName("KUMAR");
		bookingReq.setEmail("cvx@gmail.com");
		bookingReq.setPhone("9998876546");
		bookingReq.setAccessPersistentId("");
		bookingReq.setCardHolderName("vikash");
		bookingReq.setCardNumber("0988776554323456");
		bookingReq.setCvcNumber("212");
		bookingReq.setType("book");
		bookingReq.setTitle("Mr.");
		bookingReq.setReservationHoldId("1561014781.706820");
		bookingReq.setNotes("this is");
		bookingReq.setAdults(1);
		bookingReq.setChildren(1);
		bookingReq.setInfants(1);
		bookingReq.setCountryCode("+91");

		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("access_persistent_id",
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "rajiva");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "9998876546");
		body.add("time", "22:15");
		body.add("email", "cvyx@gmail.com");
		body.add("salutation", "Mr.");
		body.add("reservation_hold_id", "1560245153.324295");

		final StringBuilder bookingReqNotes = new StringBuilder();
		bookingReqNotes.append("hello");
		bookingReqNotes.append("\n");
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(bookingReq.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(any(String.class), any(HttpEntity.class)))
				.thenReturn(ResponseEntity.ok(root.toString()));

		Mockito.when(sevenRoomResources.getPostService(any(String.class), any(HttpEntity.class)))
				.thenThrow(ResourceAccessException.class);

		savenRoomsAdapter.createBookingVenue(bookingReq);

	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void createBookingVenueTest3() throws DHGlobalException, JsonProcessingException, IOException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservation.json");
		final JsonNode root = mapper.readTree(file);
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", 1);
		informationAboutGuest.put("children", 1);
		informationAboutGuest.put("infants", 1);

		final BookingRequest bookingReq = new BookingRequest();
		bookingReq.setVenueId("BAA_TORTUGA");
		bookingReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		bookingReq.setTime("223ded21:15");
		bookingReq.setPartySize(2);
		bookingReq.setFirstName("raman");
		bookingReq.setLastName("KUMAR");
		bookingReq.setEmail("cvx@gmail.com");
		bookingReq.setPhone("9998876546");
		bookingReq.setAccessPersistentId("");
		bookingReq.setCardHolderName("vikash");
		bookingReq.setCardNumber("0988776554323456");
		bookingReq.setCvcNumber("212");
		bookingReq.setType("book");
		bookingReq.setTitle("Mr.");
		bookingReq.setReservationHoldId("1561014781.706820");
		bookingReq.setNotes("this is");
		bookingReq.setAdults(1);
		bookingReq.setChildren(1);
		bookingReq.setInfants(1);
		bookingReq.setCountryCode("+91");

		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

		body.add("access_persistent_id",
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		body.add("date", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		body.add("first_name", "rajiva");
		body.add("last_name", "KUMAR");
		body.add("party_size", 2);
		body.add("phone", "9998876546");
		body.add("time", "22:15");
		body.add("email", "cvyx@gmail.com");
		body.add("salutation", "Mr.");
		body.add("reservation_hold_id", "1560245153.324295");

		final StringBuilder bookingReqNotes = new StringBuilder();
		bookingReqNotes.append("hello");
		bookingReqNotes.append("\n");
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);

		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("bvejbvejbckcjhfew7f8wte7");
		Mockito.when(mappingsService.findBookingSystemId(bookingReq.getVenueId())).thenReturn("BAA_TORTUGA");
		Mockito.when(sevenRoomResources.getPutService(any(String.class), any(HttpEntity.class)))
				.thenThrow(ResourceAccessException.class);
		Mockito.when(sevenRoomResources.getPostService(any(String.class), any(HttpEntity.class)))
				.thenReturn(ResponseEntity.ok(root.toString()));

		savenRoomsAdapter.createBookingVenue(bookingReq);

	}

	@Test
	public void createReservationHoldTest1() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationhold.json");
		final JsonNode root = mapper.readTree(file);

		final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-1485899848.43-0.2332702871");
		reservationHoldReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-DINNER-1485898159.02");
		reservationHoldReq.setTime("9:00");
		reservationHoldReq.setVenueId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		Mockito.when(mappingsService.findBookingSystemId(reservationHoldReq.getVenueId()))
				.thenReturn("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/"
				+ "aaaaaaaaaaaaaaffffffffffffffffgggggggggg" + "/hold";
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", reservationHoldReq.getDate());
		body.add("time", reservationHoldReq.getTime());
		body.add(DHConstantUtils.PARTY_SIZE, reservationHoldReq.getPartySize());
		body.add("access_persistent_id", reservationHoldReq.getAccessPersistentId());
		body.add("shift_persistent_id", reservationHoldReq.getShiftPersistentId());
		body.add("hold_wait_time_sec", reservationHoldReq.getHoldWaitTimeSec());
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenReturn(ResponseEntity.ok(root.toString()));

		final ResponseEntity<String> reservationHoldRes = savenRoomsAdapter.createReservationHold(reservationHoldReq);
		assertEquals(root.toString(), reservationHoldRes.getBody().toString());
	}

	@Test
	public void createReservationHoldTest2() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationhold.json");
		final JsonNode root = mapper.readTree(file);

		final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-1485899848.43-0.2332702871");
		reservationHoldReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		reservationHoldReq.setHoldWaitTimeSec(null);
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-DINNER-1485898159.02");
		reservationHoldReq.setTime("9:00");
		reservationHoldReq.setVenueId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		Mockito.when(mappingsService.findBookingSystemId(reservationHoldReq.getVenueId()))
				.thenReturn("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/"
				+ "aaaaaaaaaaaaaaffffffffffffffffgggggggggg" + "/hold";
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", reservationHoldReq.getDate());
		body.add("time", reservationHoldReq.getTime());
		body.add(DHConstantUtils.PARTY_SIZE, reservationHoldReq.getPartySize());
		body.add("access_persistent_id", reservationHoldReq.getAccessPersistentId());
		body.add("shift_persistent_id", reservationHoldReq.getShiftPersistentId());
		body.add("hold_wait_time_sec", reservationHoldReq.getHoldWaitTimeSec());
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenReturn(ResponseEntity.ok(root.toString()));

		savenRoomsAdapter.createReservationHold(reservationHoldReq);
	}

	@Test(expected = DHGlobalException.class)
	public void createReservationHoldTest3() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationhold.json");
		mapper.readTree(file);

		final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-1485899848.43-0.2332702871");
		reservationHoldReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-DINNER-1485898159.02");
		reservationHoldReq.setTime("9:00");
		reservationHoldReq.setVenueId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		Mockito.when(mappingsService.findBookingSystemId(reservationHoldReq.getVenueId()))
				.thenReturn("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/"
				+ "aaaaaaaaaaaaaaffffffffffffffffgggggggggg" + "/hold";
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", reservationHoldReq.getDate());
		body.add("time", reservationHoldReq.getTime());
		body.add(DHConstantUtils.PARTY_SIZE, reservationHoldReq.getPartySize());
		body.add("access_persistent_id", reservationHoldReq.getAccessPersistentId());
		body.add("shift_persistent_id", reservationHoldReq.getShiftPersistentId());
		body.add("hold_wait_time_sec", reservationHoldReq.getHoldWaitTimeSec());
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);

		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

		savenRoomsAdapter.createReservationHold(reservationHoldReq);
	}

	@Test(expected = DHGlobalException.class)
	public void createReservationHoldTest4() throws DHGlobalException, JsonProcessingException, IOException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationhold.json");
		mapper.readTree(file);

		final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-1485899848.43-0.2332702871");
		reservationHoldReq.setDate("2019-06-11");
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBu6SRCgw-DINNER-1485898159.02");
		reservationHoldReq.setTime("9:00");
		reservationHoldReq.setVenueId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator("authToken");
		Mockito.when(mappingsService.findBookingSystemId(reservationHoldReq.getVenueId()))
				.thenReturn("aaaaaaaaaaaaaaffffffffffffffffgggggggggg");
		final String url = "https://demo.sevenrooms.com/api-ext/2_2/venues/"
				+ "aaaaaaaaaaaaaaffffffffffffffffgggggggggg" + "/hold";
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", reservationHoldReq.getDate());
		body.add("time", reservationHoldReq.getTime());
		body.add(DHConstantUtils.PARTY_SIZE, reservationHoldReq.getPartySize());
		body.add("access_persistent_id", reservationHoldReq.getAccessPersistentId());
		body.add("shift_persistent_id", reservationHoldReq.getShiftPersistentId());
		body.add("hold_wait_time_sec", reservationHoldReq.getHoldWaitTimeSec());
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);

		Mockito.when(sevenRoomResources.getPutService(url, requestEntity))
				.thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

		savenRoomsAdapter.createReservationHold(reservationHoldReq);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getShiftDetailsTest1() throws JsonProcessingException, IOException, DHGlobalException {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		requestHeaders.add("Authorization", "authToken");
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final LocalDate date = LocalDate.now();
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg"))
				.thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeaders);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		final ResponseEntity<String> shiftDetailsRes = savenRoomsAdapter.getShiftDetails(venueId, date);
		assertEquals(root.toString(), shiftDetailsRes.getBody().toString());
	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void getShiftDetailsTest2() throws JsonProcessingException, IOException, DHGlobalException {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		requestHeaders.add("Authorization", "authToken");
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final LocalDate date = LocalDate.now();
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg"))
				.thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeaders);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.UNAUTHORIZED));
		savenRoomsAdapter.getShiftDetails(venueId, date);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void getShiftDetailsTest3() throws JsonProcessingException, IOException, DHGlobalException {
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		requestHeaders.add("Authorization", "authToken");
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final LocalDate date = LocalDate.now();
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("aaaaaaaaaaaaaaffffffffffffffffgggggggggg"))
				.thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeaders);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.INTERNAL_SERVER_ERROR));
		savenRoomsAdapter.getShiftDetails(venueId, date);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getVenueAvailabilityTest1() throws JsonProcessingException, IOException, DHGlobalException {
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final Integer partySize = 2;
		final LocalDate date = LocalDate.now();
		final String startTime = "7:30";
		final String endTime = "23:00";
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("BAA_TTT")).thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final String authToken = authorizationResource.getNewApiToken();
		final HttpHeaders requestHeader = sevenRoomResources.requesteHeaderValidator(authToken);
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeader);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		final ResponseEntity<String> venueAvailabilityRes = savenRoomsAdapter.getVenueAvailability("BAA_TTT", partySize,
				date, startTime, endTime);
		assertEquals(root.toString(), venueAvailabilityRes.getBody().toString());
	}

	@Test(expected = DHGlobalException.class)
	public void getVenueAvailabilityTest2() throws JsonProcessingException, IOException, DHGlobalException {
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final Integer partySize = 2;
		final LocalDate date = LocalDate.now();
		final String startTime = "7:30";
		final String endTime = "23:00";
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("BAA_TTT")).thenReturn(venueId);
		final String authToken = null;
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn(authToken);

		sevenRoomResources.requesteHeaderValidator(authToken);
		savenRoomsAdapter.getVenueAvailability("BAA_TTT", partySize, date, startTime, endTime);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void getVenueAvailabilityTest3() throws JsonProcessingException, IOException, DHGlobalException {
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final Integer partySize = 2;
		final LocalDate date = LocalDate.now();
		final String startTime = "7:30";
		final String endTime = "23:00";
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("BAA_TTT")).thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final String authToken = authorizationResource.getNewApiToken();
		final HttpHeaders requestHeader = sevenRoomResources.requesteHeaderValidator(authToken);
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeader);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.UNAUTHORIZED));
		savenRoomsAdapter.getVenueAvailability("BAA_TTT", partySize, date, startTime, endTime);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = DHGlobalException.class)
	public void getVenueAvailabilityTest4() throws JsonProcessingException, IOException, DHGlobalException {
		final String venueId = "aaaaaaaaaaaaaaffffffffffffffffgggggggggg";
		final Integer partySize = 2;
		final LocalDate date = LocalDate.now();
		final String startTime = "7:30";
		final String endTime = "23:00";
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(file);
		Mockito.when(mappingsService.findBookingSystemId("BAA_TTT")).thenReturn(venueId);
		Mockito.when(authorizationResource.getNewApiToken()).thenReturn("authToken");
		final String authToken = authorizationResource.getNewApiToken();
		final HttpHeaders requestHeader = sevenRoomResources.requesteHeaderValidator(authToken);
		Mockito.when(sevenRoomResources.requesteHeaderValidator("authToken")).thenReturn(requestHeader);
		Mockito.when(
				sevenRoomResources.getGetServiceWithURIBuilder(any(UriComponentsBuilder.class), any(HttpEntity.class)))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.INTERNAL_SERVER_ERROR));
		savenRoomsAdapter.getVenueAvailability("BAA_TTT", partySize, date, startTime, endTime);
	}

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(savenRoomsAdapter, "baseUrl", "https://demo.sevenrooms.com/api-ext/2_2/venues/");
		ReflectionTestUtils.setField(savenRoomsAdapter, "chargeBaseUrl",
				"https://demo.sevenrooms.com/api-ext/2_2/reservations/");
		ReflectionTestUtils.setField(savenRoomsAdapter, "holdWaitTimeSec", 120);
		ReflectionTestUtils.setField(savenRoomsAdapter, "baseChargeAmount", 100);
		MockitoAnnotations.initMocks(this); // without this you will get NPE
	}

}