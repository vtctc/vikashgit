package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AuthRequestTest {
	public static final String clientId = "aaaaaaaaaaaaaaaaaaaaaaaa";
	public static final String clientSecret = "bbbbbbbbbbbbbbbbbbbbb";
	public AuthRequest authRequest = new AuthRequest();

	@Test
	public void getValues() {
		Assert.assertEquals(clientId, authRequest.getClientId());
		Assert.assertEquals(clientSecret, authRequest.getClientSecret());
	}

	@Before
	public void setvalues() {
		authRequest.setClientId(clientId);
		authRequest.setClientSecret(clientSecret);
	}
}
