package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class VenueTest {
	String EXPECTED_VENUENAME = "ALQew";
	String EXPECTED_VENUECLASS = "dre";
	Venue venue = new Venue();

	@Before
	public void setvalues() {
		final Address address = new Address();
		address.setVenueName("rety");
		venue.setAddress(address);
		final VenueShift venueShift = new VenueShift();
		venueShift.setShiftName("lunch");
		venue.setVenueShift(venueShift);
		venue.setVenueName(EXPECTED_VENUENAME);
		venue.setVenueClass(EXPECTED_VENUECLASS);
		venue.setAddress(address);
		venue.setVenueShift(venueShift);
	}

	@Test
	public void testVenue() {
		final VenueShift venueShift = new VenueShift();
		venueShift.setShiftName("lunch");
		venue.setVenueShift(venueShift);
		final Address address = new Address();
		venue.setAddress(address);
		address.setVenueName("rety");
		Assert.assertEquals(EXPECTED_VENUENAME, venue.getVenueName());
		Assert.assertEquals(EXPECTED_VENUECLASS, venue.getVenueClass());
		Assert.assertEquals(venue.getVenueShift(), venue.getVenueShift());
		Assert.assertEquals(venue.getAddress(), venue.getAddress());
	}
}
