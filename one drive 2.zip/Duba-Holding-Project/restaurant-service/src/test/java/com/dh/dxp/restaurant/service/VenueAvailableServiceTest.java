package com.dh.dxp.restaurant.service;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.adapter.SevenRoomResources;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest()
public class VenueAvailableServiceTest {
	@Mock
	SevenRoomResources sevenRoomResources;
	@Mock
	SavenRoomsAdapter roomsAdapter;
	@InjectMocks
	VenueAvailableService venueAvailableService;
	private final String startTime = "7:30:00";
	private final String endTime = "23:00:00";
	String venueId = "ALQ_HANAAYA";

	@Test
	public void venueAvailableTest1() throws DHGlobalException, IOException, ParseException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode shift = mapper.readTree(file);

		final File filee = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(filee);

		final int partySize = 2;
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		final String date1 = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		final LocalDate date = LocalDate.parse(date1, dateFormatter);

		Mockito.when(roomsAdapter.getShiftDetails(venueId, date))
				.thenReturn(new ResponseEntity<>(shift.toString(), HttpStatus.OK));

		Mockito.when(roomsAdapter.getVenueAvailability(venueId, partySize, date, startTime, endTime))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));

		venueAvailableService.getVenueAvailabilityByShift(venueId, partySize, date1);
	}

	@Test(expected = DHGlobalException.class)
	public void venueAvailableTest2() throws DHGlobalException, IOException, ParseException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode shift = mapper.readTree(file);

		final File filee = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(filee);

		final int partySize = 2;
		final String date1 = "2011-jan-20";
		final LocalDate date = LocalDate.of(2019, 06, 30);
		Mockito.when(roomsAdapter.getShiftDetails(venueId, date)).thenThrow(DateTimeParseException.class);

		Mockito.when(roomsAdapter.getVenueAvailability(venueId, partySize, date, startTime, endTime))
				.thenThrow(DateTimeParseException.class);
		venueAvailableService.getVenueAvailabilityByShift(venueId, partySize, date1);
	}

	@Test(expected = DHGlobalException.class)
	public void venueAvailableTest3() throws DHGlobalException, IOException, ParseException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode shift = mapper.readTree(file);

		final File filee = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(filee);

		final int partySize = 2;
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		final String date1 = "2019-06-11";
		final LocalDate date = LocalDate.parse(date1, dateFormatter);
		Mockito.when(roomsAdapter.getShiftDetails(venueId, date)).thenThrow(DateTimeParseException.class);

		Mockito.when(roomsAdapter.getVenueAvailability(venueId, partySize, date, startTime, endTime))
				.thenThrow(DateTimeParseException.class);
		venueAvailableService.getVenueAvailabilityByShift(venueId, partySize, date1);
	}

	@Test(expected=DHGlobalException.class)
	public void venueAvailableTest4() throws DHGlobalException, IOException, ParseException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_shifts.json");
		final JsonNode shift = mapper.readTree(file);

		final File filee = ResourceUtils.getFile("classpath:mockData/mock_availability.json");
		final JsonNode root = mapper.readTree(filee);

		final int partySize = 2;
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		final String date1 = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		final LocalDate date = LocalDate.parse(date1, dateFormatter);

		Mockito.when(roomsAdapter.getShiftDetails(venueId, date))
				.thenReturn(new ResponseEntity<>(shift.toString(), HttpStatus.OK));

		Mockito.when(roomsAdapter.getVenueAvailability(venueId, partySize, date, startTime, endTime))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.BAD_REQUEST));
		venueAvailableService.getVenueAvailabilityByShift(venueId, partySize, date1);
	}
	
	
}
