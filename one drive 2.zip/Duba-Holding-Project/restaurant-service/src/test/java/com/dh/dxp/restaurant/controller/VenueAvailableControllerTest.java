package com.dh.dxp.restaurant.controller;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.model.ShiftsListModel;
import com.dh.dxp.restaurant.service.VenueAvailableService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VenueAvailableControllerTest {
	@Mock
	VenueAvailableService venueAvailableService;
	@InjectMocks
	VenueAvailableController venueAvailableController;

	@Test
	public void venueAvailableTest() throws DHGlobalException, IOException, ParseException {
		final String venueId = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgKCBpqqSCgw";
		final int partySize = 2;
		final String dateInString = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		final ResponseEntity<ShiftsListModel> shiftList = venueAvailableController.singleVenueDetail(venueId, partySize,
				dateInString);
		assertNotNull(shiftList);
	}
}
