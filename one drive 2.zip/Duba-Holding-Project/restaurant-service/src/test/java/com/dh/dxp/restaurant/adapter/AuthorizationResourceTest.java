package com.dh.dxp.restaurant.adapter;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.config.RestTemplateConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AuthorizationResourceTest {
	@Mock
	private RestTemplate restTemplate;
	@InjectMocks
	private AuthorizationResource authResource;
	
	@Mock
	RestTemplateConfig restTemplateConfig;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(authResource, "authResourceURL", "https://demo.sevenrooms.com/api-ext/2_2/auth");
		ReflectionTestUtils.setField(authResource, "sevenRoomsClientId",
				"chhhhhhhhhhhhhhhhuuuuuuuuuuuuuuuuuuiiiiiiiiiiiiiiikkkkkwwww");
		ReflectionTestUtils.setField(authResource, "sevenRoomsClientSecret", "kkkkkkkkkkkkkkkkkkkkrrrrrrrrrreeeee");
	}

	@Test
	public void testGetNewApiToken() throws JsonProcessingException, IOException, DHGlobalException {
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_auth.json");
		final JsonNode root = mapper.readTree(file);
		final String URL = "https://demo.sevenrooms.com/api-ext/2_2/auth";
		String authResourceURL="ttps://demo.sevenrooms.com/api-ext/2_2/auth";
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		// Create the request body as a MultiValueMap
		final MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
		body.add("client_id", "chhhhhhhhhhhhhhhhuuuuuuuuuuuuuuuuuuiiiiiiiiiiiiiiikkkkkwwww");
		body.add("client_secret", "kkkkkkkkkkkkkkkkkkkkrrrrrrrrrreeeee");
		final HttpEntity<?> httpEntity = new HttpEntity<>(body, requestHeaders);
		
		Mockito.when(restTemplate.exchange(URL, HttpMethod.POST, httpEntity, String.class))
				.thenReturn(new ResponseEntity<>(root.toString(), HttpStatus.OK));
		final String newApiToken = authResource.getNewApiToken();
		assertEquals(root.get("data").get("token").textValue(), newApiToken);
	}
	
	
}
