package com.dh.dxp.restaurant.model;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AvailableResponseTest {
	public static final boolean isClosed = true;
	public static final String restuartntStatus = "Available";
	public static final String shiftCategory = "aaaaaaaaaaa";
	public static final String shiftId = "bbbbbbbbbbbbb";
	AvailableResponse availableResponse = new AvailableResponse();

	@Test
	public void getValues() {
		final ShiftDetails shiftDetails = new ShiftDetails();
		shiftDetails.setAccessPersistentId("aaaaaaaaaaaaeeeeeeeeeeee");
		shiftDetails.setTime("12:00");
		shiftDetails.setType("book");
		availableResponse.setShiftDetails(new ArrayList<>());
		availableResponse.getShiftDetails().add(shiftDetails);
		Assert.assertEquals(availableResponse.getShiftDetails(), availableResponse.getShiftDetails());
		Assert.assertEquals(isClosed, availableResponse.isClosed());
		Assert.assertEquals(restuartntStatus, availableResponse.getRestuartntStatus());
		Assert.assertEquals(shiftId, availableResponse.getShiftId());
		Assert.assertEquals(shiftCategory, availableResponse.getShiftCategory());
		Assert.assertEquals(shiftCategory, availableResponse.getShiftCategory());
	}

	@Before
	public void setvalues() {
		final ShiftDetails shiftDetails = new ShiftDetails();
		shiftDetails.setAccessPersistentId("aaaaaaaaaaaaeeeeeeeeeeee");
		shiftDetails.setTime("12:00");
		shiftDetails.setType("book");
		availableResponse.setShiftDetails(new ArrayList<>());
		availableResponse.getShiftDetails().add(shiftDetails);
		availableResponse.setClosed(isClosed);
		availableResponse.setRestuartntStatus(restuartntStatus);
		availableResponse.setShiftCategory(shiftCategory);
		availableResponse.setShiftId(shiftId);
	}
}
