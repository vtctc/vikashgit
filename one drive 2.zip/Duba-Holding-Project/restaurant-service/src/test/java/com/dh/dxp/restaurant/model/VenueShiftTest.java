package com.dh.dxp.restaurant.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class VenueShiftTest {
	public static final String EXPECTED_START_DATE = "2019-06-22";
	public static final String EXPECTED_END_DATE = "2019-06-28";
	public static final String SHIFT_CATEGORY = "LUNCH";
	public static final String SHIFT_NAME = "LUNCH";
	public static final String SHIFT_START_TIME = "1:00 PM";
	public static final String SHIFT_END_TIME = "4:00 PM";
	private VenueShift venueShift;

	@Before
	public void setUp() {
		venueShift = new VenueShift();
		venueShift.setStarDate("2019-06-22");
		venueShift.setEnddate("2019-06-28");
		venueShift.setShiftCategory("LUNCH");
		venueShift.setShiftName("LUNCH");
		venueShift.setShiftStartTime("1:00 PM");
		venueShift.setShiftEndTime("4:00 PM");
	}

	@Test
	public void venueShiftTest() {
		assertEquals(EXPECTED_START_DATE, venueShift.getStarDate());
		assertEquals(EXPECTED_END_DATE, venueShift.getEnddate());
		assertEquals(SHIFT_CATEGORY, venueShift.getShiftCategory());
		assertEquals(SHIFT_NAME, venueShift.getShiftName());
		assertEquals(SHIFT_START_TIME, venueShift.getShiftStartTime());
		assertEquals(SHIFT_END_TIME, venueShift.getShiftEndTime());
	}
}
