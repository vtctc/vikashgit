package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BookingResponseTest {
	public static final String reservationReferenceCode = "aaaaaaaaaaaaaa";
	public static final String reservationId = "bbbbbbbbbbbb";
	public static final String bookingRequestid = "ccccccccc";
	BookingResponse BookingResponse = new BookingResponse();

	@Test
	public void getValues() {
		Assert.assertEquals(reservationReferenceCode, BookingResponse.getReservationReferenceCode());
		Assert.assertEquals(reservationId, BookingResponse.getReservationId());
		Assert.assertEquals(bookingRequestid, BookingResponse.getBookingRequestid());
	}

	@Before
	public void setValues() {
		BookingResponse.setReservationReferenceCode(reservationReferenceCode);
		BookingResponse.setReservationId(reservationId);
		BookingResponse.setBookingRequestid(bookingRequestid);
	}
}
