package com.dh.dxp.restaurant.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class VenueAvailabilityResponseDTOTest {
	public static final String ACCESS_PERSISTENT_ID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218";
	public static final String TIME = "21:15";
	public static final String TYPE = "request";
	public static final boolean STATUS = true;
	public static final String SHIFT_PERSISTENT_ID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-LUNCH-1554165966.01";
	private VenuesAvailablityResponceDTO venueAvailabilityResponseDTO;

	@Before
	public void setUp() {
		venueAvailabilityResponseDTO = new VenuesAvailablityResponceDTO();
		venueAvailabilityResponseDTO.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		venueAvailabilityResponseDTO.setTime("21:15");
		venueAvailabilityResponseDTO.setType("request");
		venueAvailabilityResponseDTO.setStatus(true);
		venueAvailabilityResponseDTO.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-LUNCH-1554165966.01");
	}

	@Test
	public void venueAvailabilityResponseDTOTest() {
		assertEquals(ACCESS_PERSISTENT_ID, venueAvailabilityResponseDTO.getAccessPersistentId());
		assertEquals(TIME, venueAvailabilityResponseDTO.getTime());
		assertEquals(TYPE, venueAvailabilityResponseDTO.getType());
		assertEquals(STATUS, venueAvailabilityResponseDTO.isStatus());
		assertEquals(SHIFT_PERSISTENT_ID, venueAvailabilityResponseDTO.getShiftPersistentId());
	}
}