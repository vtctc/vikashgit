package com.dh.dxp.restaurant.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.adapter.SevenRoomResources;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.dh.dxp.restaurant.model.ReservationHoldResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ReservationHoldServiceTest {
	@Mock
	SevenRoomResources sevenRoomResources;
	@Mock
	SavenRoomsAdapter roomsAdapter;
	@InjectMocks
	ReservationHoldService reservationHoldService;
	ReservationHoldResponse bookingResponse = new ReservationHoldResponse();
	ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();

	@Test
	public void ReservationHoldTest() throws DHGlobalException {
		final String entityResponse = "{\"status\":200,\"data\":{\"hold_duration_sec\":120,\"access_persistent_id\":\"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218\",\"reservation_hold_id\":\"1560774683.595860\",\"shift_persistent_id\":\"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-DINNER-1554165967.32\"}}";
		Mockito.when(roomsAdapter.createReservationHold(reservationHoldReq))
				.thenReturn(ResponseEntity.ok(entityResponse));
		bookingResponse = new ReservationHoldResponse();
		bookingResponse.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-DINNER-1554165967.32");
		bookingResponse.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		bookingResponse.setHoldDurationSec(120);
		bookingResponse.setReservationHoldId("1560245153.324295");
		reservationHoldService.createReservationHold(reservationHoldReq);
	}

	@Test(expected = DHGlobalException.class)
	public void ReservationHoldTest1() throws DHGlobalException {
		final String entityResponse = "vikash soni";
		final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
		Mockito.when(roomsAdapter.createReservationHold(reservationHoldReq))
				.thenReturn(ResponseEntity.ok(entityResponse));
		reservationHoldService.createReservationHold(reservationHoldReq);
	}

	@Before
	public void setUp() {
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		reservationHoldReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-DINNER-1554165967.32");
		reservationHoldReq.setTime("17:00");
		reservationHoldReq.setVenueId("ALQ_HANAAYA");
	}
}
