package com.dh.dxp.restaurant.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.dh.dxp.restaurant.model.ReservationHoldResponse;
import com.dh.dxp.restaurant.service.ReservationHoldService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CreateReservationHoldTest {
	@Mock
	ReservationHoldService reservationHoldService;
	@InjectMocks
	CreateReservationHold createReservationHold;
	ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();
	ReservationHoldResponse reservationHoldRes = new ReservationHoldResponse();

	@Test
	public void reservationHoldTest() throws DHGlobalException {
		Mockito.when(reservationHoldService.createReservationHold(reservationHoldReq)).thenReturn(reservationHoldRes);
		createReservationHold.reservationHold(reservationHoldReq);
	}

	@Test(expected = DHGlobalException.class)
	public void reservationHoldTest2() throws DHGlobalException {
		Mockito.when(reservationHoldService.createReservationHold(reservationHoldReq)).thenReturn(null);
		createReservationHold.reservationHold(reservationHoldReq);
	}

	@Test(expected = DHGlobalException.class)
	public void reservationHoldTest3() throws DHGlobalException {
		Mockito.when(reservationHoldService.createReservationHold(null)).thenReturn(reservationHoldRes);
		createReservationHold.reservationHold(reservationHoldReq);
	}

	@Before
	public void setUp() {
		reservationHoldReq.setDate("2019-06-11");
		reservationHoldReq.setTime("17:00");
		reservationHoldReq.setPartySize(2);
		reservationHoldReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		reservationHoldReq.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-DINNER-1554165967.32");
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setVenueId("ALQ_HANAAYA");
		reservationHoldRes.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-DINNER-1554165967.32");
		reservationHoldRes.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		reservationHoldRes.setHoldDurationSec(120);
		reservationHoldRes.setReservationHoldId("1560245153.324295");
	}
}
