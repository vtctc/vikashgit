package com.dh.dxp.restaurant.model;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShiftsListModelTest {
	static List<VenuesAvailablityResponceDTO> venuesAvailablityResponceDTOlist = new ArrayList<>();
	static ShiftsListModel shiftsListModel = new ShiftsListModel();

	@Before
	public void setvalues() {
		VenuesAvailablityResponceDTO venueAvailabilityResponseDTO = new VenuesAvailablityResponceDTO();
		venueAvailabilityResponseDTO = new VenuesAvailablityResponceDTO();
		venueAvailabilityResponseDTO.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		venueAvailabilityResponseDTO.setTime("21:15");
		venueAvailabilityResponseDTO.setType("request");
		venueAvailabilityResponseDTO.setStatus(true);
		venueAvailabilityResponseDTO.setShiftPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-LUNCH-1554165966.01");
		venuesAvailablityResponceDTOlist.add(venueAvailabilityResponseDTO);
		shiftsListModel.setVenuesAvailablityResponceDTO(venuesAvailablityResponceDTOlist);
	}

	@Test
	public void testShiftsListModel() {
		Assert.assertEquals(shiftsListModel.getVenuesAvailablityResponceDTO(), venuesAvailablityResponceDTOlist);
	}
}
