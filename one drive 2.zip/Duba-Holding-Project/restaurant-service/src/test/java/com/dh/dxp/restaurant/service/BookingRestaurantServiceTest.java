package com.dh.dxp.restaurant.service;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.adapter.SevenRoomResources;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.BookingResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookingRestaurantServiceTest {
	@Mock
	SevenRoomResources sevenRoomResources;
	@Mock
	SavenRoomsAdapter roomsAdapter;
	@InjectMocks
	BookingRestaurantService bookingRestaurantService;
	BookingRequest bookingReq = new BookingRequest();
	BookingResponse bookingResponse = new BookingResponse();

	@Before
	public void setUp() {
		bookingReq.setVenueId("ALQ_HANAAYA");
		bookingReq.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		bookingReq.setTime("21:15");
		bookingReq.setPartySize(2);
		bookingReq.setFirstName("raman");
		bookingReq.setLastName("KUMAR");
		bookingReq.setEmail("cvx@gmail.com");
		bookingReq.setPhone("9998876546");
		bookingReq.setAccessPersistentId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw-1554167280.24-0.344122585218");
		bookingReq.setCardNumber("32436545653");
		bookingReq.setCardHolderName("acbs");
		bookingReq.setCvcNumber("2334");
		bookingReq.setExpiryDate("22/2");
		bookingReq.setTitle("Mr");
		bookingReq.setNotes("this is special");
		bookingReq.setReservationHoldId("1560245153.324295");
		bookingReq.setAdults(1);
		bookingReq.setChildren(1);
		bookingReq.setInfants(1);
		bookingReq.setCountryCode("+91");
	}

	@Test
	public void createBookingTest() throws JsonProcessingException, IOException, DHGlobalException {

		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservationrequest.json");
		final JsonNode entityResponse = mapper.readTree(file);

		bookingReq.setType("request");
		bookingResponse.setReservationId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yJQsSG25pZ2h0bG9vcF9SZXNlcnZhdGlvbkFjdHVhbBigsZP5BQw");
		bookingResponse.setReservationReferenceCode("33U45SW");
		bookingResponse.setBookingRequestid(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yKQsSHG5pZ2h0bG9vcF9SZXNlcnZhdGlvblJlcXVlc3QYgIDQ09GMpgoM");

		Mockito.when(roomsAdapter.createBookingRequest(bookingReq))
				.thenReturn(new ResponseEntity<>(entityResponse.toString(), HttpStatus.OK));
		bookingRestaurantService.createBooking(bookingReq);
		
	}

	@Test(expected = DHGlobalException.class)
	public void createBookingTest2() throws DHGlobalException {
		bookingReq.setType("request");
		bookingResponse.setReservationId(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yJQsSG25pZ2h0bG9vcF9SZXNlcnZhdGlvbkFjdHVhbBigsZP5BQw");
		bookingResponse.setReservationReferenceCode("33U45SW");
		bookingResponse.setBookingRequestid(
				"ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yKQsSHG5pZ2h0bG9vcF9SZXNlcnZhdGlvblJlcXVlc3QYgIDQ09GMpgoM");
		final String entityResponse = "vikash soni";
		Mockito.when(roomsAdapter.createBookingRequest(bookingReq)).thenReturn(ResponseEntity.ok(entityResponse));
		bookingRestaurantService.createBooking(bookingReq);
		
	}

	@Test
	public void createBookingTest3() throws JsonProcessingException, IOException, DHGlobalException {
		bookingReq.setType("book");
		final ObjectMapper mapper = new ObjectMapper();
		final File file = ResourceUtils.getFile("classpath:mockData/mock_reservation.json");
		final JsonNode entityResponse = mapper.readTree(file);

		Mockito.when(roomsAdapter.createBookingVenue(bookingReq))
				.thenReturn(new ResponseEntity<>(entityResponse.toString(), HttpStatus.OK));
		bookingRestaurantService.createBooking(bookingReq);

	}

	@Test(expected = DHGlobalException.class)
	public void createBookingTest4() throws DHGlobalException {
		bookingReq.setType("book");
		final String entityResponse = "vikash soni";
		Mockito.when(roomsAdapter.createBookingVenue(bookingReq)).thenReturn(ResponseEntity.ok(entityResponse));
		bookingRestaurantService.createBooking(bookingReq);

	}

}