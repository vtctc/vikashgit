package com.dh.dxp.restaurant.model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ReservationHoldRequestTest {
	public static final String EXPECTED_DATE = "2019-06-24";
	public static final String EXPECTED_TIME = "12:00:00";
	public static final int EXPECTED_PARTYSIZE = 1;
	public static final String EXPECTED_ACCESSPERSISTENTID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw";
	public static final String EXPECTED_SHIFTPERSISTENTID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufY";
	public static final Integer EXPECTED_HOLDWAITTIMESEC = 120;
	public static final String EXPECTED_VENUEID = "ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZ";
	final ReservationHoldRequest reservationHoldReq = new ReservationHoldRequest();

	@Before
	public void setUp() throws Exception {
		reservationHoldReq
				.setAccessPersistentId("ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufYCAw");
		reservationHoldReq.setDate("2019-06-24");
		reservationHoldReq.setHoldWaitTimeSec(120);
		reservationHoldReq.setPartySize(1);
		reservationHoldReq
				.setShiftPersistentId("ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZW51ZRiAgNCylufY");
		reservationHoldReq.setTime("12:00:00");
		reservationHoldReq.setVenueId("ahhzfnNldmVucm9vbXMtc2VjdXJlLWRlbW9yHAsSD25pZ2h0bG9vcF9WZ");
	}

	@Test
	public void testResesrvationHoldRequest() {
		Assert.assertEquals(EXPECTED_ACCESSPERSISTENTID, reservationHoldReq.getAccessPersistentId());
		Assert.assertEquals(EXPECTED_DATE, reservationHoldReq.getDate());
		Assert.assertEquals(EXPECTED_SHIFTPERSISTENTID, reservationHoldReq.getShiftPersistentId());
		Assert.assertEquals(EXPECTED_TIME, reservationHoldReq.getTime());
		Assert.assertEquals(EXPECTED_VENUEID, reservationHoldReq.getVenueId());
		Assert.assertEquals(EXPECTED_HOLDWAITTIMESEC, reservationHoldReq.getHoldWaitTimeSec());
		Assert.assertEquals(EXPECTED_PARTYSIZE, reservationHoldReq.getPartySize());
	}
}
