package com.dh.dxp.restaurant.model;

public class Venue {
	private VenueShift venueShift;
	private Address address;
	private String venueName; // Restaurant Name
	private String venueClass; // Restaurant Category

	public Address getAddress() {
		return address;
	}

	public String getVenueClass() {
		return venueClass;
	}

	public String getVenueName() {
		return venueName;
	}

	public VenueShift getVenueShift() {
		return venueShift;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setVenueClass(String venueClass) {
		this.venueClass = venueClass;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}

	public void setVenueShift(VenueShift venueShift) {
		this.venueShift = venueShift;
	}
}
