package com.dh.dxp.restaurant.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class VenuesAvailablityResponceDTO {
	@JsonInclude(Include.ALWAYS)
	private String accessPersistentId;
	private String time;
	private String type;
	private boolean status;
	private String shiftPersistentId;
	private long deposit;
	private boolean requireCreditCard;

	public String getAccessPersistentId() {
		return accessPersistentId;
	}

	public long getDeposit() {
		return deposit;
	}

	public String getShiftPersistentId() {
		return shiftPersistentId;
	}

	public String getTime() {
		return time;
	}

	public String getType() {
		return type;
	}

	public boolean isRequireCreditCard() {
		return requireCreditCard;
	}

	public boolean isStatus() {
		return status;
	}

	public void setAccessPersistentId(String accessPersistentId) {
		this.accessPersistentId = accessPersistentId;
	}

	public void setDeposit(long deposit) {
		this.deposit = deposit;
	}

	public void setRequireCreditCard(boolean requireCreditCard) {
		this.requireCreditCard = requireCreditCard;
	}

	public void setShiftPersistentId(String shiftPersistentId) {
		this.shiftPersistentId = shiftPersistentId;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setType(String type) {
		this.type = type;
	}
}
