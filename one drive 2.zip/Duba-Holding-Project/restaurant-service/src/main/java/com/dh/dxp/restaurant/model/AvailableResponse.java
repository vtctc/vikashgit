package com.dh.dxp.restaurant.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AvailableResponse {
	private boolean isClosed;
	private String restuartntStatus; // Open or Close
	private String shiftCategory;
	private String shiftId;
	private List<ShiftDetails> shiftDetails;

	public String getRestuartntStatus() {
		return restuartntStatus;
	}

	public String getShiftCategory() {
		return shiftCategory;
	}

	public List<ShiftDetails> getShiftDetails() {
		return shiftDetails;
	}

	public String getShiftId() {
		return shiftId;
	}

	@JsonIgnore
	public boolean isClosed() {
		return isClosed;
	}

	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}

	public void setRestuartntStatus(String restuartntStatus) {
		this.restuartntStatus = restuartntStatus;
	}

	public void setShiftCategory(String shiftCategory) {
		this.shiftCategory = shiftCategory;
	}

	public void setShiftDetails(List<ShiftDetails> shiftDetails) {
		this.shiftDetails = shiftDetails;
	}

	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}
}
