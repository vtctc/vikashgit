package com.dh.dxp.restaurant.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.BookingResponse;
import com.dh.dxp.restaurant.service.BookingRestaurantService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("${base.path.sevenrooms}")
@Validated
@Api(value = "About Restaurant Reservation Info", tags = {
"Venue Booking" })
public class CreateReservationController {
	private static final Logger logger = LogManager.getLogger(CreateReservationController.class);
	@Autowired
	private BookingRestaurantService bookingRestaurant;

	@RequestMapping(value = "booking", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = DHGlobalException.class) })
	@ApiOperation(value = "Create Reservation for Venue.", produces = "application/json")
	public ResponseEntity<BookingResponse> bookingVenue(
			@ApiParam(name="BookingRequest",
					  value = "A JSON value representing a booking a venue. An example of the expected schema can be found down here. The fields marked with an * means that they are required."
					 )
			@Valid @RequestBody BookingRequest bookingReq)
			throws DHGlobalException {
		logger.info("venue-booking call initiated");
		final BookingResponse bookingRes = bookingRestaurant.createBooking(bookingReq);
		logger.info("venues-booking call completed");
		if (bookingRes != null) {
			return new ResponseEntity<>(bookingRes, HttpStatus.OK);
		} else {
			logger.error("Failed to create reservation");
			throw new DHGlobalException("Failed to create reservation");
		}
	}
}
