package com.dh.dxp.restaurant.model;

public class VenueShift {
	private String starDate;
	private String enddate;
	private String shiftCategory;
	private String shiftName;
	private String shiftStartTime;
	private String shiftEndTime;

	public String getEnddate() {
		return enddate;
	}

	public String getShiftCategory() {
		return shiftCategory;
	}

	public String getShiftEndTime() {
		return shiftEndTime;
	}

	public String getShiftName() {
		return shiftName;
	}

	public String getShiftStartTime() {
		return shiftStartTime;
	}

	public String getStarDate() {
		return starDate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public void setShiftCategory(String shiftCategory) {
		this.shiftCategory = shiftCategory;
	}

	public void setShiftEndTime(String shiftEndTime) {
		this.shiftEndTime = shiftEndTime;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public void setShiftStartTime(String shiftStartTime) {
		this.shiftStartTime = shiftStartTime;
	}

	public void setStarDate(String starDate) {
		this.starDate = starDate;
	}
}
