package com.dh.dxp.restaurant.config;

public class DHConstantUtils {
	public static final String CONTENT_TYPE = "application/x-ww-form-urlencoded";
	public static final String RESPONSE_HEADER = "response_token";
	public static final String MDC_TOKEN_KEY = "request-Id";
	public static final String REQUEST_HEADER = "request-Header";
	public static final String MESSAGE_SEVENROOM_API_AUTH_TOKEN = "Getting the sevenrooms Api auth token";
	public static final String ERROR_INVALID_AUTHORIZATION = "No valid Authorization token provided";
	public static final String DATE_FORMATE_ERROR = "Date should be in ISO 8601 format i.e. yyyy-MM-dd";
	public static final String CANNOT_SUBMIT_REQUEST_FOR_PAST_DATES_ERROR = "Cannot submit requests for past dates";
	public static final String AUTH_TOKEN_FROM_SEVEN_ROMM_API = "Failed to get auth token from sevenrooms api";
	public static final String PARTY_SIZE = "party_size";
	public static final String ACCESS_TOKEN_EXPIRED = "The access token expired";
	public static final String FAILED_TO_PROCESS_THE_REQUEST = "Failed to process the request";
	public static final String DATE_FORMATTER = "yyyy-MM-dd";
	public static final String SEVENROOMS_SERVER_HANDLING_REQUESTERROR = "Something went wrong on the SevenRooms server handling the request";
	public static final String NOTES = "notes";

	private DHConstantUtils() {
	}
}
