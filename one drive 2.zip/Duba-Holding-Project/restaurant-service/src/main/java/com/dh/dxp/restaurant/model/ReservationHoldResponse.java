package com.dh.dxp.restaurant.model;

public class ReservationHoldResponse {
	private String shiftPersistentId;
	private String accessPersistentId;
	private int holdDurationSec;
	private String reservationHoldId;

	public String getAccessPersistentId() {
		return accessPersistentId;
	}

	public int getHoldDurationSec() {
		return holdDurationSec;
	}

	public String getReservationHoldId() {
		return reservationHoldId;
	}

	public String getShiftPersistentId() {
		return shiftPersistentId;
	}

	public void setAccessPersistentId(String accessPersistentId) {
		this.accessPersistentId = accessPersistentId;
	}

	public void setHoldDurationSec(int holdDurationSec) {
		this.holdDurationSec = holdDurationSec;
	}

	public void setReservationHoldId(String reservationHoldId) {
		this.reservationHoldId = reservationHoldId;
	}

	public void setShiftPersistentId(String shiftPersistentId) {
		this.shiftPersistentId = shiftPersistentId;
	}
}
