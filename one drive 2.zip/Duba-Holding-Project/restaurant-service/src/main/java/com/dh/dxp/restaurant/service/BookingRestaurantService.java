package com.dh.dxp.restaurant.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.controller.CreateReservationController;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.BookingResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class BookingRestaurantService {
	private static final Logger logger = LogManager.getLogger(CreateReservationController.class);
	@Autowired
	private SavenRoomsAdapter roomsAdapter;

	public BookingResponse createBooking(BookingRequest bookingReq) throws DHGlobalException {
		final ObjectMapper jsonObjectMapper = new ObjectMapper();
		ResponseEntity<String> entity = null;
		BookingResponse bookingResponse = null;
		logger.info("booking request type :{} ", bookingReq.getType());
		if (bookingReq.getType().equals("request")) {
			logger.info("Inside request");
			entity = roomsAdapter.createBookingRequest(bookingReq);
			if (entity != null) {
				bookingResponse = new BookingResponse();
				JsonNode rootNode;
				try {
					rootNode = jsonObjectMapper.readTree(entity.getBody());
				} catch (final IOException e) {
					logger.error("Error Reading JSON Response in Class : {}", this.getClass());
					throw new DHGlobalException("Error Reading JSON Response in Class : " + this.getClass());
				}
				final JsonNode jsonRootNode = rootNode.path("data");
				bookingResponse.setBookingRequestid(jsonRootNode.get("request_id").asText());
			}
		} else {
			logger.info("Inside booking");
			entity = roomsAdapter.createBookingVenue(bookingReq);
			if (entity != null) {
				bookingResponse = new BookingResponse();
				JsonNode rootNode;
				try {
					rootNode = jsonObjectMapper.readTree(entity.getBody());
				} catch (final IOException e) {
					logger.error("Error Reading JSON Response in Class : {}", this.getClass());
					throw new DHGlobalException("Error Reading JSON Response in Class : " + this.getClass());
				}
				final JsonNode jsonRootNode = rootNode.path("data");
				bookingResponse.setReservationId(jsonRootNode.get("reservation_id").asText());
				bookingResponse.setReservationReferenceCode(jsonRootNode.get("reservation_reference_code").asText());
			}
		}
		return bookingResponse;
	}
}
