package com.dh.dxp.restaurant.model;

public class ShiftDetails {
	private String time;
	private String type;
	private String accessPersistentId;

	public String getAccessPersistentId() {
		return accessPersistentId;
	}

	public String getTime() {
		return time;
	}

	public String getType() {
		return type;
	}

	public void setAccessPersistentId(String accessPersistentId) {
		this.accessPersistentId = accessPersistentId;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setType(String type) {
		this.type = type;
	}
}
