package com.dh.dxp.restaurant.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dh.dxp.component.exceptions.DHGlobalException;

public class DateUtils {
	private static final Logger logger = LogManager.getLogger(DateUtils.class);

	public static LocalTime formatCommon(String timeIOS) throws DHGlobalException, ParseException {
		final String pattern = "yyyy-MM-dd HH:mm:ss";
		LocalTime localTime = null;
		try {
			final SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			final Date d = sdf.parse(timeIOS);
			new SimpleDateFormat("yyyy-MM-dd");
			final DateFormat time = new SimpleDateFormat("HH:mm:ss");
			localTime = LocalTime.parse(time.format(d));
		} catch (final DateTimeParseException e) {
			logger.error("Date should be in ISO 8601 format i.e. yyyy-MM-dd");
			throw new DHGlobalException("Date should be in ISO 8601 format i.e. yyyy-MM-dd");
		}
		return localTime;
	}

	private DateUtils() {
	}
}
