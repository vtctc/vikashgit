package com.dh.dxp.restaurant.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModelProperty;

public class BookingRequest {
	@NotEmpty(message = "{validation.venueId.notEmpty}")
	private String venueId;
	@NotEmpty(message = "{validation.date.notEmpty}")
	private String date;
	@NotEmpty(message = "{validation.time.notEmpty}")
	private String time;
	@Min(value = 1, message = "{validation.partySize.min}")
	private int partySize;
	@NotEmpty(message = "{validation.firstName.notEmpty}")
	private String firstName;
	@NotEmpty(message = "{validation.lastName.notEmpty}")
	private String lastName;
	@NotEmpty(message = "{validation.countryCode.notEmpty}")
	private String countryCode;
	@NotEmpty(message = "{validation.phone.notEmpty}")
	private String phone;
	private String accessPersistentId;
	private String cardNumber;
	private String cvcNumber;
	private String title;
	private String type;
	@ApiModelProperty(required = false)
	private String reservationHoldId;
	@Pattern(regexp = ".+@.+\\.[a-z]+")
	@NotEmpty(message = "{validation.email.notEmpty}")
	private String email;
	@ApiModelProperty(required = false)
	private String notes;
	@ApiModelProperty(required = false)
	private String cardHolderName;
	@ApiModelProperty(required = false)
	private String expiryDate;
	private Integer adults;
	private Integer children;
	private Integer infants;

	public String getAccessPersistentId() {
		return accessPersistentId;
	}

	public Integer getAdults() {
		return adults;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public Integer getChildren() {
		return children;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public String getCvcNumber() {
		return cvcNumber;
	}

	public String getDate() {
		return date;
	}

	public String getEmail() {
		return email;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public Integer getInfants() {
		return infants;
	}

	public String getLastName() {
		return lastName;
	}

	public String getNotes() {
		return notes;
	}

	public int getPartySize() {
		return partySize;
	}

	public String getPhone() {
		return phone;
	}

	public String getReservationHoldId() {
		return reservationHoldId;
	}

	public String getTime() {
		return time;
	}

	public String getTitle() {
		return title;
	}

	public String getType() {
		return type;
	}

	public String getVenueId() {
		return venueId;
	}

	public void setAccessPersistentId(String accessPersistentId) {
		this.accessPersistentId = accessPersistentId;
	}

	public void setAdults(Integer adults) {
		this.adults = adults;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public void setChildren(Integer children) {
		this.children = children;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setCvcNumber(String cvcNumber) {
		this.cvcNumber = cvcNumber;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setInfants(Integer infants) {
		this.infants = infants;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public void setPartySize(int partySize) {
		this.partySize = partySize;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setReservationHoldId(String reservationHoldId) {
		this.reservationHoldId = reservationHoldId;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setVenueId(String venueId) {
		this.venueId = venueId;
	}
}
