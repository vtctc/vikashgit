package com.dh.dxp.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableResourceServer
@ComponentScan("com.dh.dxp")
@EnableCaching
public class DHRestaurantsApplication {
	public static void main(String[] args) {
		SpringApplication.run(DHRestaurantsApplication.class, args);
	}
}
