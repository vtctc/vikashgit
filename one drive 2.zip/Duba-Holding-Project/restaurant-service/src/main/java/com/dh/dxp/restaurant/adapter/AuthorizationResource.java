package com.dh.dxp.restaurant.adapter;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.config.RestTemplateConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Service
public class AuthorizationResource {
	private static final Logger logger = LoggerFactory.getLogger(AuthorizationResource.class);
	@Autowired
	RestTemplateConfig restTemplateConfig;
	@Value("#{'${api.auth.url}'}")
	private String authResourceURL;
	@Value("#{'${api.auth.clientId}'}")
	String sevenRoomsClientId;
	@Value("#{'${api.auth.clientSecret}'}")
	String sevenRoomsClientSecret;

	@Scheduled(fixedRate = 24 * 60 * 60 * 1000)
	@CacheEvict(value = "token", allEntries = true)
	public void evictAllCacheValues() {
		final SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		final String date = formatter.format(new Date());
		logger.info("Token deleted :{}", date);
	}

	// Tried with configuration property, But facing problem as Only spring version
	// above Spring 3.2.2 support
	// to use configuration property in (@Scheduled) annotation
	@Cacheable(value = "token", unless = "#result == null")
	public String getNewApiToken() throws DHGlobalException {
		logger.info("authorization-resource inside getnewauthtoken");

		final ObjectMapper jsonObjectMapper = new ObjectMapper();

		// setting up the request headers
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		// Create the request body as a MultiValueMap
		final MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
		body.add("client_id", sevenRoomsClientId);
		body.add("client_secret", sevenRoomsClientSecret);
		final HttpEntity<?> httpEntity = new HttpEntity<>(body, requestHeaders);
		ResponseEntity<String> entity = null;
		String token = null;
		try {
			entity = restTemplateConfig.getRestTemplate().exchange(authResourceURL, HttpMethod.POST, httpEntity,
					String.class);
		} catch (final ResourceAccessException ex) {
			logger.error("error", ex.getMessage());
			throw new DHGlobalException("Failed to connect seven Rooms API");
		}
		if (entity.getStatusCodeValue() == 200)
			try {
				final JsonNode node = jsonObjectMapper.readTree(entity.getBody());
				token = node.path("data").path("token").textValue();
			} catch (final Exception ioException) {
				logger.info("Failed to get token :{}", ioException.getMessage());
				return token;
			}
		return token;
	}
}
