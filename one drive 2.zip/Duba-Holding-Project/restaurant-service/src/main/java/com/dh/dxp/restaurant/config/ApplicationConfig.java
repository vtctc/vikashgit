package com.dh.dxp.restaurant.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class ApplicationConfig implements WebMvcConfigurer {
	private static final Logger logger = LogManager.getLogger(ApplicationConfig.class);

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		logger.info("******Cross Origin*****");
		registry.addMapping("/**").allowedOrigins("*").allowedMethods("POST", "GET", "PUT", "OPTIONS", "DELETE");
	}

	@Bean
	public ObjectMapper buildObjectMapper() {
		return new ObjectMapper().setSerializationInclusion(Include.NON_NULL);
	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	@Bean
	public FilterRegistrationBean<MdcLogEnhancerFilter> servletRegistrationBean() {
		final FilterRegistrationBean<MdcLogEnhancerFilter> registrationBean = new FilterRegistrationBean<>();
		final MdcLogEnhancerFilter log4jMDCFilterFilter = new MdcLogEnhancerFilter(DHConstantUtils.RESPONSE_HEADER,
				DHConstantUtils.MDC_TOKEN_KEY, DHConstantUtils.REQUEST_HEADER);
		registrationBean.setFilter(log4jMDCFilterFilter);
		registrationBean.setOrder(2);
		return registrationBean;
	}
}
