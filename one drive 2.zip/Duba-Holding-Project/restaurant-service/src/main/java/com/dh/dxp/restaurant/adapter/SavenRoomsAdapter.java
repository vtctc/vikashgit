package com.dh.dxp.restaurant.adapter;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.util.UriComponentsBuilder;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.component.service.impl.HotelRestaurantMappingServiceImpl;
import com.dh.dxp.restaurant.config.DHConstantUtils;
import com.dh.dxp.restaurant.model.BookingRequest;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class SavenRoomsAdapter {
	private static final Logger logger = LogManager.getLogger(SavenRoomsAdapter.class);
	@Autowired
	private SevenRoomResources sevenRoomResources;
	@Autowired
	private AuthorizationResource authorizationResource;
	@Value("#{'${api.base.url}'}")
	private String baseUrl;
	@Value("#{'${api.charge.url}'}")
	private String chargeBaseUrl;
	@Value("#{'${hold_wait_time_sec}'}")
	private int holdWaitTimeSec;
	@Value("#{'${api.reservation.base.charge}'}")
	private int baseChargeAmount;
	@Autowired
	private HotelRestaurantMappingServiceImpl mappingsService;

	// Booking Request
	public ResponseEntity<String> createBookingRequest(BookingRequest request) throws DHGlobalException {
		forDateFormatValidate(request);
		final String sevenRoomsVenueId = mappingsService.findBookingSystemId(request.getVenueId());
		logger.info("sevenrooms venue Id from DB :{}", sevenRoomsVenueId);
		final String url = baseUrl + sevenRoomsVenueId + "/request";
		final String authToken = authorizationResource.getNewApiToken();
		// setting up the request headers
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", request.getDate());
		body.add("first_name", request.getFirstName());
		body.add("last_name", request.getLastName());
		body.add(DHConstantUtils.PARTY_SIZE, request.getPartySize());
		body.add("phone", request.getCountryCode().concat(request.getPhone()));
		body.add("time", request.getTime());
		body.add("email", request.getEmail());
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", request.getAdults());
		informationAboutGuest.put("children", request.getChildren());
		informationAboutGuest.put("infants", request.getInfants());
		final StringBuilder bookingReqNotes = new StringBuilder();
		if ((request.getNotes() != null) && !request.getNotes().isEmpty()) {
			bookingReqNotes.append(request.getNotes());
			bookingReqNotes.append("\n");
		}
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);
		body.add("notes", bookingReqNotes);
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		logger.info("Request for sevenrooms createbookingrequest-api for type request ", requestEntity);
		ResponseEntity<String> sevenRoomsApiResponse = null;
		try {
			final Long startTime = System.currentTimeMillis();
			logger.info("sevenrooms  createreservationrequest-api call intiated startTime:{}", startTime);
			sevenRoomsApiResponse = sevenRoomResources.getPutService(url, requestEntity);
			logger.info("url for create reservation request:{}", url);
			final Long endTime = System.currentTimeMillis();
			logger.info("sevenrooms  createreservationrequest-api call completed in(millisecond):{}",
					endTime - startTime);
		} catch (final HttpClientErrorException ex) {
			if (ex.getStatusCode() == HttpStatus.UNAUTHORIZED) {
				logger.error(DHConstantUtils.ACCESS_TOKEN_EXPIRED);
				throw new DHGlobalException(DHConstantUtils.ACCESS_TOKEN_EXPIRED);
			} else if (ex.getStatusCode() == HttpStatus.FORBIDDEN) {
				logger.error("Failed to process the request :{} ", ex.getResponseBodyAsString());
				throw new DHGlobalException(
						DHConstantUtils.FAILED_TO_PROCESS_THE_REQUEST + ex.getResponseBodyAsString());
			} else {
				logger.error(ex.getCause() + " " + ex.getResponseBodyAsString());
				throw new DHGlobalException(ex.getCause() + " " + ex.getResponseBodyAsString());
			}
		}
		return sevenRoomsApiResponse;
	}

	// For Reservation
	public ResponseEntity<String> createBookingVenue(BookingRequest bookingReq) throws DHGlobalException {
		logger.info("SavenRoomsAdapter Inside the createBookingVenue");
		/* Converting string type date to Localdate format YYYY-MM-DD */
		forDateFormatValidate(bookingReq);
		final String sevenRoomsVenueId = mappingsService.findBookingSystemId(bookingReq.getVenueId());
		logger.info("sevenrooms venue Id from DB :{}", sevenRoomsVenueId);
		final String bookingUrl = baseUrl + sevenRoomsVenueId + "/book";
		final String authToken = authorizationResource.getNewApiToken();
		// setting up the request headers
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("access_persistent_id", bookingReq.getAccessPersistentId());
		body.add("date", bookingReq.getDate());
		body.add("first_name", bookingReq.getFirstName());
		body.add("last_name", bookingReq.getLastName());
		body.add(DHConstantUtils.PARTY_SIZE, bookingReq.getPartySize());
		body.add("phone", bookingReq.getCountryCode().concat(bookingReq.getPhone()));
		body.add("time", bookingReq.getTime());
		body.add("email", bookingReq.getEmail());
		body.add("salutation", bookingReq.getTitle());
		final Map<String, Integer> informationAboutGuest = new HashMap<>();
		informationAboutGuest.put("adults", bookingReq.getAdults());
		informationAboutGuest.put("children", bookingReq.getChildren());
		informationAboutGuest.put("infants", bookingReq.getInfants());
		final StringBuilder bookingReqNotes = new StringBuilder();
		if ((bookingReq.getNotes() != null) && !bookingReq.getNotes().isEmpty()) {
			bookingReqNotes.append(bookingReq.getNotes());
			bookingReqNotes.append("\n");
		}
		bookingReqNotes.append("GuestDetails:").append(informationAboutGuest);
		body.add("notes", bookingReqNotes);

		if (!StringUtils.isEmpty(bookingReq.getReservationHoldId())) {
			body.add("reservation_hold_id", bookingReq.getReservationHoldId());
		}
		// request entity is created with request body and headers
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		ResponseEntity<String> sevenRoomsApiResponse = null;
		final Long startTime = System.currentTimeMillis();
		logger.info("Request for sevenrooms createreservationrequest-api type book ", requestEntity);
		try {
			logger.info("sevenrooms createreservationrequest-api call initiated startTime:{}", startTime);
			sevenRoomsApiResponse = sevenRoomResources.getPutService(bookingUrl, requestEntity);
			logger.info("url for create reservation for book type url is :{}", bookingUrl);
			final Long endtime = System.currentTimeMillis();
			logger.info("sevenrooms createreservationrequest-api completed in(millisecond):{}", startTime - endtime);
		} catch (final HttpClientErrorException ex) {
			logger.error(ex.getStatusCode());
			errorHandlingForResponse(ex);
		} catch (final ResourceAccessException ex) {
			logger.error("error", ex.getMessage());
			throw new DHGlobalException("Failed to connect seven Rooms API");
		}
		if ((sevenRoomsApiResponse != null) && (sevenRoomsApiResponse.getStatusCodeValue() == 200)) {
			final ObjectMapper jsonObjectMapper = new ObjectMapper();
			JsonNode rootNode = null;
			try {
				rootNode = jsonObjectMapper.readTree(sevenRoomsApiResponse.getBody());
			} catch (final IOException e) {
				logger.error("Error while reading response from SevenRoom API");
				throw new DHGlobalException("Error while reading response from SevenRoom API");
			}
			final JsonNode jsonRootNode = rootNode.path("data");
			final String reservationReferenceCode = jsonRootNode.get("reservation_reference_code").textValue();
			final String reservationId = jsonRootNode.get("reservation_id").textValue();
			final boolean createChargeAPIResponse = createCharge(bookingReq, authToken, reservationId,
					reservationReferenceCode);
			if (createChargeAPIResponse) {
				return sevenRoomsApiResponse;
			} else {
				logger.error("Transaction got failed");
				throw new DHGlobalException("Transaction got failed");
			}
		}
		return sevenRoomsApiResponse;
	}

	public boolean createCharge(BookingRequest reservationRequest, String authToken, String reservationId,
			String reservationCode) throws DHGlobalException {
		final String chargeUrl = chargeBaseUrl + reservationId + "/add_charge";
		// setting up the request headers
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("card_id", reservationRequest.getCardHolderName());
		body.add("card_last4", reservationRequest.getCvcNumber());
		body.add("subtotal", baseChargeAmount * reservationRequest.getPartySize());
		body.set("transaction_id", reservationCode.concat("_").concat(String.valueOf(System.currentTimeMillis())));
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		ResponseEntity<String> sevenRoomsApiResponse = null;
		logger.info("request for sevenrooms createcharge-api :{}", requestEntity.getBody());
		try {
			sevenRoomsApiResponse = sevenRoomResources.getPostService(chargeUrl, requestEntity);
		} catch (final ResourceAccessException ex) {
			logger.error("message:{}", ex.getLocalizedMessage());
			throw new DHGlobalException(ex.getLocalizedMessage());
		}
		return sevenRoomsApiResponse.getStatusCode().equals(HttpStatus.OK);
	}

	public ResponseEntity<String> createReservationHold(ReservationHoldRequest request) throws DHGlobalException {
		// validate request parameter
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DHConstantUtils.DATE_FORMATTER);
		final LocalDate date = LocalDate.parse(request.getDate(), dateFormatter);
		if (date.isBefore(LocalDate.now())) {
			logger.error(DHConstantUtils.CANNOT_SUBMIT_REQUEST_FOR_PAST_DATES_ERROR);
			throw new DHGlobalException(DHConstantUtils.CANNOT_SUBMIT_REQUEST_FOR_PAST_DATES_ERROR);
		}
		final String authToken = authorizationResource.getNewApiToken();
		final String sevenRoomsVenueId = mappingsService.findBookingSystemId(request.getVenueId());
		logger.info("sevenrooms venue id from DB :{}", sevenRoomsVenueId);
		// reservation-hold url
		final String url = baseUrl + sevenRoomsVenueId + "/hold";
		// setting up the request headers
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("date", request.getDate());
		body.add("time", request.getTime());
		body.add(DHConstantUtils.PARTY_SIZE, request.getPartySize());
		body.add("access_persistent_id", request.getAccessPersistentId());
		body.add("shift_persistent_id", request.getShiftPersistentId());
		if ((request.getHoldWaitTimeSec() != null) && (request.getHoldWaitTimeSec() > 0)) {
			body.add("hold_wait_time_sec", request.getHoldWaitTimeSec());
		} else {
			body.add("hold_wait_time_sec", holdWaitTimeSec);
		}
		final HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, requestHeaders);
		ResponseEntity<String> sevenRoomsApiResponse = null;
		logger.info("sevenrooms createreservationhold-api requestentity:{}", requestEntity.getBody());
		try {
			final Long startTime = System.currentTimeMillis();
			logger.info("sevenrooms createreservationhold-api call intiated startTime:{}", startTime);
			sevenRoomsApiResponse = sevenRoomResources.getPutService(url, requestEntity);
			logger.info("url for createreservationhold-api request:{}", url);
			final Long endTime = System.currentTimeMillis();
			logger.info("sevenrooms createreservationhold-api call completed in (millisecond):{}", endTime - startTime);
		} catch (final HttpClientErrorException ex) {
			logger.error("message:{} response:{}", ex.getLocalizedMessage(), ex.getResponseBodyAsString());
			throw new DHGlobalException(ex.getLocalizedMessage() + " " + ex.getResponseBodyAsString());
		} catch (final HttpServerErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
				logger.error("There was a problem completing the reservation hold");
				throw new DHGlobalException("There was a problem completing the reservation hold");
			}
		}
		return sevenRoomsApiResponse;
	}

	private void errorHandlingForResponse(final HttpClientErrorException ex) throws DHGlobalException {
		if (ex.getStatusCode() == HttpStatus.CONFLICT) {
			logger.error("A reservation for this client already exists on this shift");
			throw new DHGlobalException("A reservation for this client already exists on this shift");
		} else if (ex.getStatusCode() == HttpStatus.UNAUTHORIZED) {
			logger.error("The access token expired");
			throw new DHGlobalException("The access token expired");
		} else if (ex.getStatusCode() == HttpStatus.FORBIDDEN) {
			logger.error("Failed to process the request " + ex.getResponseBodyAsString());
			throw new DHGlobalException("Failed to process the request " + ex.getResponseBodyAsString());
		} else {
			logger.error("exception cause:{} exception response :{}", ex.getCause(), ex.getResponseBodyAsString());
			throw new DHGlobalException(ex.getCause() + " " + ex.getResponseBodyAsString());
		}
	}

	private void forDateFormatValidate(BookingRequest bookingReq) throws DHGlobalException {
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DHConstantUtils.DATE_FORMATTER);
		LocalDate bookingDateFormate = null;
		try {
			bookingDateFormate = LocalDate.parse(bookingReq.getDate(), dateFormatter);
		} catch (final DateTimeParseException ex) {
			logger.error(DHConstantUtils.DATE_FORMATE_ERROR);
			throw new DHGlobalException(DHConstantUtils.DATE_FORMATE_ERROR);
		}
		// Request validation
		if (bookingDateFormate.isBefore(LocalDate.now())) {
			logger.error(DHConstantUtils.CANNOT_SUBMIT_REQUEST_FOR_PAST_DATES_ERROR);
			throw new DHGlobalException(DHConstantUtils.CANNOT_SUBMIT_REQUEST_FOR_PAST_DATES_ERROR);
		}
	}

	public ResponseEntity<String> getShiftDetails(String venueId, LocalDate date) throws DHGlobalException {
		final String sevenRoomVenueId = mappingsService.findBookingSystemId(venueId);
		logger.info("sevenRoom VenueId:{}", sevenRoomVenueId);
		logger.info(DHConstantUtils.MESSAGE_SEVENROOM_API_AUTH_TOKEN);
		final String authToken = authorizationResource.getNewApiToken();
		final String URL = baseUrl + sevenRoomVenueId + "/shifts";
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(URL).queryParam("end_date", date)
				.queryParam("start_date", date);
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		// request entity is created with request body and headers
		final HttpEntity<String> requestEntity = new HttpEntity<>(requestHeaders);
		final Long startTime = System.currentTimeMillis();
		logger.info("Request for sevenrooms shift-API {}", requestEntity);
		logger.info("sevenrooms shift-API call startTime:{}", startTime);
		final ResponseEntity<String> venueEntity = sevenRoomResources.getGetServiceWithURIBuilder(builder,
				requestEntity);
		logger.info("url for getshiftdetails:{}", builder.build().encode().toUri());
		final Long endTime = System.currentTimeMillis();
		logger.info("sevenrooms shift-API call completed in (millisecond):{}", endTime - startTime);
		if (venueEntity.getStatusCode() == HttpStatus.UNAUTHORIZED) {
			logger.error(DHConstantUtils.ERROR_INVALID_AUTHORIZATION);
			throw new DHGlobalException(DHConstantUtils.ERROR_INVALID_AUTHORIZATION);
		} else if (venueEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			logger.error(DHConstantUtils.SEVENROOMS_SERVER_HANDLING_REQUESTERROR);
			throw new DHGlobalException(DHConstantUtils.SEVENROOMS_SERVER_HANDLING_REQUESTERROR);
		}
		return venueEntity;
	}

	public ResponseEntity<String> getVenueAvailability(String venueId, Integer partySize, LocalDate date,
			String startTime, String endTime) throws DHGlobalException {
		final String sevenRoomVenueId = mappingsService.findBookingSystemId(venueId);
		logger.info("sevenRoomVenueId :{}", sevenRoomVenueId);
		logger.info("Getting the sevenrooms Api auth token");
		final String authToken = authorizationResource.getNewApiToken();
		if (authToken == null) {
			logger.error("Failed to get auth token from sevenrooms api");
			throw new DHGlobalException("Failed to get auth token from sevenrooms api");
		}
		final String URL = baseUrl + sevenRoomVenueId + "/availability";
		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(URL).queryParam("date", date)
				.queryParam("end_time", endTime).queryParam(DHConstantUtils.PARTY_SIZE, partySize)
				.queryParam("start_time", startTime);
		final HttpHeaders requestHeaders = sevenRoomResources.requesteHeaderValidator(authToken);
		// request entity is created with request body and headers
		final HttpEntity<String> requestEntity = new HttpEntity<>(requestHeaders);
		final Long starttime = System.currentTimeMillis();
		logger.info("sevenrooms venue-availability call startTime:{}", starttime);
		final ResponseEntity<String> venueEntity = sevenRoomResources.getGetServiceWithURIBuilder(builder,
				requestEntity);
		logger.info("url for venue-availability :{}", builder.build().encode().toUri());
		final Long endtime = System.currentTimeMillis();
		logger.info("sevenrooms venue-availability completed in(millisecond):{}", endtime - starttime);
		if (venueEntity.getStatusCode() == HttpStatus.UNAUTHORIZED) {
			logger.error(DHConstantUtils.ERROR_INVALID_AUTHORIZATION);
			throw new DHGlobalException(DHConstantUtils.ERROR_INVALID_AUTHORIZATION);
		} else if (venueEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			logger.error(DHConstantUtils.SEVENROOMS_SERVER_HANDLING_REQUESTERROR);
			throw new DHGlobalException(DHConstantUtils.SEVENROOMS_SERVER_HANDLING_REQUESTERROR);
		}
		return venueEntity;
	}
}
