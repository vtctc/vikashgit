package com.dh.dxp.restaurant.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class ReservationHoldRequest {
	@NotEmpty(message = "{validation.date.notEmpty}")
	private String date;
	@NotEmpty(message = "{validation.time.notEmpty}")
	private String time;
	@Min(value = 1, message = "{validation.partySize.min}")
	private int partySize;
	@NotEmpty(message = "{validation.accessPersistentId.notEmpty}")
	private String accessPersistentId;
	@NotEmpty(message = "{validation.shiftPersistentId.notEmpty}")
	private String shiftPersistentId;
	private Integer holdWaitTimeSec;
	@NotEmpty(message = "{validation.venueId.notEmpty}")
	private String venueId;

	public String getAccessPersistentId() {
		return accessPersistentId;
	}

	public String getDate() {
		return date;
	}

	public Integer getHoldWaitTimeSec() {
		return holdWaitTimeSec;
	}

	public int getPartySize() {
		return partySize;
	}

	public String getShiftPersistentId() {
		return shiftPersistentId;
	}

	public String getTime() {
		return time;
	}

	public String getVenueId() {
		return venueId;
	}

	public void setAccessPersistentId(String accessPersistentId) {
		this.accessPersistentId = accessPersistentId;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setHoldWaitTimeSec(Integer holdWaitTimeSec) {
		this.holdWaitTimeSec = holdWaitTimeSec;
	}

	public void setPartySize(int partySize) {
		this.partySize = partySize;
	}

	public void setShiftPersistentId(String shiftPersistentId) {
		this.shiftPersistentId = shiftPersistentId;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public void setVenueId(String venueId) {
		this.venueId = venueId;
	}
}
