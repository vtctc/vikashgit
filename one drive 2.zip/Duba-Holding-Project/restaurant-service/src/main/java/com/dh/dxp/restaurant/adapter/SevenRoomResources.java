package com.dh.dxp.restaurant.adapter;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.config.RestTemplateConfig;

@Component
public class SevenRoomResources {
	@Autowired
	private RestTemplateConfig restTemplateConfig;

	public ResponseEntity<String> getGetServiceWithURIBuilder(UriComponentsBuilder builder,
			HttpEntity<String> requestEntity) throws DHGlobalException {
		return restTemplateConfig.getRestTemplate().exchange(builder.build().encode().toUri(), HttpMethod.GET,
				requestEntity, String.class);
	}

	public ResponseEntity<String> getPostService(String url, HttpEntity<MultiValueMap<String, Object>> requestEntity)
			throws DHGlobalException {
		return restTemplateConfig.getRestTemplate().exchange(url, HttpMethod.POST, requestEntity, String.class);
	}

	public ResponseEntity<String> getPutService(String url, HttpEntity<MultiValueMap<String, Object>> requestEntity)
			throws DHGlobalException {
		return restTemplateConfig.getRestTemplate().exchange(url, HttpMethod.PUT, requestEntity, String.class);
	}

	// Default Header Constructed
	public HttpHeaders requesteHeaderValidator(String authToken) {
		// setting up the request headers
		final HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_FORM_URLENCODED));
		requestHeaders.add("Authorization", authToken);
		return requestHeaders;
	}
}