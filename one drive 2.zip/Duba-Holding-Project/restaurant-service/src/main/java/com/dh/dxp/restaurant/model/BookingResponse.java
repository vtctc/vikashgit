package com.dh.dxp.restaurant.model;

public class BookingResponse {
	private String reservationReferenceCode;
	private String reservationId;
	private String bookingRequestid;

	public String getBookingRequestid() {
		return bookingRequestid;
	}

	public String getReservationId() {
		return reservationId;
	}

	public String getReservationReferenceCode() {
		return reservationReferenceCode;
	}

	public void setBookingRequestid(String bookingRequestid) {
		this.bookingRequestid = bookingRequestid;
	}

	public void setReservationId(String reservationId) {
		this.reservationId = reservationId;
	}

	public void setReservationReferenceCode(String reservationReferenceCode) {
		this.reservationReferenceCode = reservationReferenceCode;
	}
}
