package com.dh.dxp.restaurant.config;

import java.net.ProxySelector;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.routing.HttpRoutePlanner;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.SystemDefaultRoutePlanner;
import org.apache.http.ssl.TrustStrategy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dh.dxp.component.exceptions.DHGlobalException;

@Service
public class RestTemplateConfig {

	private static final Logger logger = LogManager.getLogger(RestTemplateConfig.class);

	@Autowired
	private Environment environment;

	public RestTemplate getRestTemplate() throws DHGlobalException {

		if (Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> env.equalsIgnoreCase("local"))) {
			System.setProperty("http.proxyHost", "172.22.218.218");
			System.setProperty("http.proxyPort", "8085");
			System.setProperty("https.proxyHost", "172.22.218.218");
			System.setProperty("https.proxyPort", "8085");
		}
		if (Arrays.stream(environment.getActiveProfiles())
				.anyMatch(env -> (env.equalsIgnoreCase("local") || env.equalsIgnoreCase("dev"))))
			try {

				final TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

				final SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
						.loadTrustMaterial(null, acceptingTrustStrategy).build();

				final SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
				final HttpRoutePlanner routePlanner = new SystemDefaultRoutePlanner(ProxySelector.getDefault());
				final CloseableHttpClient httpClient = HttpClientBuilder.create().setRoutePlanner(routePlanner)
						.setSSLSocketFactory(csf).build();

				final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
				requestFactory.setConnectionRequestTimeout(0);
				requestFactory.setHttpClient(httpClient);
				final RestTemplate restTemplate = new RestTemplate(requestFactory);
				restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(httpClient));
				logger.info("SSL verify disabled.");
				return restTemplate;
			} catch (final Exception e) {
				logger.error("Failed to create Rest template");
				throw new DHGlobalException(
						"An error Occurred in creating the Rest template Error in creating Rest template");
			}
		return new RestTemplate();

	}

}
