package com.dh.dxp.restaurant.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.dh.dxp.restaurant.model.ReservationHoldResponse;
import com.dh.dxp.restaurant.service.ReservationHoldService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("${base.path.sevenrooms}")
@Validated
@Api(value = "About Create ReservationHold Info", tags = {
"Reservation Hold" })
public class CreateReservationHold {
	private static final Logger logger = LogManager.getLogger(CreateReservationHold.class);
	@Autowired
	private ReservationHoldService reservationHoldService;

	@RequestMapping(value = "reservation-hold", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = DHGlobalException.class) })
	@ApiOperation(value = "Create ReservationHold for venue  .", produces = "application/json")
	public ResponseEntity<ReservationHoldResponse> reservationHold(
			@ApiParam(name="ReservationHoldRequest",
			  value = "A JSON value representing a create reservation hold . An example of the expected schema can be found down here. The fields marked with an * means that they are required."
			 )
			@Valid @RequestBody ReservationHoldRequest reservationHoldReq) throws DHGlobalException {
		logger.info("create-reservation-hold call initiated");
		final ReservationHoldResponse reservationHoldRes = reservationHoldService
				.createReservationHold(reservationHoldReq);
		logger.info("create-reservation-hold call completed");
		if (reservationHoldRes != null) {
			return new ResponseEntity<>(reservationHoldRes, HttpStatus.OK);
		} else {
			throw new DHGlobalException("Failed to create reservation hold");
		}
	}
}
