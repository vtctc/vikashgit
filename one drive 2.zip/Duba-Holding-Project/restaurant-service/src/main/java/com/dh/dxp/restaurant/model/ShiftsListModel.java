package com.dh.dxp.restaurant.model;

import java.util.List;

public class ShiftsListModel {
	private List<VenuesAvailablityResponceDTO> venuesAvailablityResponceDTO;

	public List<VenuesAvailablityResponceDTO> getVenuesAvailablityResponceDTO() {
		return venuesAvailablityResponceDTO;
	}

	public void setVenuesAvailablityResponceDTO(List<VenuesAvailablityResponceDTO> venuesAvailablityResponceDTO) {
		this.venuesAvailablityResponceDTO = venuesAvailablityResponceDTO;
	}
}
