package com.dh.dxp.restaurant.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.controller.CreateReservationHold;
import com.dh.dxp.restaurant.model.ReservationHoldRequest;
import com.dh.dxp.restaurant.model.ReservationHoldResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ReservationHoldService {
	private static final Logger logger = LogManager.getLogger(CreateReservationHold.class);
	@Autowired
	private SavenRoomsAdapter roomsAdapter;

	public ReservationHoldResponse createReservationHold(ReservationHoldRequest reservationHoldReq)
			throws DHGlobalException {
		final ObjectMapper jsonObjectMapper = new ObjectMapper();
		ResponseEntity<String> entity = null;
		ReservationHoldResponse bookingResponse = null;
		logger.info("calling Reservation adapter ");
		entity = roomsAdapter.createReservationHold(reservationHoldReq);
		if (entity != null) {
			bookingResponse = new ReservationHoldResponse();
			JsonNode rootNode;
			try {
				rootNode = jsonObjectMapper.readTree(entity.getBody());
			} catch (final IOException e) {
				logger.error("Error Reading JSON Response in Class :{} ", this.getClass());
				throw new DHGlobalException("Error Reading JSON Response in Class : " + this.getClass());
			}
			final JsonNode jsonRootNode = rootNode.path("data");
			bookingResponse.setShiftPersistentId(jsonRootNode.get("shift_persistent_id").asText());
			bookingResponse.setAccessPersistentId(jsonRootNode.get("access_persistent_id").asText());
			bookingResponse.setHoldDurationSec(jsonRootNode.get("hold_duration_sec").asInt());
			bookingResponse.setReservationHoldId(jsonRootNode.get("reservation_hold_id").asText());
		}
		return bookingResponse;
	}
}
