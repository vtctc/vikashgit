package com.dh.dxp.restaurant.model;

public class Address {
	private String addressLine;
	private String country;
	private String state;
	private String street;
	private String currencyCode;
	private String venueName; // Restaurant Name
	private String phoneNumber;

	public String getAddressLine() {
		return addressLine;
	}

	public String getCountry() {
		return country;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getState() {
		return state;
	}

	public String getStreet() {
		return street;
	}

	public String getVenueName() {
		return venueName;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}
}
