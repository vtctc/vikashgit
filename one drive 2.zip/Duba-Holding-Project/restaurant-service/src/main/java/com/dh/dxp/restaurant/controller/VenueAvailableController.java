package com.dh.dxp.restaurant.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.model.ShiftsListModel;
import com.dh.dxp.restaurant.service.VenueAvailableService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("${base.path.sevenrooms}")
@Validated
@Api(value = "About Venue Availability Info", tags = {
"Venue Availability" })
public class VenueAvailableController {
	private static final Logger logger = LogManager.getLogger(VenueAvailableController.class);
	@Autowired
	VenueAvailableService venueAvailableService;

	@RequestMapping(path = "availability", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class),
			@ApiResponse(code = 404, message = "Bad Request", response = DHGlobalException.class) })
	@ApiOperation(value = "Getting Information Regarding Venue Availability .", produces = "application/json")
	public ResponseEntity<ShiftsListModel> singleVenueDetail(
			@ApiParam(name="venueid",
			  value = "representing venuid."
			 )
			@NotEmpty(message = "{validation.email.notEmpty}") @RequestParam(value = "venue_id", required = true) String venueId,
			@ApiParam(name="partysize",
			  value = "representing partysize."
			 )@Min(value = 1, message = "{validation.partySize.min}") @RequestParam(value = "party_size", required = true) Integer partySize,
			@ApiParam(name="date",
			  value = "representing date to know venue available."
			 )@NotEmpty(message = "{validation.date.notEmpty}") @RequestParam(value = "date", required = true) String dateInString)
			throws DHGlobalException, IOException, ParseException {
		logger.info("venues-availability for venueId:{} partySize:{} date:{}", venueId, partySize, dateInString);
		final ShiftsListModel availableResponseList = venueAvailableService.getVenueAvailabilityByShift(venueId,
				partySize, dateInString);
		logger.info("venues-availability call completed");
		return new ResponseEntity<>(availableResponseList, HttpStatus.ACCEPTED);
	}
}
