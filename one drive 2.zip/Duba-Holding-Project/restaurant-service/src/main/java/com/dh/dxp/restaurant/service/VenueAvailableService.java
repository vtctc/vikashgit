package com.dh.dxp.restaurant.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dh.dxp.component.exceptions.DHGlobalException;
import com.dh.dxp.restaurant.adapter.SavenRoomsAdapter;
import com.dh.dxp.restaurant.model.ShiftsListModel;
import com.dh.dxp.restaurant.model.VenuesAvailablityResponceDTO;
import com.dh.dxp.restaurant.utils.DateUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class VenueAvailableService {
	private static final Logger logger = LogManager.getLogger(VenueAvailableService.class);
	private static final String STARTTIME = "7:30:00";
	private static final String ENDTIME = "23:00:00";
	@Autowired
	private SavenRoomsAdapter roomsAdapter;

	private void availbiltyMethod(Integer partySize, final List<LocalTime> allIntervalTimeList,
			final List<VenuesAvailablityResponceDTO> availablityResponceDTOs, final JsonNode availabilityNode)
			throws DHGlobalException, ParseException {
		for (final JsonNode timeNode : availabilityNode.path("times")) {
			final LocalTime localTime = DateUtils.formatCommon(timeNode.path("time_iso").asText());
			final boolean time = allIntervalTimeList.contains(localTime);
			final VenuesAvailablityResponceDTO venuesAvailablityResponceDTO = new VenuesAvailablityResponceDTO();
			venuesAvailablityResponceDTO.setAccessPersistentId(timeNode.path("access_persistent_id").textValue());
			getDepositAmount(partySize, timeNode, venuesAvailablityResponceDTO);
			venuesAvailablityResponceDTO.setTime(localTime.toString());
			venuesAvailablityResponceDTO.setType(timeNode.path("type").asText());
			venuesAvailablityResponceDTO.setShiftPersistentId(availabilityNode.path("shift_persistent_id").asText());
			if (time)
				venuesAvailablityResponceDTO.setStatus(true);
			else
				venuesAvailablityResponceDTO.setStatus(false);
			availablityResponceDTOs.add(venuesAvailablityResponceDTO);
		}
	}

	private void getDepositAmount(Integer partySize, final JsonNode timeNode,
			final VenuesAvailablityResponceDTO venuesAvailablityResponceDTO) {
		if (venuesAvailablityResponceDTO.getAccessPersistentId() != null) {
			if (timeNode.path("require_credit_card").booleanValue())
				venuesAvailablityResponceDTO.setRequireCreditCard(true);
			if (timeNode.path("cost").asLong() > 0)
				if (timeNode.path("charge_type").textValue().equals("person"))
					venuesAvailablityResponceDTO.setDeposit(timeNode.path("cost").asLong() * partySize);
				else
					venuesAvailablityResponceDTO.setDeposit(timeNode.path("cost").asLong());
		}
	}

	public ShiftsListModel getVenueAvailabilityByShift(String venueId, Integer partySize, String dateInString)
			throws IOException, ParseException, DHGlobalException {
		logger.info("venueAvailableService getVenueAvailabilityByShift initiated with venueId:{} partySize:{} date:{}",
				venueId, partySize, dateInString);
		final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate date = null;
		try {
			date = LocalDate.parse(dateInString, dateFormatter);
		} catch (final DateTimeParseException ex) {
			logger.error("Date should be in ISO 8601 format i.e. yyyy-MM-dd");
			throw new DHGlobalException("Date should be in ISO 8601 format i.e. yyyy-MM-dd");
		}
		if (date.isBefore(LocalDate.now())) {
			logger.error("Cannot submit requests for past dates");
			throw new DHGlobalException("Cannot submit requests for past dates");
		}
		final ObjectMapper jsonObjectMapper = new ObjectMapper();
		final ResponseEntity<String> responceShift = roomsAdapter.getShiftDetails(venueId, date);
		final ShiftsListModel shiftsListModel = new ShiftsListModel();
		if (responceShift != null) {
			final JsonNode shiftBody = jsonObjectMapper.readTree(responceShift.getBody());
			final JsonNode shiftNode = shiftBody.path("data").path("shifts");
			final JsonNode dateNode = shiftNode.iterator().next();
			final List<LocalTime> allIntervalTimeList = new ArrayList<>();
			for (final JsonNode dateValue : dateNode) {
				final List<LocalTime> intervalTimeList = new ArrayList<>();
				final String end_time = dateValue.findValue("end_time").asText();
				final LocalTime localTime = LocalTime.parse(end_time);
				String starttime = dateValue.findValue("start_time").asText();
				final SimpleDateFormat df = new SimpleDateFormat("HH:mm");
				boolean timeCompair;
				int interValueTime = 0;
				do {
					final Date startTimeDate = df.parse(starttime);
					final Calendar calenderObject = Calendar.getInstance();
					calenderObject.setTime(startTimeDate);
					calenderObject.add(Calendar.MINUTE, interValueTime);
					final String tempIntervalTime = df.format(calenderObject.getTime());
					final LocalTime localTimeObj = LocalTime.parse(tempIntervalTime);
					intervalTimeList.add(localTimeObj);
					starttime = localTimeObj.toString();
					interValueTime = dateValue.findValue("interval_minutes").intValue();
					final LocalTime time1 = LocalTime.parse(starttime);
					final LocalTime time2 = LocalTime.parse(localTime.toString());
					timeCompair = time1.equals(time2);
				} while (!timeCompair);
				allIntervalTimeList.addAll(intervalTimeList);
			}
			// Venue availability
			final ResponseEntity<String> availabilityResponce = roomsAdapter.getVenueAvailability(venueId, partySize,
					date, STARTTIME, ENDTIME);
			if (availabilityResponce.getStatusCodeValue() != HttpStatus.OK.value()) {
				logger.error("Something went wrong on the SevenRoomsAdapter  getvenueavailbilty.{}", this.getClass());
				throw new DHGlobalException(
						"Something went wrong on the SevenRoomsAdapter  getvenueavailbilty." + this.getClass());
			}
			final ObjectMapper objectMapper = new ObjectMapper();
			final String availabilityBody = availabilityResponce.getBody();
			final JsonNode availabilityBodyNode = objectMapper.readTree(availabilityBody);
			final List<VenuesAvailablityResponceDTO> availablityResponceDTOs = new ArrayList<>();
			for (final JsonNode availabilityNode : availabilityBodyNode.path("data").path("availability"))
				availbiltyMethod(partySize, allIntervalTimeList, availablityResponceDTOs, availabilityNode);
			shiftsListModel.setVenuesAvailablityResponceDTO(availablityResponceDTOs);
		}
		return shiftsListModel;
	}
}
