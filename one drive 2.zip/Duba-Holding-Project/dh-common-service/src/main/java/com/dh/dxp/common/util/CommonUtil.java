package com.dh.dxp.common.util;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

@Component
public class CommonUtil {
	private RestTemplate restTemplate;
	
	private static final String CURRENCY_EXCHANGE_CACHE = "currency_exchange_cache";
	private static final Logger LOGGER = LogManager.getLogger(CommonUtil.class);
	private static final long CURRENCY_EXCHANGE_CACHE_TTL = (long) 4 * 60 * 60 * 1000;
	
	public CommonUtil(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	/**
	 * This method hits third party api and response backs the data
	 * Only used for get rest calls
	 * @param uri
	 * @return
	 * @throws URISyntaxException 
	 * @throws  
	 */
	@Cacheable(value = CURRENCY_EXCHANGE_CACHE, key = "#url")
	public JsonNode getDataFromThirdParty(final String url) throws URISyntaxException {
		return restTemplate.getForObject(new URI(url), JsonNode.class);
	}
	
	/**
	 * This method runs periodically and flushes cache 
	 * 
	 */
	@CacheEvict(allEntries = true, cacheNames = { CURRENCY_EXCHANGE_CACHE})
	@Scheduled(fixedDelay = CURRENCY_EXCHANGE_CACHE_TTL)
	public boolean currencyExchangeCacheEvict() {
		LOGGER.info("{} Cache is getting flushed-------",CURRENCY_EXCHANGE_CACHE);
		return true;
	}

}
