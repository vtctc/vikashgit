package com.dh.dxp.common.model;

import java.io.Serializable;

public class CurrencyExchangeResposne implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 43846111989213845L;
	
	double currencyValue;

	public double getCurrencyValue() {
		return currencyValue;
	}

	public void setCurrencyValue(double currencyValue) {
		this.currencyValue = currencyValue;
	}
	
}
