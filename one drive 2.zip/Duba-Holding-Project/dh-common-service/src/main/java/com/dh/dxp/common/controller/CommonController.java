package com.dh.dxp.common.controller;

import java.net.URISyntaxException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dh.dxp.common.config.DHConstantUtils;
import com.dh.dxp.common.model.CurrencyExchangeResposne;
import com.dh.dxp.common.service.CurrencyExchangeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(path = DHConstantUtils.COMMON_SERVICE_BASE_PATH)
@Api(value = "This api is used as bridge between new API of DH and old API of DH", tags = {
		"Currency Exchange value etc.," })
public class CommonController {

	CurrencyExchangeService currencyExchangeService;
	private static final Logger LOGGER = LogManager.getLogger(CommonController.class);

	@Autowired
	CommonController(CurrencyExchangeService currencyExchangeService) {
		this.currencyExchangeService = currencyExchangeService;
	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseEntity.class),
			@ApiResponse(code = 500, message = "Error", response = ResponseEntity.class) })
	@ApiOperation(value = "Gives currency value for given currency value", produces = DHConstantUtils.CONTENT_FRMT, notes = "This functionality is used for microservices communication. ")

	@RequestMapping(value = "currency-conversion/{baseCurrency}/{targetCurrency}/{amount}", method = RequestMethod.GET, produces = DHConstantUtils.CONTENT_FRMT)
	public ResponseEntity<CurrencyExchangeResposne> getCurrencyValue(@PathVariable String baseCurrency,
			@PathVariable String targetCurrency, @PathVariable String amount) throws URISyntaxException {
		long startTime = System.currentTimeMillis();
		LOGGER.info("Requested Base currency: {}, Target Currenct: {}, Amount: {}", baseCurrency, targetCurrency,
				amount);
		double currencyValue = currencyExchangeService.getCurrencyExchangeValue(baseCurrency, targetCurrency, amount);
		CurrencyExchangeResposne response = new CurrencyExchangeResposne();
		response.setCurrencyValue(currencyValue);
		LOGGER.info("Response Currency Exchange Value: {}", currencyValue);
		LOGGER.info("Total time consumed in currency conversion :{}ms", System.currentTimeMillis() - startTime);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
