/*
 *
 */
package com.dh.dxp.common.config;

import java.util.concurrent.Callable;

import com.netflix.hystrix.strategy.concurrency.HystrixConcurrencyStrategy;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class CustomHystrixConcurrencyStrategy extends HystrixConcurrencyStrategy {

	@Override
    public <T> Callable<T> wrapCallable(Callable<T> callable){
        return new ContextCallable<>(callable);
    }
 }
