package com.dh.dxp.common.config;

/*
 *
 * Copyright (c) 2019-2022 Dubai Holdings. All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential.
 * 
 */
public class DHConstantUtils {
	
	private DHConstantUtils() {}

	public static final String COMMON_SERVICE_BASE_PATH = "/common/";
	public static final String CONTENT_FRMT = "application/json";
	public static final String TRACEID = "traceId";
	public static final String REQUEST_ID = "requestID";
	public static final String APPLICATION = "application";
	public static final String OPTIONS = "OPTIONS";
	
}
