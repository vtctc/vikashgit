package com.dh.dxp.common.test;

import static org.assertj.core.api.Assertions.fail;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.common.DhCommonServiceApplication;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DhCommonServiceApplicationTests {

	@Test
	public void contextLoads() {
		String[]args = {"start"};
		try {
			DhCommonServiceApplication.main(args);
		}catch(Exception exc) {
			fail("Application is not starting");
		}
		
	}

}
