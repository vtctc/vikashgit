package com.dh.dxp.common.controller.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.common.controller.CommonController;
import com.dh.dxp.common.model.CurrencyExchangeResposne;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations="classpath:application.properties")
public class CommonControllerTest {
	@Autowired
	private CommonController controller;
	
	@Test
	public void getCurrencyValueTest() throws Exception {
		ResponseEntity<CurrencyExchangeResposne> response = controller.getCurrencyValue("AED", "USD", "10");
		CurrencyExchangeResposne responseBody = response.getBody();
		assertNotNull(responseBody.getCurrencyValue());
	}
}
