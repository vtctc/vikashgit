package com.dh.dxp.common.service.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.dh.dxp.common.service.CurrencyExchangeService;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations="classpath:application.properties")
public class CurrencyExchangeServiceTest {
	
	@Autowired
	CurrencyExchangeService service;
	
	@Test
	public void getCurrencyExchangeValueTest() throws Exception {
		Double currencyValue = service.getCurrencyExchangeValue("AED", "USD", "10");
		assertNotNull(currencyValue);
	}
}
